"use client";
import React, { useState } from 'react';

const FileUpload: React.FC = () => {
    const [fileName, setFileName] = useState('');
    const [errorMessage, setErrorMessage] = useState('');

    const validateFile = (file: File) => {
        const fileType = file.name.split('.').pop()?.toLowerCase();
        if (fileType && ['xlsx', 'csv'].includes(fileType)) {
            setFileName(`Selected file: ${file.name}`);
            setErrorMessage('');
            return true;
        } else {
            setFileName('');
            setErrorMessage('Error: Please upload an Excel (.xlsx) or CSV (.csv) file.');
            setTimeout(() => setErrorMessage(''), 3000); // Clear error message after 3 seconds
            return false;
        }
    };

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) validateFile(file);
        else {
            setFileName('');
            setErrorMessage('Error: No file selected. Please upload an Excel (.xlsx) or CSV (.csv) file.');
            setTimeout(() => setErrorMessage(''), 3000); // Clear error message after 3 seconds
        }
    };

    const uploadFile = () => {
        const fileInput = document.getElementById('fileUpload') as HTMLInputElement;
        if (fileInput && fileInput.files?.length) {
            const file = fileInput.files[0];
            if (validateFile(file)) alert('File uploaded and processed!');
        } else {
            setErrorMessage('Error: No file selected. Please upload an Excel (.xlsx) or CSV (.csv) file.');
            setTimeout(() => setErrorMessage(''), 3000); // Clear error message after 3 seconds
        }
    };

    return (
        <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem',
            flexWrap: 'nowrap'
        }}>
            <button 
                onClick={() => document.getElementById('fileUpload')?.click()} 
                style={{
                    backgroundColor: '#007bff',
                    color: 'white',
                    padding: '0.4rem 0.8rem',
                    border: 'none',
                    borderRadius: '0.4rem',
                    cursor: 'pointer',
                    transition: 'background-color 0.3s ease',
                    fontSize: '0.9rem'
                }}
                onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#0056b3'}
                onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#007bff'}
            >
                Choose File
            </button>
            
            <input 
                type="file" 
                id="fileUpload" 
                name="fileUpload" 
                accept=".xlsx, .csv" 
                onChange={handleFileChange} 
                style={{ display: 'none' }} 
            />
            
            <button 
                style={{
                    backgroundColor: '#4CAF50',
                    color: 'white',
                    padding: '0.4rem 0.8rem',
                    border: 'none',
                    borderRadius: '0.4rem',
                    cursor: 'pointer',
                    transition: 'background-color 0.3s ease',
                    fontSize: '0.9rem'
                }}
                onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#45a049'}
                onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#4CAF50'}
                onClick={uploadFile}
            >
                Upload
            </button>
            
            {fileName && (
                <div style={{
                    fontSize: '0.8rem',
                    color: '#333',
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    maxWidth: '150px'
                }}>
                    {fileName}
                </div>
            )}
            
            {errorMessage && (
                <div style={{ 
                    color: 'red',
                    fontSize: '0.8rem',
                    whiteSpace: 'nowrap'
                }}>
                    {errorMessage}
                </div>
            )};
        </div>
    );
};

export default FileUpload;                                                                                                                                                                                           
                                                                                                                                         