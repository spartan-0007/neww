import React from 'react';

const Footer = () => {
  return (
    <footer style={{ backgroundColor: 'black', color: 'white', padding: '10px 0', width: '100%', position: 'fixed', bottom: '0', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <p style={{ textAlign: 'center' }}>&copy; {new Date().getFullYear()} Iftas. All rights reserved.</p>
    </footer>
  );
};

export default Footer;
