// AssignKRA component structure (you'll need to implement this in your actual component)

import React, { useState, useEffect } from 'react';

interface KRAData {
  id: number;
  title: string;
  description: string;
  target: string;
  weightage: string;
}

interface AssignKRAEmployee {
  id: number;
  name: string;
  position: string;
  employeeId: string;
  department: string;
  location: string;
  experience: string;
  kraStatus: 'Not Assigned' | 'Assigned' | 'In Progress' | 'Completed';
  avatar: string;
  reportingManager?: string;
}

interface AssignKRAProps {
  employee: AssignKRAEmployee;
  onBack: () => void;
  onSubmit: (kras: KRAData[]) => void;
  initialData?: KRAData[];
}

const AssignKRA: React.FC<AssignKRAProps> = ({ 
  employee, 
  onBack, 
  onSubmit, 
  initialData 
}) => {
  const [kras, setKras] = useState<KRAData[]>(initialData || []);
  const [isLoading, setIsLoading] = useState(false);
  
  // Determine if we're editing existing KRAs or creating new ones
  const isEditing = initialData && initialData.length > 0;
  
  const handleSave = async () => {
    if (kras.length === 0) {
      alert('Please add at least one KRA before saving.');
      return;
    }
    
    // Validate that all KRAs have required fields
    const isValid = kras.every(kra => 
      kra.title.trim() && 
      kra.description.trim() && 
      kra.target.trim() && 
      kra.weightage.trim()
    );
    
    if (!isValid) {
      alert('Please fill in all required fields for each KRA.');
      return;
    }
    
    // Validate that total weightage equals 100
    const totalWeightage = kras.reduce((sum, kra) => sum + parseInt(kra.weightage), 0);
    if (totalWeightage !== 100) {
      alert(`Total weightage must equal 100%. Current total: ${totalWeightage}%`);
      return;
    }
    
    setIsLoading(true);
    try {
      // Call the onSubmit function passed from parent
      await onSubmit(kras);
    } catch (error) {
      console.error('Error saving KRAs:', error);
      alert('Failed to save KRAs. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  // Add a new KRA
  const addKRA = () => {
    const newKRA: KRAData = {
      id: Date.now(), // Simple ID generation
      title: '',
      description: '',
      target: '',
      weightage: ''
    };
    setKras([...kras, newKRA]);
  };

  // Remove a KRA
  const removeKRA = (id: number) => {
    setKras(kras.filter(kra => kra.id !== id));
  };

  // Update a KRA
  const updateKRA = (id: number, field: keyof KRAData, value: string) => {
    setKras(kras.map(kra => 
      kra.id === id ? { ...kra, [field]: value } : kra
    ));
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 max-w-6xl mx-auto">
      {/* Header */}
      <div className="mb-6">
        <button
          onClick={onBack}
          className="group flex items-center gap-3 px-4 py-3 text-gray-600 hover:text-white hover:bg-gradient-to-r hover:from-blue-500 hover:to-purple-600 rounded-xl transition-all duration-300 shadow-sm hover:shadow-lg transform hover:-translate-y-0.5 mb-4"
        >
          <div className="p-1.5 bg-gray-100 group-hover:bg-white/20 rounded-lg transition-all duration-300">
            <svg 
              className="w-5 h-5 transform group-hover:-translate-x-1 transition-transform duration-300" 
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </div>
          <div>
            <span className="font-semibold text-sm">Back to Team</span>
            <p className="text-xs opacity-75 group-hover:opacity-100">Return to team management</p>
          </div>
        </button>

        <h2 className="text-2xl font-bold text-gray-900 mb-2">
          {isEditing ? 'Edit KRAs' : 'Assign KRAs'} - {employee.name}
        </h2>
        <p className="text-gray-600">
          {employee.position} • {employee.department} • {employee.employeeId}
        </p>
      </div>

      {/* KRA Form Content */}
      <div className="space-y-6">
        {kras.map((kra, index) => (
          <div key={kra.id} className="bg-gray-50 rounded-xl p-6 border border-gray-200">
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-lg font-semibold text-gray-900">KRA {index + 1}</h3>
              {kras.length > 1 && (
                <button
                  onClick={() => removeKRA(kra.id)}
                  className="text-red-500 hover:text-red-700 transition-colors"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                </button>
              )}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Title *
                </label>
                <input
                  type="text"
                  value={kra.title}
                  onChange={(e) => updateKRA(kra.id, 'title', e.target.value)}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  placeholder="Enter KRA title"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Weightage (%) *
                </label>
                <input
                  type="number"
                  value={kra.weightage}
                  onChange={(e) => updateKRA(kra.id, 'weightage', e.target.value)}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  placeholder="Enter weightage percentage"
                  min="0"
                  max="100"
                />
              </div>
            </div>
            
            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description *
              </label>
              <textarea
                value={kra.description}
                onChange={(e) => updateKRA(kra.id, 'description', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                rows={3}
                placeholder="Describe the KRA in detail"
              />
            </div>
            
            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Target *
              </label>
              <textarea
                value={kra.target}
                onChange={(e) => updateKRA(kra.id, 'target', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                rows={2}
                placeholder="Define the target or expected outcome"
              />
            </div>
          </div>
        ))}

        {/* Add KRA Button */}
        <button
          onClick={addKRA}
          className="w-full border-2 border-dashed border-gray-300 hover:border-blue-500 text-gray-600 hover:text-blue-600 py-4 px-6 rounded-xl transition-colors flex items-center justify-center gap-2 font-medium"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
          Add Another KRA
        </button>

        {/* Weightage Summary */}
        {kras.length > 0 && (
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium text-blue-900">Total Weightage:</span>
              <span className={`text-sm font-bold ${
                kras.reduce((sum, kra) => sum + (parseInt(kra.weightage) || 0), 0) === 100 
                  ? 'text-green-600' 
                  : 'text-red-600'
              }`}>
                {kras.reduce((sum, kra) => sum + (parseInt(kra.weightage) || 0), 0)}%
              </span>
            </div>
            <p className="text-xs text-blue-700 mt-1">
              Total weightage must equal 100%
            </p>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex gap-4 pt-6 border-t border-gray-200">
          <button
            onClick={onBack}
            className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 px-6 rounded-lg transition-colors font-medium"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={isLoading || kras.length === 0}
            className="flex-1 bg-blue-500 hover:bg-blue-600 disabled:bg-gray-300 disabled:cursor-not-allowed text-white py-3 px-6 rounded-lg transition-colors font-medium flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <>
                <svg className="animate-spin w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
                Saving...
              </>
            ) : (
              <>
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                {isEditing ? 'Update KRAs' : 'Assign KRAs'}
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AssignKRA;