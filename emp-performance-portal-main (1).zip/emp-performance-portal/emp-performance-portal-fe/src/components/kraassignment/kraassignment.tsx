'use client';

import React, { useState, useEffect } from 'react';
import type { KRA } from '@/data/krasampledata';

interface TeamMember {
  id: string;
  employeeId: string;
  name: string;
  initials: string;
  position: string;
  department: string;
  location: string;
  experience: string;
}

interface KRAAssignmentProps {
  isOpen: boolean;
  onClose: () => void;
  employee: TeamMember;
  existingKRAs?: KRA[];
  onSave: (employeeId: string, kras: KRA[]) => void;
}

const KRAAssignment: React.FC<KRAAssignmentProps> = ({
  isOpen,
  onClose,
  employee,
  existingKRAs = [],
  onSave
}) => {
  const [kras, setKras] = useState<KRA[]>([]);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);

  // Initialize with existing KRAs or add a blank one
  useEffect(() => {
    if (existingKRAs.length > 0) {
      setKras(existingKRAs);
    } else {
      setKras([createNewKRA()]);
    }
  }, [existingKRAs]);

  const createNewKRA = (): KRA => ({
    id: Date.now(),
    title: '',
    description: '',
    targetValue: '',
    weightage: 0,
    category: 'CLOUD',
    status: 'PENDING_SELF_RATING',
    selfRating: 0,
    supervisorRating: 0,
    finalRating: 0,
    achievementComments: '',
    supervisorComments: '',
    reviewerComments: ''
  });

  const categories = [
    { value: 'CLOUD', label: 'Cloud', color: 'bg-red-100 text-red-700' },
    { value: 'TEAM', label: 'Team', color: 'bg-yellow-100 text-yellow-700' },
    { value: 'EFFICIENCY', label: 'Efficiency', color: 'bg-orange-100 text-orange-700' },
    { value: 'INNOVATION', label: 'Innovation', color: 'bg-green-100 text-green-700' },
    { value: 'STAKEHOLDER', label: 'Stakeholder', color: 'bg-purple-100 text-purple-700' },
    { value: 'MANDATORY', label: 'Mandatory', color: 'bg-pink-100 text-pink-700' },
    { value: 'SELF', label: 'Self', color: 'bg-indigo-100 text-indigo-700' }
  ];

  const addKRA = () => {
    setKras([...kras, createNewKRA()]);
    setEditingIndex(kras.length);
  };

  const removeKRA = (index: number) => {
    setKras(kras.filter((_, i) => i !== index));
  };

  const updateKRA = (index: number, field: keyof KRA, value: any) => {
    const updatedKRAs = [...kras];
    updatedKRAs[index] = { ...updatedKRAs[index], [field]: value };
    setKras(updatedKRAs);
  };

  const getTotalWeightage = () => {
    return kras.reduce((sum, kra) => sum + (kra.weightage || 0), 0);
  };

  const handleSave = () => {
    const totalWeight = getTotalWeightage();
    if (totalWeight !== 100) {
      alert('Total weightage must equal 100%');
      return;
    }

    if (kras.some(kra => !kra.title || !kra.description || !kra.targetValue)) {
      alert('Please fill in all required fields');
      return;
    }

    onSave(employee.employeeId, kras);
  };

  // Priority colors based on weightage
  const getPriorityColor = (weightage: number) => {
    if (weightage >= 20) return { bg: 'bg-red-100', text: 'text-red-700', label: 'HIGH' };
    if (weightage >= 15) return { bg: 'bg-yellow-100', text: 'text-yellow-700', label: 'MEDIUM' };
    return { bg: 'bg-green-100', text: 'text-green-700', label: 'LOW' };
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-6xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-2xl font-bold">
                {existingKRAs.length > 0 ? 'Edit KRAs' : 'Assign KRAs'}
              </h2>
              <p className="text-blue-100 mt-1">
                {employee.name} • {employee.position}
              </p>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:bg-white/20 p-2 rounded-lg transition-colors"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {/* Weightage Summary */}
          <div className="mb-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex justify-between items-center">
              <span className="text-blue-900 font-medium">Total Weightage:</span>
              <span className={`text-2xl font-bold ${getTotalWeightage() === 100 ? 'text-green-600' : 'text-red-600'}`}>
                {getTotalWeightage()}%
              </span>
            </div>
            {getTotalWeightage() !== 100 && (
              <p className="text-sm text-red-600 mt-2">
                ⚠️ Total weightage must equal 100%
              </p>
            )}
          </div>

          {/* KRA List */}
          <div className="space-y-4">
            {kras.map((kra, index) => (
              <div key={kra.id} className="bg-gray-50 rounded-lg p-6 border border-gray-200">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-lg font-semibold text-gray-900">
                    KRA #{index + 1}
                  </h3>
                  {kras.length > 1 && (
                    <button
                      onClick={() => removeKRA(index)}
                      className="text-red-600 hover:bg-red-50 p-2 rounded-lg transition-colors"
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Title */}
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      KRA Title *
                    </label>
                    <input
                      type="text"
                      value={kra.title}
                      onChange={(e) => updateKRA(index, 'title', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Enter KRA title"
                    />
                  </div>

                  {/* Description */}
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Description *
                    </label>
                    <textarea
                      value={kra.description}
                      onChange={(e) => updateKRA(index, 'description', e.target.value)}
                      rows={3}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Enter detailed description"
                    />
                  </div>

                  {/* Target Value */}
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Target/Success Criteria *
                    </label>
                    <input
                      type="text"
                      value={kra.targetValue}
                      onChange={(e) => updateKRA(index, 'targetValue', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Define measurable target"
                    />
                  </div>

                  {/* Category */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Category *
                    </label>
                    <select
                      value={kra.category}
                      onChange={(e) => updateKRA(index, 'category', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    >
                      {categories.map(cat => (
                        <option key={cat.value} value={cat.value}>{cat.label}</option>
                      ))}
                    </select>
                  </div>

                  {/* Weightage */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Weightage (%) *
                    </label>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={kra.weightage}
                      onChange={(e) => updateKRA(index, 'weightage', parseInt(e.target.value) || 0)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="0"
                    />
                  </div>

                  {/* Status */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Status
                    </label>
                    <select
                      value={kra.status}
                      onChange={(e) => updateKRA(index, 'status', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option value="PENDING_SELF_RATING">Pending Self Rating</option>
                      <option value="IN_PROGRESS">In Progress</option>
                      <option value="COMPLETED">Completed</option>
                    </select>
                  </div>

                  {/* Priority */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Priority
                    </label>
                    <div className="p-3 bg-gray-50 rounded-lg">
                      <span className={`inline-block px-3 py-1 rounded text-sm font-medium ${
                        getPriorityColor(kra.weightage).bg
                      } ${getPriorityColor(kra.weightage).text}`}>
                        {getPriorityColor(kra.weightage).label}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Add KRA Button */}
          <button
            onClick={addKRA}
            className="mt-4 w-full py-3 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-blue-500 hover:text-blue-600 transition-colors flex items-center justify-center gap-2"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            Add KRA
          </button>
        </div>

        {/* Footer */}
        <div className="bg-gray-50 p-6 border-t border-gray-200">
          <div className="flex justify-between items-center">
            <button
              onClick={onClose}
              className="px-6 py-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors font-medium"
            >
              Cancel
            </button>
            <div className="flex gap-3">
              <button
                onClick={handleSave}
                disabled={getTotalWeightage() !== 100}
                className={`px-6 py-2.5 rounded-lg font-medium transition-colors ${
                  getTotalWeightage() === 100
                    ? 'bg-blue-600 text-white hover:bg-blue-700'
                    : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                }`}
              >
                Save KRAs
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default KRAAssignment;