import React, { useState, useEffect } from 'react';

// Interfaces
interface Task {
  id: number;
  personName: string;
  level: string;
  taskDescription: string;
  storyPoints: string;
  status: string;
  sprint: string;
}

interface PerformanceData {
  personName: string;
  level: string;
  expectedStoryPoints: number;
  actualStoryPoints: number;
  performancePercentage: number;
  performanceStatus: 'Above Expected' | 'Meets Expected' | 'Below Expected';
}

// Initial sample data
const initialTasks: Task[] = [
  { id: 1, personName: 'Harshith Murthy', level: 'L0', taskDescription: 'User Authentication Module', storyPoints: '8', status: 'Completed', sprint: 'Sprint 1' },
  { id: 2, personName: 'Utsav Raj', level: 'L0', taskDescription: 'Database Schema Design', storyPoints: '5', status: 'In Progress', sprint: 'Sprint 1' },
  { id: 3, personName: 'Dhvaj Raman Das', level: 'L1', taskDescription: 'API Integration', storyPoints: '13', status: 'Completed', sprint: 'Sprint 1' },
  { id: 4, personName: 'Rashmatti Mishra', level: 'Manager', taskDescription: 'Code Review & Planning', storyPoints: '8', status: 'Completed', sprint: 'Sprint 1' },
  { id: 5, personName: 'Mayur Pawar', level: 'L2', taskDescription: 'Frontend Architecture', storyPoints: '21', status: 'Completed', sprint: 'Sprint 1' },
  { id: 6, personName: 'Harshith Murthy', level: 'L1', taskDescription: 'Testing Framework Setup', storyPoints: '12', status: 'In Progress', sprint: 'Sprint 1' },
  { id: 7, personName: 'Harshith Murthy', level: 'L0', taskDescription: 'Login Page UI', storyPoints: '5', status: 'Completed', sprint: 'Sprint 1' },
  { id: 8, personName: 'Mayur Pawar', level: 'L2', taskDescription: 'Dashboard Components', storyPoints: '8', status: 'In Progress', sprint: 'Sprint 1' }
];

// Expected story points by level
const expectedStoryPointsByLevel: Record<string, number> = {
  'L0': 10,
  'L1': 15,
  'L2': 22,
  'Manager': 12
};

// Options for dropdowns
const levelOptions = ['L0', 'L1', 'L2', 'Manager'];
const statusOptions = ['Not Started', 'In Progress', 'Completed'];
const sprintOptions = ['Sprint 1', 'Sprint 2', 'Sprint 3', 'Sprint 4'];

const IntegratedTaskPerformance: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  const [performanceData, setPerformanceData] = useState<PerformanceData[]>([]);
  const [changedTasks, setChangedTasks] = useState<Set<number>>(new Set());

  // Calculate performance data whenever tasks change
  useEffect(() => {
    const tasksByPerson: Record<string, Task[]> = {};
    
    // Group tasks by person
    tasks.forEach(task => {
      if (!tasksByPerson[task.personName]) {
        tasksByPerson[task.personName] = [];
      }
      tasksByPerson[task.personName].push(task);
    });

    // Calculate performance for each person
    const newPerformanceData: PerformanceData[] = [];
    
    Object.entries(tasksByPerson).forEach(([personName, personTasks]) => {
      // Get the person's level (using first task's level)
      const level = personTasks[0].level;
      const expectedStoryPoints = expectedStoryPointsByLevel[level] || 0;
      
      // Calculate actual story points (only completed tasks)
      const actualStoryPoints = personTasks
        .filter(task => task.status === 'Completed')
        .reduce((total, task) => total + (parseInt(task.storyPoints) || 0), 0);
      
      // Calculate performance percentage
      const performancePercentage = expectedStoryPoints > 0 
        ? Math.round((actualStoryPoints / expectedStoryPoints) * 1000) / 10 
        : 0;
      
      // Determine performance status
      let performanceStatus: PerformanceData['performanceStatus'];
      if (performancePercentage > 100) {
        performanceStatus = 'Above Expected';
      } else if (performancePercentage === 100) {
        performanceStatus = 'Meets Expected';
      } else {
        performanceStatus = 'Below Expected';
      }
      
      newPerformanceData.push({
        personName,
        level,
        expectedStoryPoints,
        actualStoryPoints,
        performancePercentage,
        performanceStatus
      });
    });
    
    setPerformanceData(newPerformanceData.sort((a, b) => a.personName.localeCompare(b.personName)));
  }, [tasks]);

  // Add new task
  const addNewTask = () => {
    const newId = Math.max(...tasks.map(t => t.id), 0) + 1;
    const newTask: Task = {
      id: newId,
      personName: '',
      level: 'L0',
      taskDescription: '',
      storyPoints: '',
      status: 'In Progress',
      sprint: 'Sprint 1'
    };
    setTasks([...tasks, newTask]);
  };

  // Handle input changes
  const handleInputChange = (id: number, field: keyof Task, value: string) => {
    setTasks(tasks.map(task => 
      task.id === id ? { ...task, [field]: value } : task
    ));
    setChangedTasks(prev => new Set(prev).add(id));
  };

  // Delete task
  const deleteTask = (id: number) => {
    setTasks(tasks.filter(task => task.id !== id));
    setChangedTasks(prev => {
      const newSet = new Set(prev);
      newSet.delete(id);
      return newSet;
    });
  };

  // Update task
  const updateTask = (id: number) => {
    if (!changedTasks.has(id)) {
      alert('Please update something before saving!');
      return;
    }
    alert(`Task ${id} updated successfully!`);
    setChangedTasks(prev => {
      const newSet = new Set(prev);
      newSet.delete(id);
      return newSet;
    });
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Task Tracking Section */}
      <div className="p-6 pb-3">
        <h1 className="text-2xl font-semibold text-gray-800 mb-4">Task Tracking</h1>
        
        {/* Buttons */}
        <div className="flex justify-between mb-4">
          <div className="flex gap-2">
            <button
              onClick={addNewTask}
              className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition-colors"
            >
              Add New Task
            </button>
            <button
              onClick={() => alert('Export to Excel')}
              className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition-colors"
            >
              Export to Excel
            </button>
          </div>
        </div>

        {/* Task Table */}
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="bg-blue-600 text-white">
                <th className="px-4 py-3 text-left text-sm font-medium">Person Name</th>
                <th className="px-4 py-3 text-left text-sm font-medium">Level</th>
                <th className="px-4 py-3 text-left text-sm font-medium">Task Description</th>
                <th className="px-4 py-3 text-left text-sm font-medium">Story Points</th>
                <th className="px-4 py-3 text-left text-sm font-medium">Status</th>
                <th className="px-4 py-3 text-left text-sm font-medium">Sprint</th>
                <th className="px-4 py-3 text-left text-sm font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {tasks.map((task, index) => (
                <tr key={task.id} className={index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                  <td className="px-4 py-2 border-b">
                    <input
                      type="text"
                      value={task.personName}
                      onChange={(e) => handleInputChange(task.id, 'personName', e.target.value)}
                      className="w-full px-2 py-1 border rounded"
                    />
                  </td>
                  <td className="px-4 py-2 border-b">
                    <select
                      value={task.level}
                      onChange={(e) => handleInputChange(task.id, 'level', e.target.value)}
                      className="w-full px-2 py-1 border rounded"
                    >
                      {levelOptions.map(level => (
                        <option key={level} value={level}>{level}</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-2 border-b">
                    <input
                      type="text"
                      value={task.taskDescription}
                      onChange={(e) => handleInputChange(task.id, 'taskDescription', e.target.value)}
                      className="w-full px-2 py-1 border rounded"
                    />
                  </td>
                  <td className="px-4 py-2 border-b">
                    <input
                      type="number"
                      value={task.storyPoints}
                      onChange={(e) => handleInputChange(task.id, 'storyPoints', e.target.value)}
                      className="w-full px-2 py-1 border rounded"
                    />
                  </td>
                  <td className="px-4 py-2 border-b">
                    <select
                      value={task.status}
                      onChange={(e) => handleInputChange(task.id, 'status', e.target.value)}
                      className="w-full px-2 py-1 border rounded"
                    >
                      {statusOptions.map(status => (
                        <option key={status} value={status}>{status}</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-2 border-b">
                    <select
                      value={task.sprint}
                      onChange={(e) => handleInputChange(task.id, 'sprint', e.target.value)}
                      className="w-full px-2 py-1 border rounded"
                    >
                      {sprintOptions.map(sprint => (
                        <option key={sprint} value={sprint}>{sprint}</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-2 border-b">
                    <div className="flex gap-1">
                      <button
                        onClick={() => updateTask(task.id)}
                        disabled={!changedTasks.has(task.id)}
                        className={`px-3 py-1 rounded text-white text-xs ${
                          changedTasks.has(task.id) 
                            ? 'bg-blue-600 hover:bg-blue-700' 
                            : 'bg-gray-400 cursor-not-allowed'
                        }`}
                      >
                        Update
                      </button>
                      <button
                        onClick={() => deleteTask(task.id)}
                        className="px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700 text-xs"
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Performance Summary Section */}
      <div className="p-6 pt-3">
        <h1 className="text-2xl font-semibold text-gray-800 mb-4">Performance Summary</h1>
        
        {/* Performance Table */}
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="bg-blue-600 text-white">
                <th className="px-4 py-3 text-left text-sm font-medium">Person Name</th>
                <th className="px-4 py-3 text-left text-sm font-medium">Level</th>
                <th className="px-4 py-3 text-left text-sm font-medium">Expected Story Points/Sprint</th>
                <th className="px-4 py-3 text-left text-sm font-medium">Actual Story Points</th>
                <th className="px-4 py-3 text-left text-sm font-medium">Performance %</th>
                <th className="px-4 py-3 text-left text-sm font-medium">Performance Status</th>
              </tr>
            </thead>
            <tbody>
              {performanceData.map((person) => (
                <tr 
                  key={person.personName}
                  className={
                    person.performanceStatus === 'Above Expected' 
                      ? 'bg-green-100' 
                      : person.performanceStatus === 'Below Expected' 
                      ? 'bg-red-100' 
                      : 'bg-blue-100'
                  }
                >
                  <td className="px-4 py-3 border-b font-medium">{person.personName}</td>
                  <td className="px-4 py-3 border-b">{person.level}</td>
                  <td className="px-4 py-3 border-b">{person.expectedStoryPoints}</td>
                  <td className="px-4 py-3 border-b">{person.actualStoryPoints}</td>
                  <td className="px-4 py-3 border-b font-medium">{person.performancePercentage}%</td>
                  <td className="px-4 py-3 border-b">
                    <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${
                      person.performanceStatus === 'Above Expected' 
                        ? 'bg-green-200 text-green-800' 
                        : person.performanceStatus === 'Below Expected' 
                        ? 'bg-red-200 text-red-800' 
                        : 'bg-blue-200 text-blue-800'
                    }`}>
                      {person.performanceStatus === 'Above Expected' && '🟢 '}
                      {person.performanceStatus === 'Meets Expected' && '🔵 '}
                      {person.performanceStatus === 'Below Expected' && '🔴 '}
                      {person.performanceStatus}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default IntegratedTaskPerformance;