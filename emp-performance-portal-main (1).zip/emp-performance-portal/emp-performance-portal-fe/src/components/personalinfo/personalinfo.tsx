// PersonalInfo.tsx
'use client';

import React from 'react';
import { personalInfoData, PersonalInfoData } from '../../data/sampledata';

interface PersonalInfoProps {
  data?: PersonalInfoData;
}

const PersonalInfo: React.FC<PersonalInfoProps> = ({ data = personalInfoData }) => {
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 max-w-6xl mx-auto">
      {/* Header Section */}
      <div className="flex items-start gap-6 mb-10">
        {/* Profile Avatar */}
        <div className="w-24 h-24 bg-green-500 rounded-2xl flex items-center justify-center text-white text-2xl font-bold flex-shrink-0">
          {data.initials}
        </div>
        
        {/* Name and Position */}
        <div className="flex-1">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{data.name}</h1>
          <p className="text-xl text-gray-600 mb-4">{data.position}</p>
          
          {/* Employee ID and Role */}
          <div className="flex items-center gap-4">
            <span className="bg-green-100 text-green-700 px-4 py-2 rounded-lg text-base font-medium">
              {data.employeeId}
            </span>
            <span className="bg-purple-100 text-purple-700 px-4 py-2 rounded-lg text-base font-medium">
              {data.role}
            </span>
          </div>
        </div>
      </div>

      {/* Information Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {/* Department */}
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
            <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
            </svg>
          </div>
          <div>
            <p className="text-sm text-gray-500 uppercase tracking-wide font-medium">DEPARTMENT</p>
            <p className="text-gray-900 font-medium text-base">{data.department}</p>
          </div>
        </div>

        {/* Location */}
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
            <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
          </div>
          <div>
            <p className="text-sm text-gray-500 uppercase tracking-wide font-medium">LOCATION</p>
            <p className="text-gray-900 font-medium text-base">{data.location}</p>
          </div>
        </div>

        {/* Team Size */}
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
            <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
          </div>
          <div>
            <p className="text-sm text-gray-500 uppercase tracking-wide font-medium">TEAM SIZE</p>
            <p className="text-gray-900 font-medium text-base">{data.teamSize} Members</p>
          </div>
        </div>

        {/* Experience */}
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center flex-shrink-0">
            <svg className="w-6 h-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
            </svg>
          </div>
          <div>
            <p className="text-sm text-gray-500 uppercase tracking-wide font-medium">EXPERIENCE</p>
            <p className="text-gray-900 font-medium text-base">{data.experience} years</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PersonalInfo;