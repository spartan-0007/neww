import React from 'react';

const SelfAssessmentForm = () => {
  return (
    <div className="min-h-screen bg-white p-6">
      <div className="max-w-4xl mx-auto">
        <div className="bg-blue-50 border border-gray-300 rounded-lg p-6">
          {/* Header */}
          <div className="flex items-center gap-2 mb-6">
            <div className="w-4 h-4 border border-blue-500 rounded flex items-center justify-center">
              <div className="w-2 h-2 bg-blue-500 rounded"></div>
            </div>
            <h2 className="text-lg font-medium text-gray-800">Self-Assessment</h2>
          </div>

          {/* Score Section */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Score (0-100) <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <input
                type="number"
                min="0"
                max="100"
                defaultValue="0"
                className="w-full px-3 py-3 border border-gray-300 rounded-md text-center text-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
              <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-blue-500 text-sm font-medium">
                /100
              </div>
            </div>
          </div>

          {/* Achievement Comments Section */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Achievement Comments <span className="text-red-500">*</span>
            </label>
            <textarea
              placeholder="Describe your key achievements..."
              rows={4}
              className="w-full px-3 py-3 border border-gray-300 rounded-md resize-none bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 placeholder-gray-400"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default SelfAssessmentForm;