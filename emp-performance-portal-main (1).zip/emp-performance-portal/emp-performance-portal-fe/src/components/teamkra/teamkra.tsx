'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { teamMembersData, departments, statusOptions, TeamMember } from '@/data/sampledata3';
import EditEmployeeModal from '@/components/editkra/editkra';
import AssignKRA from '@/components/kraform/kraform';

// Define KRA type for compatibility with AssignKRA component
interface KRAData {
  id: number;
  title: string;
  description: string;
  target: string;
  weightage: string;
}

// Employee interface for AssignKRA component
interface AssignKRAEmployee {
  id: number;
  name: string;
  position: string;
  employeeId: string;
  department: string;
  location: string;
  experience: string;
  kraStatus: 'Not Assigned' | 'Assigned' | 'In Progress' | 'Completed';
  avatar: string;
  email?: string;
  phone?: string;
  joinDate?: string;
  reportingManager?: string;
}

interface RatingData {
  employeeId: string;
  employeeName: string;
  ratings: {
    kraId: string;
    kraTitle: string;
    selfRating: number;
    supervisorRating: number;
    comment: string;
  }[];
  submittedAt: string;
}

// Extended TeamMember with rating info
interface TeamMemberWithRating extends TeamMember {
  avgSelfRating?: number;
  avgSupervisorRating?: number;
  lastRatingUpdate?: string;
}

interface TeamKRAsProps {
  onBackToMyKRAs?: () => void;
  onViewEmployee?: (employee: any) => void;
}

const TeamKRAs: React.FC<TeamKRAsProps> = ({ onBackToMyKRAs, onViewEmployee }) => {
  const router = useRouter();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('All Departments');
  const [selectedStatus, setSelectedStatus] = useState('All Status');
  const [filteredMembers, setFilteredMembers] = useState<TeamMemberWithRating[]>(teamMembersData);
  const [selectedMember, setSelectedMember] = useState<TeamMember | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [employeeRatings, setEmployeeRatings] = useState<{ [key: string]: RatingData }>({});
  const [showKRAAssignment, setShowKRAAssignment] = useState(false);
  const [assigningEmployee, setAssigningEmployee] = useState<AssignKRAEmployee | null>(null);
  const [existingKRAs, setExistingKRAs] = useState<KRAData[]>([]);
  const [isEditingKRAs, setIsEditingKRAs] = useState(false);

  // Function to calculate average rating
  const calculateAverageRating = (ratings: number[]) => {
    if (ratings.length === 0) return 0;
    const sum = ratings.reduce((acc, rating) => acc + rating, 0);
    return Math.round(sum / ratings.length);
  };

  // Function to update members with ratings
  const updateMembersWithRatings = useCallback((ratings: { [key: string]: RatingData }) => {
    console.log('Updating members with ratings:', ratings);
    const updatedMembers = teamMembersData.map(member => {
      const memberRating = ratings[member.employeeId];
      if (memberRating && member.kraStatus !== 'Not Assigned') {
        const avgSelfRating = calculateAverageRating(memberRating.ratings.map(r => r.selfRating));
        const avgSupervisorRating = calculateAverageRating(memberRating.ratings.map(r => r.supervisorRating));
        return {
          ...member,
          avgSelfRating,
          avgSupervisorRating,
          lastRatingUpdate: memberRating.submittedAt
        };
      }
      return {
        ...member,
        avgSelfRating: undefined,
        avgSupervisorRating: undefined,
        lastRatingUpdate: undefined
      };
    });
    return updatedMembers;
  }, []);

  // Function to load and merge ratings from both storage sources
  const loadAllRatings = useCallback(() => {
    console.log('Loading all ratings...');
    let mergedRatings: { [key: string]: RatingData } = {};

    // First, load from localStorage
    const storedRatings = localStorage.getItem('employeeRatings');
    if (storedRatings) {
      try {
        const parsedRatings = JSON.parse(storedRatings);
        teamMembersData.forEach(member => {
          if (member.kraStatus !== 'Not Assigned' && parsedRatings[member.employeeId]) {
            mergedRatings[member.employeeId] = parsedRatings[member.employeeId];
          }
        });
      } catch (error) {
        console.error('Error parsing stored ratings:', error);
      }
    }

    // Then, check sessionStorage for newer data
    const sessionRatingStr = sessionStorage.getItem('submittedRatings');
    if (sessionRatingStr) {
      try {
        const sessionRating: RatingData = JSON.parse(sessionRatingStr);
        const member = teamMembersData.find(m => m.employeeId === sessionRating.employeeId);
        
        if (member && member.kraStatus !== 'Not Assigned') {
          // Override with session data if it exists
          mergedRatings[sessionRating.employeeId] = sessionRating;
          
          // Update localStorage with the new data
          localStorage.setItem('employeeRatings', JSON.stringify(mergedRatings));
          
          // Clear sessionStorage after merging
          sessionStorage.removeItem('submittedRatings');
        }
      } catch (error) {
        console.error('Error parsing session ratings:', error);
      }
    }

    return mergedRatings;
  }, []);

  // Initial load and setup - runs on every mount
  useEffect(() => {
    console.log('Component mounted, loading ratings...');
    const ratings = loadAllRatings();
    setEmployeeRatings(ratings);
    const updatedMembers = updateMembersWithRatings(ratings);
    setFilteredMembers(updatedMembers);
  }, [loadAllRatings, updateMembersWithRatings]);

  // Apply filters function (not using useCallback to avoid circular dependency)
  const applyFilters = (ratingsToUse?: { [key: string]: RatingData }) => {
    const ratings = ratingsToUse || employeeRatings;
    console.log('Applying filters with ratings:', ratings);
    
    const filtered = teamMembersData.filter(member => {
      const matchesSearch = member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           member.employeeId.includes(searchTerm);
      const matchesDepartment = selectedDepartment === 'All Departments' ||
                               member.department === selectedDepartment;
      const matchesStatus = selectedStatus === 'All Status' ||
                           member.kraStatus === selectedStatus;

      return matchesSearch && matchesDepartment && matchesStatus;
    });

    const filteredWithRatings = filtered.map(member => {
      const memberRating = ratings[member.employeeId];
      if (memberRating && member.kraStatus !== 'Not Assigned') {
        const avgSelfRating = calculateAverageRating(memberRating.ratings.map(r => r.selfRating));
        const avgSupervisorRating = calculateAverageRating(memberRating.ratings.map(r => r.supervisorRating));
        return {
          ...member,
          avgSelfRating,
          avgSupervisorRating,
          lastRatingUpdate: memberRating.submittedAt
        };
      }
      return {
        ...member,
        avgSelfRating: undefined,
        avgSupervisorRating: undefined,
        lastRatingUpdate: undefined
      };
    });

    setFilteredMembers(filteredWithRatings);
  };

  // Re-apply filters when criteria change
  useEffect(() => {
    applyFilters();
  }, [searchTerm, selectedDepartment, selectedStatus, employeeRatings]);

  // Poll for new ratings more frequently
  useEffect(() => {
    const checkForNewRatings = () => {
      const sessionRating = sessionStorage.getItem('submittedRatings');
      if (sessionRating) {
        console.log('Found new rating in sessionStorage, processing...');
        const ratings = loadAllRatings();
        setEmployeeRatings(ratings);
        applyFilters(ratings);
      }
    };

    // Check immediately and then every 500ms
    checkForNewRatings();
    const interval = setInterval(checkForNewRatings, 500);

    return () => clearInterval(interval);
  }, [loadAllRatings]);

  // Handle visibility changes and storage events
  useEffect(() => {
    // Function to reload ratings when tab becomes visible or storage changes
    const handleReloadRatings = () => {
      console.log('Reloading ratings due to visibility/storage change');
      const ratings = loadAllRatings();
      setEmployeeRatings(ratings);
      applyFilters(ratings);
    };

    // Listen for tab visibility changes
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        handleReloadRatings();
      }
    };

    // Listen for storage changes (from other tabs)
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'employeeRatings' || e.key === 'submittedRatings') {
        handleReloadRatings();
      }
    };

    // Add focus event listener as well for better reliability
    const handleFocus = () => {
      handleReloadRatings();
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('focus', handleFocus);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('focus', handleFocus);
    };
  }, [loadAllRatings]);

  const convertToAssignKRAEmployee = (member: TeamMember): AssignKRAEmployee => {
    return {
      id: parseInt(member.id),
      name: member.name,
      position: member.position,
      employeeId: member.employeeId,
      department: member.department,
      location: member.location,
      experience: member.experience,
      kraStatus: member.kraStatus,
      avatar: member.initials,
      reportingManager: 'John Doe'
    };
  };

  const getExistingKRAs = (employeeId: string): KRAData[] => {
    const member = teamMembersData.find(m => m.employeeId === employeeId);
    if (member && member.kraStatus !== 'Not Assigned') {
      return [
        {
          id: 1,
          title: 'Cloud Infrastructure Management',
          description: 'Manage and optimize cloud infrastructure services to ensure high availability and performance',
          target: 'Achieve 99.9% uptime for all cloud services',
          weightage: '30'
        },
        {
          id: 2,
          title: 'Team Collaboration',
          description: 'Lead team initiatives and cross-functional collaboration to improve project delivery',
          target: 'Complete 2 major cross-team projects successfully',
          weightage: '25'
        },
        {
          id: 3,
          title: 'Process Improvement',
          description: 'Identify bottlenecks and implement process improvements to increase efficiency',
          target: 'Reduce deployment time by 20% and increase automation coverage to 80%',
          weightage: '25'
        },
        {
          id: 4,
          title: 'Innovation & Learning',
          description: 'Stay updated with latest technologies and implement innovative solutions',
          target: 'Complete 2 technical certifications and implement 1 new technology stack',
          weightage: '20'
        }
      ];
    }
    return [];
  };

  const handleAssignKRA = (member: TeamMember) => {
    const convertedEmployee = convertToAssignKRAEmployee(member);
    setAssigningEmployee(convertedEmployee);
    setExistingKRAs([]);
    setIsEditingKRAs(false);
    setShowKRAAssignment(true);
  };

  const handleEditKRAs = (member: TeamMember) => {
    const convertedEmployee = convertToAssignKRAEmployee(member);
    setAssigningEmployee(convertedEmployee);
    const memberKRAs = getExistingKRAs(member.employeeId);
    setExistingKRAs(memberKRAs);
    setIsEditingKRAs(true);
    setShowKRAAssignment(true);
  };

  const handleBackToList = () => {
    setShowKRAAssignment(false);
    setAssigningEmployee(null);
    setExistingKRAs([]);
    setIsEditingKRAs(false);
  };

  const handleEditEmployee = (member: TeamMember) => {
    setSelectedMember(member);
    setIsEditModalOpen(true);
  };

  const handleViewEmployee = (member: TeamMember) => {
    router.push(`/home/view/${member.employeeId}`);
  };

  const handleSaveEmployee = (updatedEmployee: TeamMember) => {
    const updatedMembers = filteredMembers.map(member =>
      member.id === updatedEmployee.id ? updatedEmployee : member
    );
    setFilteredMembers(updatedMembers);
  };

  const handleSubmitKRAs = (kras: KRAData[]) => {
    if (!assigningEmployee) return;

    const updatedMembers = filteredMembers.map(member =>
      member.employeeId === assigningEmployee.employeeId
        ? { ...member, kraStatus: 'Assigned' as const }
        : member
    );
    setFilteredMembers(updatedMembers);

    console.log('Saving KRAs for employee:', assigningEmployee.employeeId, kras);

    handleBackToList();

    alert(isEditingKRAs ? 'KRAs updated successfully!' : 'KRAs assigned successfully!');
  };

  const getRatingColor = (rating: number) => {
    if (rating >= 80) return 'text-green-600';
    if (rating >= 60) return 'text-blue-600';
    if (rating >= 40) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getRatingBackground = (rating: number) => {
    if (rating >= 80) return 'bg-green-50 border-green-200';
    if (rating >= 60) return 'bg-blue-50 border-blue-200';
    if (rating >= 40) return 'bg-yellow-50 border-yellow-200';
    return 'bg-red-50 border-red-200';
  };

  if (showKRAAssignment && assigningEmployee) {
    return (
      <AssignKRA
        employee={assigningEmployee}
        onBack={handleBackToList}
        onSubmit={handleSubmitKRAs}
        initialData={existingKRAs.length > 0 ? existingKRAs : undefined}
      />
    );
  }

  return (
    <>
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 max-w-6xl mx-auto">
        {onBackToMyKRAs && (
          <div className="mb-6">
            <button
              onClick={onBackToMyKRAs}
              className="group flex items-center gap-3 px-4 py-3 text-gray-600 hover:text-white hover:bg-gradient-to-r hover:from-blue-500 hover:to-purple-600 rounded-xl transition-all duration-300 shadow-sm hover:shadow-lg transform hover:-translate-y-0.5 cursor-pointer"
            >
              <div className="p-1.5 bg-gray-100 group-hover:bg-white/20 rounded-lg transition-all duration-300">
                <svg
                  className="w-5 h-5 transform group-hover:-translate-x-1 transition-transform duration-300"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </div>
              <div>
                <span className="font-semibold text-sm">Back to My KRAs</span>
                <p className="text-xs opacity-75 group-hover:opacity-100">Return to your performance dashboard</p>
              </div>
            </button>
          </div>
        )}

        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Team KRA Management</h2>
          <p className="text-gray-600">Assign and monitor KRAs for your team members</p>
        </div>

        <div className="bg-gray-50 rounded-xl p-6 mb-6">
          <div className="mb-4">
            <div className="relative">
              <svg className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <input
                type="text"
                placeholder="Search employees..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <select
              value={selectedDepartment}
              onChange={(e) => setSelectedDepartment(e.target.value)}
              className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
            >
              {departments.map((dept) => (
                <option key={dept} value={dept}>{dept}</option>
              ))}
            </select>

            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
            >
              {statusOptions.map((status) => (
                <option key={status} value={status}>{status}</option>
              ))}
            </select>
          </div>

          <button
            onClick={() => applyFilters()}
            className="w-full bg-blue-500 hover:bg-blue-600 text-white py-3 px-6 rounded-lg transition-colors font-medium cursor-pointer"
          >
            Apply Filters
          </button>
        </div>

        <div className="space-y-4">
          {filteredMembers.map((member) => {
            console.log(`Rendering member ${member.employeeId}: kraStatus=${member.kraStatus}, avgSelfRating=${member.avgSelfRating}, avgSupervisorRating=${member.avgSupervisorRating}`);
            return (
              <div key={member.id} className="bg-white border border-gray-200 rounded-xl p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center text-white font-bold text-lg flex-shrink-0">
                    {member.initials}
                  </div>

                  <div className="flex-1">
                    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                      <div>
                        <h3 className="font-semibold text-gray-900 text-lg mb-1">{member.name}</h3>
                        <p className="text-gray-600 mb-1">{member.position}</p>
                        <p className="text-sm text-gray-500">{member.employeeId}</p>
                      </div>

                      <div className="space-y-3">
                        <div>
                          <p className="text-sm text-gray-500 mb-1">Department:</p>
                          <p className="text-gray-900 font-medium">{member.department}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-500 mb-1">Location:</p>
                          <p className="text-gray-700">{member.location}</p>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div>
                          <p className="text-sm text-gray-500 mb-1">Experience:</p>
                          <p className="text-gray-700">{member.experience}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-500 mb-1">KRA Status:</p>
                          {member.kraStatus === 'Not Assigned' && (
                            <span className="text-red-600 text-sm font-medium">{member.kraStatus}</span>
                          )}
                          {member.kraStatus === 'Assigned' && (
                            <span className="text-blue-600 text-sm font-medium">{member.kraStatus}</span>
                          )}
                          {member.kraStatus === 'In Progress' && (
                            <span className="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full text-sm font-medium">{member.kraStatus}</span>
                          )}
                        </div>
                      </div>

                      <div className="flex flex-col space-y-3">
                        {/* Performance Ratings Box - This will show for all employees with KRA assigned */}
                        {member.kraStatus !== 'Not Assigned' && (
                          <div className={`p-3 rounded-lg border ${getRatingBackground(member.avgSupervisorRating || 0)}`}>
                            <p className="text-xs font-semibold text-gray-700 mb-2 flex items-center gap-1">
                              <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                              </svg>
                              Performance Ratings
                            </p>
                            <div className="space-y-2">
                              <div className="flex justify-between items-center">
                                <span className="text-xs text-gray-600">Employee:</span>
                                <div className="flex items-center gap-2">
                                  <div className="w-12 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                                    <div 
                                      className={`h-full ${(member.avgSelfRating || 0) >= 80 ? 'bg-green-500' : (member.avgSelfRating || 0) >= 60 ? 'bg-blue-500' : (member.avgSelfRating || 0) >= 40 ? 'bg-yellow-500' : 'bg-red-500'}`}
                                      style={{ width: `${member.avgSelfRating || 0}%` }}
                                    ></div>
                                  </div>
                                  <span className={`text-xs font-bold ${getRatingColor(member.avgSelfRating || 0)}`}>
                                    {member.avgSelfRating || 0}
                                  </span>
                                </div>
                              </div>
                              <div className="flex justify-between items-center">
                                <span className="text-xs text-gray-600">Supervisor:</span>
                                <div className="flex items-center gap-2">
                                  <div className="w-12 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                                    <div 
                                      className={`h-full ${(member.avgSupervisorRating || 0) >= 80 ? 'bg-green-500' : (member.avgSupervisorRating || 0) >= 60 ? 'bg-blue-500' : (member.avgSupervisorRating || 0) >= 40 ? 'bg-yellow-500' : 'bg-red-500'}`}
                                      style={{ width: `${member.avgSupervisorRating || 0}%` }}
                                    ></div>
                                  </div>
                                  <span className={`text-xs font-bold ${getRatingColor(member.avgSupervisorRating || 0)}`}>
                                    {member.avgSupervisorRating || 0}
                                  </span>
                                </div>
                              </div>
                            </div>
                            {member.lastRatingUpdate && (
                              <p className="text-xs text-gray-500 mt-2 flex items-center gap-1">
                                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                                Updated: {new Date(member.lastRatingUpdate).toLocaleDateString()}
                              </p>
                            )}
                          </div>
                        )}

                        {/* Buttons */}
                        {member.kraStatus === 'Not Assigned' ? (
                          <button
                            onClick={() => handleAssignKRA(member)}
                            className="w-full bg-green-500 hover:bg-green-600 text-white py-2.5 px-4 rounded-lg transition-colors flex items-center justify-center gap-2 font-medium cursor-pointer"
                          >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                            </svg>
                            Assign KRAs
                          </button>
                        ) : (
                          <div className="flex gap-2 w-full">
                            <button
                              onClick={() => handleEditKRAs(member)}
                              className="flex-1 bg-blue-100 hover:bg-blue-200 text-blue-700 py-2.5 px-4 rounded-lg transition-colors flex items-center justify-center gap-1 font-medium cursor-pointer"
                            >
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                              </svg>
                              Edit
                            </button>
                            <button
                              onClick={() => handleViewEmployee(member)}
                              className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-2.5 px-4 rounded-lg transition-colors flex items-center justify-center gap-1 font-medium cursor-pointer"
                            >
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                              </svg>
                              View
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {selectedMember && (
        <EditEmployeeModal
          isOpen={isEditModalOpen}
          onClose={() => {
            setIsEditModalOpen(false);
            setSelectedMember(null);
          }}
          employee={selectedMember}
          onSave={handleSaveEmployee}
        />
      )}
    </>
  );
};

export default TeamKRAs;