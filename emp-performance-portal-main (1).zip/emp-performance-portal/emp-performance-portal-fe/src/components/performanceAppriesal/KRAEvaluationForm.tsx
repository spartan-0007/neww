"use client";

import React, { useState, useEffect } from 'react';
import type { KRA } from '@/data/krasampledata';

interface KRAEvaluationFormProps {
  kras: KRA[];
  onBackToList: () => void;
  onSaveEvaluation: (kraId: number, score: number, comments: string) => void;
}

// Get priority based on weightage
const getPriority = (weightage: number): string => {
  if (weightage >= 20) return 'HIGH';
  if (weightage >= 15) return 'MEDIUM';
  return 'LOW';
};

// Priority colors mapping
const priorityColors: Record<string, { bg: string; text: string }> = {
  HIGH: { bg: 'bg-red-100', text: 'text-red-700' },
  MEDIUM: { bg: 'bg-yellow-100', text: 'text-yellow-700' },
  LOW: { bg: 'bg-green-100', text: 'text-green-700' },
};

const KRAEvaluationForm: React.FC<KRAEvaluationFormProps> = ({ 
  kras, 
  onBackToList, 
  onSaveEvaluation 
}) => {
  const [currentKRAIndex, setCurrentKRAIndex] = useState(0);
  const [formData, setFormData] = useState<{ [key: number]: { score: number; comments: string } }>({});

  // Filter out SELF category
  const kraList = kras.filter(kra => kra.category !== 'SELF');
  const currentKRA = kraList[currentKRAIndex];
  const priority = getPriority(currentKRA.weightage);
  const priorityColor = priorityColors[priority];

  // Initialize form data from existing KRA data
  useEffect(() => {
    const initialData: { [key: number]: { score: number; comments: string } } = {};
    kraList.forEach(kra => {
      initialData[kra.id] = {
        score: kra.selfRating || 0,
        comments: kra.achievementComments || ''
      };
    });
    setFormData(initialData);
  }, [kraList]);

  const handleScoreChange = (score: number) => {
    const newFormData = {
      ...formData,
      [currentKRA.id]: {
        ...formData[currentKRA.id],
        score: score
      }
    };
    setFormData(newFormData);
    onSaveEvaluation(currentKRA.id, score, formData[currentKRA.id]?.comments || '');
  };

  const handleCommentsChange = (comments: string) => {
    const newFormData = {
      ...formData,
      [currentKRA.id]: {
        ...formData[currentKRA.id],
        comments: comments
      }
    };
    setFormData(newFormData);
    onSaveEvaluation(currentKRA.id, formData[currentKRA.id]?.score || 0, comments);
  };

  const handleNext = () => {
    if (currentKRAIndex < kraList.length - 1) {
      setCurrentKRAIndex(prev => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (currentKRAIndex > 0) {
      setCurrentKRAIndex(prev => prev - 1);
    }
  };

  const currentFormData = formData[currentKRA.id] || { score: 0, comments: '' };

  return (
    <div className="p-6">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-xl shadow-sm">
          {/* Header */}
          <div className="p-6 border-b border-gray-100">
            <div className="flex justify-between items-center">
              <div>
                <h1 className="text-2xl font-bold text-gray-900 mb-2">Performance Evaluation</h1>
                <p className="text-gray-600">Rate your performance on each assigned KRA</p>
              </div>
              <div className="text-right">
                <div className="text-lg font-semibold text-gray-900">Total: 100%</div>
              </div>
            </div>
          </div>

          {/* Progress Indicator */}
          <div className="px-6 py-4 bg-gray-50 border-b border-gray-100">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">KRA {currentKRAIndex + 1} of {kraList.length}</span>
              <div className="flex gap-2">
                {kraList.map((kra, index) => (
                  <div 
                    key={kra.id}
                    className={`w-3 h-3 rounded-full ${
                      index === currentKRAIndex ? 'bg-blue-500' : 
                      formData[kra.id]?.score > 0 ? 'bg-green-500' : 'bg-gray-300'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* KRA Content */}
          <div className="p-6">
            {/* KRA Header */}
            <div className="mb-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold">{currentKRAIndex + 1}</span>
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg font-semibold text-gray-900">KRA {currentKRAIndex + 1}</span>
                    <span className={`px-2 py-1 text-xs font-medium rounded ${priorityColor.bg} ${priorityColor.text}`}>
                      {priority}
                    </span>
                  </div>
                  <div className="text-sm text-gray-600">Weightage: {currentKRA.weightage}%</div>
                </div>
              </div>

              {/* KRA Title */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">KRA Title</label>
                <div className="p-3 bg-gray-50 border border-gray-200 rounded-lg">
                  <div className="text-gray-900">{currentKRA.title}</div>
                </div>
              </div>

              {/* Performance Target */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">Performance Target</label>
                <div className="p-3 bg-gray-50 border border-gray-200 rounded-lg">
                  <div className="text-gray-900">{currentKRA.targetValue}</div>
                </div>
              </div>
            </div>

            {/* Self-Assessment Section */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
              <div className="flex items-center gap-2 mb-4">
                <span className="text-blue-600 text-lg">🔒</span>
                <h3 className="text-lg font-semibold text-gray-900">Self-Assessment</h3>
              </div>

              {/* Score Input */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Score (0-100) <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={currentFormData.score || ''}
                    onChange={(e) => handleScoreChange(parseInt(e.target.value) || 0)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="0"
                  />
                  <span className="absolute right-3 top-3 text-gray-400">/100</span>
                </div>
              </div>

              {/* Achievement Comments */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Achievement Comments <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={currentFormData.comments}
                  onChange={(e) => handleCommentsChange(e.target.value)}
                  placeholder="Describe your key achievements..."
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 min-h-[120px] resize-none"
                />
              </div>
            </div>

            {/* Navigation Buttons */}
            <div className="flex justify-between items-center">
              <button 
                onClick={onBackToList}
                className="px-6 py-2 text-gray-600 hover:text-gray-900 font-medium"
              >
                ← Back to List
              </button>
              
              <div className="flex gap-3">
                <button 
                  onClick={handlePrevious}
                  disabled={currentKRAIndex === 0}
                  className="px-6 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Previous
                </button>
                {currentKRAIndex === kraList.length - 1 ? (
                  <button 
                    onClick={onBackToList}
                    className="px-6 py-2 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700"
                  >
                    Complete Assessment
                  </button>
                ) : (
                  <button 
                    onClick={handleNext}
                    className="px-6 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700"
                  >
                    Next KRA
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default KRAEvaluationForm;