"use client";

import React, { useState } from 'react';
import type { PerformanceData, KRA } from '@/data/krasampledata';

interface SelfAssessmentFormProps {
  data: PerformanceData;
  onSaveAssessment?: (updatedKras: KRA[]) => void;
  onBack?: () => void;
}

// Tab types
type TabType = 'kra' | 'behavioral';

// Behavioral Competency interface
interface BehavioralCompetency {
  id: number;
  title: string;
  description: string;
  category: string;
  selfRating: number;
  comments: string;
}

// Category colors mapping
const categoryColors: Record<string, { bg: string; text: string; border: string }> = {
  SELF: { bg: 'bg-indigo-50', text: 'text-indigo-600', border: 'border-indigo-200' },
  CLOUD: { bg: 'bg-red-50', text: 'text-red-600', border: 'border-red-200' },
  TEAM: { bg: 'bg-yellow-50', text: 'text-yellow-600', border: 'border-yellow-200' },
  EFFICIENCY: { bg: 'bg-orange-50', text: 'text-orange-600', border: 'border-orange-200' },
  INNOVATION: { bg: 'bg-green-50', text: 'text-green-600', border: 'border-green-200' },
  STAKEHOLDER: { bg: 'bg-purple-50', text: 'text-purple-600', border: 'border-purple-200' },
  MANDATORY: { bg: 'bg-pink-50', text: 'text-pink-600', border: 'border-pink-200' },
  MEDIUM: { bg: 'bg-teal-50', text: 'text-teal-600', border: 'border-teal-200' },
};

// Priority colors mapping based on weightage
const getPriorityColor = (weightage: number) => {
  if (weightage >= 20) return { bg: 'bg-red-100', text: 'text-red-700', label: 'HIGH' };
  if (weightage >= 15) return { bg: 'bg-yellow-100', text: 'text-yellow-700', label: 'MEDIUM' };
  return { bg: 'bg-green-100', text: 'text-green-700', label: 'LOW' };
};

const SelfAssessmentForm: React.FC<SelfAssessmentFormProps> = ({ 
  data, 
  onSaveAssessment,
  onBack 
}) => {
  // Add safety checks for data and data.kras
  if (!data) {
    return (
      <div className="p-6">
        <div className="max-w-6xl mx-auto">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="text-center">
              <h2 className="text-xl font-semibold text-gray-900 mb-2">No Data Available</h2>
              <p className="text-gray-600">Performance data is not available.</p>
              {onBack && (
                <button 
                  onClick={onBack}
                  className="mt-4 text-blue-600 hover:text-blue-800 text-sm font-medium cursor-pointer"
                >
                  ← Back to Overview
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Initialize state with current KRA data - add safety check
  const [kras, setKras] = useState<KRA[]>(data?.kras || []);

  const [activeTab, setActiveTab] = useState<TabType>('kra');
  
  // Sample behavioral competencies data
  const [behavioralCompetencies, setBehavioralCompetencies] = useState<BehavioralCompetency[]>([
    {
      id: 1,
      title: "Communication Skills",
      description: "Ability to convey information clearly and effectively through various channels, actively listen to others, and adapt communication style to different audiences.",
      category: "CORE",
      selfRating: 0,
      comments: ""
    },
    {
      id: 2,
      title: "Problem Solving",
      description: "Capability to identify issues, analyze root causes, develop creative solutions, and implement effective resolutions in a timely manner.",
      category: "TECHNICAL",
      selfRating: 0,
      comments: ""
    },
    {
      id: 3,
      title: "Teamwork & Collaboration",
      description: "Working effectively with others, sharing knowledge, supporting team goals, and contributing to a positive team environment.",
      category: "INTERPERSONAL",
      selfRating: 0,
      comments: ""
    },
    {
      id: 4,
      title: "Leadership & Initiative",
      description: "Taking ownership of tasks, guiding others when needed, making decisions confidently, and driving projects forward proactively.",
      category: "LEADERSHIP",
      selfRating: 0,
      comments: ""
    },
    {
      id: 5,
      title: "Adaptability",
      description: "Flexibility in handling change, learning new skills quickly, adjusting to new situations, and maintaining performance under pressure.",
      category: "CORE",
      selfRating: 0,
      comments: ""
    }
  ]);

  // Calculate progress - exclude SELF category
  const actualKras = kras.filter(kra => kra.category !== 'SELF');
  const completedKras = actualKras.filter(kra => 
    kra.selfRating > 0 && kra.achievementComments?.trim().length > 0
  ).length;
  const totalKras = actualKras.length;
  const progressPercent = totalKras > 0 ? Math.round((completedKras / totalKras) * 100) : 0;

  // Update KRA rating
  const updateKraRating = (kraId: number, rating: number) => {
    setKras(prevKras => 
      prevKras.map(kra => 
        kra.id === kraId 
          ? { ...kra, selfRating: rating, status: rating > 0 ? 'IN_PROGRESS' : 'PENDING_SELF_RATING' }
          : kra
      )
    );
  };

  // Update KRA comments
  const updateKraComments = (kraId: number, comments: string) => {
    setKras(prevKras => 
      prevKras.map(kra => 
        kra.id === kraId 
          ? { ...kra, achievementComments: comments }
          : kra
      )
    );
  };

  // Update Behavioral Competency rating
  const updateBehavioralRating = (compId: number, rating: number) => {
    setBehavioralCompetencies(prevComps => 
      prevComps.map(comp => 
        comp.id === compId 
          ? { ...comp, selfRating: rating }
          : comp
      )
    );
  };

  // Update Behavioral Competency comments
  const updateBehavioralComments = (compId: number, comments: string) => {
    setBehavioralCompetencies(prevComps => 
      prevComps.map(comp => 
        comp.id === compId 
          ? { ...comp, comments: comments }
          : comp
      )
    );
  };

  // Handle save
  const handleSave = () => {
    if (onSaveAssessment) {
      onSaveAssessment(kras);
    }
  };

  // Handle submit assessment
  const handleSubmitAssessment = () => {
    // Update all KRAs to submitted status
    const submittedKras = kras.map(kra => ({
      ...kra,
      status: 'SUBMITTED_TO_SUPERVISOR' as const
    }));
    
    if (onSaveAssessment) {
      onSaveAssessment(submittedKras);
    }
    
    // Redirect back to overview
    if (onBack) {
      onBack();
    }
  };

  // Display all KRAs excluding SELF category
  const displayKras = kras.filter(kra => kra.category !== 'SELF');

  // Tab content components
  const renderKRAContent = () => (
    <div className="space-y-8">
      {displayKras.map((kra, index) => {
        const colors = categoryColors[kra.category] || categoryColors.SELF;
        const priority = getPriorityColor(kra.weightage || 0);
        
        return (
          <div key={kra.id} className={`border rounded-lg p-8 ${colors.bg} ${colors.border}`}>
            {/* KRA Header */}
            <div className="flex items-start gap-6 mb-6">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                kra.category === 'CLOUD' ? 'bg-red-500' : 
                kra.category === 'TEAM' ? 'bg-yellow-500' : 
                kra.category === 'EFFICIENCY' ? 'bg-orange-500' : 
                kra.category === 'INNOVATION' ? 'bg-green-500' : 
                kra.category === 'STAKEHOLDER' ? 'bg-purple-500' : 
                kra.category === 'SELF' ? 'bg-indigo-500' :
                kra.category === 'MANDATORY' ? 'bg-pink-500' :
                kra.category === 'MEDIUM' ? 'bg-teal-500' :
                'bg-blue-500'
              }`}>
                <span className="text-white text-sm font-bold">{index + 1}</span>
              </div>
              
              <div className="flex-1">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <span className={`inline-block px-3 py-1 rounded text-sm font-medium ${priority.bg} ${priority.text} mb-3`}>
                      {priority.label}
                    </span>
                    <h3 className="text-xl font-semibold text-gray-900">{kra.title || 'Untitled KRA'}</h3>
                  </div>
                  <div className="text-right">
                    <span className="text-2xl font-bold text-gray-900">{kra.weightage || 0}%</span>
                    <p className="text-sm text-gray-500">Weightage</p>
                  </div>
                </div>
              </div>
            </div>

            {/* KRA Title Section */}
            <div className="mb-6">
              <h4 className="text-base font-medium text-gray-700 mb-3">KRA Title</h4>
              <div className="rounded-lg p-4">
                <p className="text-gray-900 text-base">{kra.title || 'Untitled KRA'}</p>
              </div>
            </div>

            {/* Performance Target */}
            <div className="mb-6">
              <h4 className="text-base font-medium text-gray-700 mb-3">Performance Target</h4>
              <div className="rounded-lg p-4">
                <p className="text-gray-700 text-base leading-relaxed">{kra.description || 'No description available'}</p>
              </div>
            </div>

            {/* Self Assessment Section */}
            <div className="bg-blue-50 rounded-lg p-6 mb-6 border border-blue-200">
              <h4 className="text-base font-medium text-blue-800 mb-4">Self-Assessment</h4>
              
              {/* Score Input */}
              <div className="mb-6">
                <label className="block text-base font-medium text-gray-700 mb-3">
                  Score (0-100) *
                </label>
                <div className="flex items-center gap-6">
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={kra.selfRating || ''}
                    onChange={(e) => updateKraRating(kra.id, parseInt(e.target.value) || 0)}
                    className="w-32 p-3 text-lg border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white"
                    placeholder="0"
                  />
                  <div className="text-right flex-1">
                    <span className="text-base text-gray-500">/100</span>
                  </div>
                </div>
              </div>

              {/* Achievement Comments */}
              <div>
                <label className="block text-base font-medium text-gray-700 mb-3">
                  Achievement Comments *
                </label>
                <textarea
                  value={kra.achievementComments || ''}
                  onChange={(e) => updateKraComments(kra.id, e.target.value)}
                  placeholder="Describe your key achievements..."
                  rows={5}
                  className="w-full p-4 text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none bg-white"
                />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );

  const renderBehavioralContent = () => (
    <div className="space-y-8">
      {behavioralCompetencies.map((competency, index) => {
        const categoryColors = {
          CORE: { bg: 'bg-blue-50', border: 'border-blue-200', color: 'bg-blue-500' },
          TECHNICAL: { bg: 'bg-green-50', border: 'border-green-200', color: 'bg-green-500' },
          INTERPERSONAL: { bg: 'bg-purple-50', border: 'border-purple-200', color: 'bg-purple-500' },
          LEADERSHIP: { bg: 'bg-orange-50', border: 'border-orange-200', color: 'bg-orange-500' }
        };
        
        const colors = categoryColors[competency.category as keyof typeof categoryColors] || categoryColors.CORE;
        
        return (
          <div key={competency.id} className={`border rounded-lg p-8 ${colors.bg} ${colors.border}`}>
            {/* Competency Header */}
            <div className="flex items-start gap-6 mb-6">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${colors.color}`}>
                <span className="text-white text-sm font-bold">{index + 1}</span>
              </div>
              
              <div className="flex-1">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <span className={`inline-block px-3 py-1 rounded text-sm font-medium mb-3 ${
                      competency.category === 'CORE' ? 'bg-blue-100 text-blue-700' :
                      competency.category === 'TECHNICAL' ? 'bg-green-100 text-green-700' :
                      competency.category === 'INTERPERSONAL' ? 'bg-purple-100 text-purple-700' :
                      competency.category === 'LEADERSHIP' ? 'bg-orange-100 text-orange-700' :
                      'bg-gray-100 text-gray-700'
                    }`}>
                      {competency.category}
                    </span>
                    <h3 className="text-xl font-semibold text-gray-900">{competency.title}</h3>
                  </div>
                </div>
              </div>
            </div>

            {/* Competency Description */}
            <div className="mb-6">
              <h4 className="text-base font-medium text-gray-700 mb-3">Competency Description</h4>
              <div className="rounded-lg p-4">
                <p className="text-gray-700 text-base leading-relaxed">{competency.description}</p>
              </div>
            </div>

            {/* Self Assessment Section */}
            <div className="bg-indigo-50 rounded-lg p-6 mb-6 border border-indigo-200">
              <h4 className="text-base font-medium text-indigo-800 mb-4">Self-Assessment</h4>
              
              {/* Rating Scale Info */}
              <div className="mb-4 p-3 bg-white rounded border border-indigo-100">
                <p className="text-sm text-gray-600 mb-2"><strong>Rating Scale:</strong></p>
                <div className="grid grid-cols-1 md:grid-cols-5 gap-2 text-xs">
                  <span className="text-red-600">1-2: Needs Development</span>
                  <span className="text-orange-600">3-4: Below Expectations</span>
                  <span className="text-yellow-600">5-6: Meets Expectations</span>
                  <span className="text-blue-600">7-8: Exceeds Expectations</span>
                  <span className="text-green-600">9-10: Outstanding</span>
                </div>
              </div>

              {/* Score Input */}
              <div className="mb-6">
                <label className="block text-base font-medium text-gray-700 mb-3">
                  Rating (1-10) *
                </label>
                <div className="flex items-center gap-6">
                  <input
                    type="number"
                    min="1"
                    max="10"
                    value={competency.selfRating || ''}
                    onChange={(e) => updateBehavioralRating(competency.id, parseInt(e.target.value) || 0)}
                    className="w-32 p-3 text-lg border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white"
                    placeholder="1-10"
                  />
                  <div className="text-right flex-1">
                    <span className="text-base text-gray-500">/10</span>
                    {competency.selfRating > 0 && (
                      <div className="mt-1">
                        <span className={`text-sm font-medium px-2 py-1 rounded ${
                          competency.selfRating <= 2 ? 'bg-red-100 text-red-700' :
                          competency.selfRating <= 4 ? 'bg-orange-100 text-orange-700' :
                          competency.selfRating <= 6 ? 'bg-yellow-100 text-yellow-700' :
                          competency.selfRating <= 8 ? 'bg-blue-100 text-blue-700' :
                          'bg-green-100 text-green-700'
                        }`}>
                          {competency.selfRating <= 2 ? 'Needs Development' :
                           competency.selfRating <= 4 ? 'Below Expectations' :
                           competency.selfRating <= 6 ? 'Meets Expectations' :
                           competency.selfRating <= 8 ? 'Exceeds Expectations' :
                           'Outstanding'}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Comments */}
              <div>
                <label className="block text-base font-medium text-gray-700 mb-3">
                  Self-Assessment Comments *
                </label>
                <textarea
                  value={competency.comments || ''}
                  onChange={(e) => updateBehavioralComments(competency.id, e.target.value)}
                  placeholder="Provide specific examples of how you demonstrate this competency..."
                  rows={4}
                  className="w-full p-4 text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 resize-none bg-white"
                />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );

  return (
    <div className="p-6">
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-xl shadow-sm">
          {/* Header */}
          <div className="p-8 border-b border-gray-100">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">Self Assessment</h1>
                <p className="text-gray-600 text-lg">Rate your performance on each assigned KRA</p>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold text-green-600">{progressPercent}%</div>
                <div className="text-sm text-gray-500">Total: 100%</div>
              </div>
            </div>
            
            {onBack && (
              <button 
                onClick={onBack}
                className="text-blue-600 hover:text-blue-800 text-sm font-medium cursor-pointer"
              >
                ← Back to Overview
              </button>
            )}

            {/* Tab Navigation */}
            <div className="mt-6">
              <nav className="flex space-x-1 bg-gray-100 p-1 rounded-lg">
                <button
                  onClick={() => setActiveTab('kra')}
                  className={`flex-1 px-4 py-3 text-sm font-medium rounded-md transition-all duration-200 cursor-pointer ${
                    activeTab === 'kra'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-gray-600 hover:text-gray-800 hover:bg-gray-200'
                  }`}
                >
                  Key Result Areas
                </button>
                <button
                  onClick={() => setActiveTab('behavioral')}
                  className={`flex-1 px-4 py-3 text-sm font-medium rounded-md transition-all duration-200 cursor-pointer ${
                    activeTab === 'behavioral'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-gray-600 hover:text-gray-800 hover:bg-gray-200'
                  }`}
                >
                  Behavioral Competencies
                </button>
              </nav>
            </div>
          </div>

          {/* Content */}
          <div className="p-8">
            {activeTab === 'kra' && renderKRAContent()}
            {activeTab === 'behavioral' && renderBehavioralContent()}

            {/* Bottom Actions - Show for both tabs */}
            {(activeTab === 'kra' || activeTab === 'behavioral') && (
              <div className="mt-12 flex justify-between items-center bg-gray-50 p-6 rounded-lg">
                <div>
                  {activeTab === 'kra' ? (
                    <p className="text-base text-gray-600 font-medium">
                      Progress: {completedKras}/{totalKras} KRAs completed
                    </p>
                  ) : (
                    <p className="text-base text-gray-600 font-medium">
                      Progress: {behavioralCompetencies.filter(comp => comp.selfRating > 0 && comp.comments.trim().length > 0).length}/{behavioralCompetencies.length} Competencies completed
                    </p>
                  )}
                </div>
                <div className="flex gap-4">
                  <button 
                    onClick={handleSave}
                    className="px-8 py-3 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 text-base cursor-pointer"
                  >
                    Save Draft
                  </button>
                  <button 
                    onClick={handleSubmitAssessment}
                    disabled={activeTab === 'kra' ? completedKras < totalKras : behavioralCompetencies.some(comp => comp.selfRating === 0 || comp.comments.trim().length === 0)}
                    className={`px-8 py-3 rounded-lg font-medium text-base ${
                      (activeTab === 'kra' ? completedKras >= totalKras : behavioralCompetencies.every(comp => comp.selfRating > 0 && comp.comments.trim().length > 0))
                        ? 'bg-green-600 text-white hover:bg-green-700 cursor-pointer'
                        : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    }`}
                  >
                    Submit Assessment
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SelfAssessmentForm;