"use client";

import React, { useState } from 'react';
import type { PerformanceData, KRA } from '@/data/krasampledata';
import SelfAssessmentForm from '@/components/performanceAppriesal/selAssessmentForm';

interface MainPerformanceComponentProps {
  data: PerformanceData;
  onBack?: () => void;
}

// Category colors mapping
const categoryColors: Record<string, { bg: string; text: string; border: string }> = {
  SELF: { bg: 'bg-indigo-50', text: 'text-indigo-600', border: 'border-indigo-200' },
  CLOUD: { bg: 'bg-red-50', text: 'text-red-600', border: 'border-red-200' },
  TEAM: { bg: 'bg-yellow-50', text: 'text-yellow-600', border: 'border-yellow-200' },
  EFFICIENCY: { bg: 'bg-orange-50', text: 'text-orange-600', border: 'border-orange-200' },
  INNOVATION: { bg: 'bg-green-50', text: 'text-green-600', border: 'border-green-200' },
  STAKEHOLDER: { bg: 'bg-purple-50', text: 'text-purple-600', border: 'border-purple-200' },
  MANDATORY: { bg: 'bg-pink-50', text: 'text-pink-600', border: 'border-pink-200' },
  MEDIUM: { bg: 'bg-teal-50', text: 'text-teal-600', border: 'border-teal-200' },
};

// Priority colors mapping
const priorityColors: Record<string, { bg: string; text: string }> = {
  HIGH: { bg: 'bg-red-100', text: 'text-red-700' },
  MEDIUM: { bg: 'bg-yellow-100', text: 'text-yellow-700' },
  LOW: { bg: 'bg-green-100', text: 'text-green-700' },
};

// Get priority based on weightage
const getPriority = (weightage: number): string => {
  if (weightage >= 20) return 'HIGH';
  if (weightage >= 15) return 'MEDIUM';
  return 'LOW';
};

const MainPerformanceComponent: React.FC<MainPerformanceComponentProps> = ({ data, onBack }) => {
  const [currentView, setCurrentView] = useState<'overview' | 'assessment'>('overview');
  const [performanceData, setPerformanceData] = useState<PerformanceData>(data);

  // Handle beginning assessment
  const handleBeginAssessment = () => {
    setCurrentView('assessment');
  };

  // Handle going back to overview
  const handleBackToOverview = () => {
    setCurrentView('overview');
  };

  // Handle saving assessment
  const handleSaveAssessment = (updatedKras: KRA[]) => {
    setPerformanceData(prev => ({
      ...prev,
      kras: updatedKras
    }));
    console.log('Assessment saved:', updatedKras);
  };

  // Show assessment form
  if (currentView === 'assessment') {
    return (
      <SelfAssessmentForm 
        data={performanceData}
        onSaveAssessment={handleSaveAssessment}
        onBack={handleBackToOverview}
      />
    );
  }

  // Safety checks for overview
  if (!performanceData || !performanceData.kras || !Array.isArray(performanceData.kras)) {
    return (
      <div className="p-6">
        <div className="max-w-6xl mx-auto">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="text-center">
              <h2 className="text-xl font-semibold text-gray-900 mb-2">No Data Available</h2>
              <p className="text-gray-600">Please check your data configuration.</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Separate SELF guidelines from actual KRAs
  const selfGuidelines = performanceData.kras.find(kra => kra.category === 'SELF');
  const kraList = performanceData.kras.filter(kra => kra.category !== 'SELF');
  
  // Updated status logic to match your data structure
  const completedCount = kraList.filter(kra => 
    kra.status === 'COMPLETED' || 
    kra.status === 'IN_PROGRESS' || 
    (kra.selfRating && kra.selfRating > 0)
  ).length;
  
  const submittedCount = kraList.filter(kra => kra.status === 'COMPLETED').length;
  const allSubmitted = kraList.length > 0 && submittedCount === kraList.length;

  return (
    <div className="p-6">
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-xl shadow-sm">
          {/* Header */}
          <div className="p-6 border-b border-gray-100">
            <div className="flex justify-between items-center">
              <div>
                {onBack && (
                  <button 
                    onClick={onBack}
                    className="text-blue-600 hover:text-blue-800 text-sm font-medium cursor-pointer mb-4"
                  >
                    ← Back to Dashboard
                  </button>
                )}
                <h1 className="text-2xl font-bold text-gray-900 mb-2">Performance Appraisal</h1>
                <p className="text-gray-600">{performanceData.fiscalYear || 'N/A'} • Review Period: {performanceData.reviewPeriod || 'N/A'}</p>
              </div>
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 cursor-pointer">
                View Progress
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="p-6">
            {/* Key Result Areas Header */}
            <div className="mb-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-2">Key Result Areas</h2>
              {allSubmitted ? (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                      <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <div>
                      <p className="text-green-800 font-medium">Assessment Submitted Successfully!</p>
                      <p className="text-green-700 text-sm">Your KRAs have been assigned to your supervisor for review.</p>
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-gray-600 text-sm">Complete your self-assessment for each KRA</p>
              )}
              <div className="flex items-center justify-between mt-4">
                <div className="text-sm text-gray-500">
                  {allSubmitted 
                    ? `All ${kraList.length} KRAs submitted to supervisor` 
                    : `Progress: ${completedCount}/${kraList.length} completed`
                  }
                </div>
                {!allSubmitted && (
                  <button 
                    onClick={handleBeginAssessment}
                    className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm hover:bg-gray-200 cursor-pointer"
                  >
                    Start Self-Assessment
                  </button>
                )}
              </div>
            </div>

            {/* KRA List */}
            <div className="space-y-4">
              {/* Self Assessment Guidelines - if exists */}
              {selfGuidelines && (
                <div className={`border rounded-lg p-4 ${categoryColors.SELF.bg} ${categoryColors.SELF.border}`}>
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 bg-indigo-500">
                      <span className="text-white text-sm">📋</span>
                    </div>
                    <div className="flex-1">
                      <h3 className="text-base font-medium text-gray-900 mb-2">{selfGuidelines.title || 'Self Assessment Guidelines'}</h3>
                      <p className="text-sm text-gray-600">{selfGuidelines.description || 'Guidelines for completing your self-assessment'}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Actual KRAs */}
              {kraList.map((kra, index) => {
                const colors = categoryColors[kra.category] || categoryColors.SELF;
                const priority = getPriority(kra.weightage || 0);
                const priorityColor = priorityColors[priority];
                const isCompleted = kra.status === 'COMPLETED' || kra.status === 'IN_PROGRESS' || (kra.selfRating && kra.selfRating > 0);
                const isSubmitted = kra.status === 'COMPLETED';
                
                return (
                  <div key={kra.id} className={`border rounded-lg p-4 ${colors.bg} ${colors.border} ${isSubmitted ? 'opacity-75' : ''}`}>
                    <div className="flex items-start gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                        kra.category === 'CLOUD' ? 'bg-red-500' : 
                        kra.category === 'TEAM' ? 'bg-yellow-500' : 
                        kra.category === 'EFFICIENCY' ? 'bg-orange-500' : 
                        kra.category === 'INNOVATION' ? 'bg-green-500' : 
                        kra.category === 'STAKEHOLDER' ? 'bg-purple-500' : 
                        kra.category === 'SELF' ? 'bg-indigo-500' :
                        kra.category === 'MANDATORY' ? 'bg-pink-500' :
                        kra.category === 'MEDIUM' ? 'bg-teal-500' :
                        'bg-blue-500'
                      }`}>
                        <span className="text-white text-sm font-bold">{index + 1}</span>
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="text-base font-medium text-gray-900">{kra.title || 'Untitled KRA'}</h3>
                          <div className="text-right">
                            <span className="text-2xl font-bold text-gray-900">{kra.weightage || 0}%</span>
                            <p className="text-xs text-gray-500">Weightage</p>
                          </div>
                        </div>
                        
                        <p className="text-sm text-gray-600 mb-2">{kra.description || 'No description available'}</p>
                        <p className="text-xs text-gray-500 mb-3"><strong>Target:</strong> {kra.targetValue || 'No target specified'}</p>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4 text-sm">
                            <span className={`px-2 py-1 rounded font-medium ${priorityColor.bg} ${priorityColor.text}`}>
                              {priority}
                            </span>
                            {isSubmitted ? (
                              <span className="text-green-600 font-medium flex items-center gap-1">
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                                </svg>
                                Completed
                              </span>
                            ) : (
                              <span className={`${isCompleted ? 'text-blue-600 font-medium' : 'text-gray-500'}`}>
                                {kra.status === 'IN_PROGRESS' ? 'In Progress' : 
                                 kra.selfRating > 0 ? `Self-Rated: ${kra.selfRating}/100` : 
                                 'Pending Self-Assessment'}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Bottom Action */}
            {!allSubmitted && (
              <div className="mt-8 text-center">
                <button 
                  onClick={handleBeginAssessment}
                  className="px-8 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 cursor-pointer"
                >
                  Begin Self-Assessment
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MainPerformanceComponent;