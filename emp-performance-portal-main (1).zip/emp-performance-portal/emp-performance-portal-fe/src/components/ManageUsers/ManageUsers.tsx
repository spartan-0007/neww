import React, { useState } from 'react';

import EditEmployeeForm from '@/components/editEmployee/editEmployee';

interface Employee {
  id: string;
  name: string;
  email: string;
  position: string;
  department: string;
  employeeId: string;
  phone: string;
  joinDate: string;
  status: 'Active' | 'Inactive' | 'Notice Period';
  lastWorkingDay?: string;
  avatar?: string;
}

// Sample employee data
const sampleEmployees: Employee[] = [
  {
    id: '1',
    name: 'Raj Kumar',
    email: 'raj.kumar@iftas.com',
    position: 'Software Engineer',
    department: 'Technology',
    employeeId: '1002',
    phone: '+91 98765 43210',
    joinDate: '2023-01-15',
    status: 'Active'
  },
  {
    id: '2',
    name: 'Priya Sharma',
    email: 'priya.sharma@iftas.com',
    position: 'UI/UX Designer',
    department: 'Design',
    employeeId: '1003',
    phone: '+91 98765 43211',
    joinDate: '2023-03-20',
    status: 'Active'
  },
  {
    id: '3',
    name: 'Vikram Singh',
    email: 'vikram.singh@iftas.com',
    position: 'Business Analyst',
    department: 'Operations',
    employeeId: '1004',
    phone: '+91 98765 43212',
    joinDate: '2022-11-10',
    status: 'Active'
  },
  {
    id: '4',
    name: 'Anita Desai',
    email: 'anita.desai@iftas.com',
    position: 'HR Manager',
    department: 'Human Resources',
    employeeId: '1005',
    phone: '+91 98765 43213',
    joinDate: '2022-08-05',
    status: 'Inactive'
  },
  {
    id: '5',
    name: 'Rohit Gupta',
    email: 'rohit.gupta@iftas.com',
    position: 'DevOps Engineer',
    department: 'Technology',
    employeeId: '1006',
    phone: '+91 98765 43214',
    joinDate: '2023-05-12',
    status: 'Active'
  },
  {
    id: '6',
    name: 'Neha Agarwal',
    email: 'neha.agarwal@iftas.com',
    position: 'Marketing Specialist',
    department: 'Marketing',
    employeeId: '1007',
    phone: '+91 98765 43215',
    joinDate: '2023-02-28',
    status: 'Active'
  }
];

// Add Employee Form Component
const AddEmployeeForm: React.FC<{
  onBack: () => void;
  onSubmit: (employee: Omit<Employee, 'id'>) => void;
}> = ({ onBack, onSubmit }) => {
  const [formData, setFormData] = useState<Omit<Employee, 'id'>>({
    name: '',
    email: '',
    position: '',
    department: '',
    employeeId: '',
    phone: '',
    joinDate: '',
    status: 'Active'
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
 

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) newErrors.name = 'Full name is required';
    if (!formData.email.trim()) newErrors.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = 'Please enter a valid email';
    if (!formData.position.trim()) newErrors.position = 'Position is required';
    if (!formData.department) newErrors.department = 'Department is required';
    if (!formData.employeeId.trim()) newErrors.employeeId = 'Employee ID is required';
    if (!formData.phone.trim()) newErrors.phone = 'Phone number is required';
    if (!formData.joinDate) newErrors.joinDate = 'Join date is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validateForm()) {
      onSubmit(formData);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 max-w-4xl mx-auto">
      {/* Back Button */}
      <div className="mb-6">
        <button
          onClick={onBack}
          className="group flex items-center gap-3 px-4 py-3 text-gray-600 hover:text-white hover:bg-gradient-to-r hover:from-blue-500 hover:to-purple-600 rounded-xl transition-all duration-300 shadow-sm hover:shadow-lg transform hover:-translate-y-0.5"
        >
          <div className="p-1.5 bg-gray-100 group-hover:bg-white/20 rounded-lg transition-all duration-300">
            <svg 
              className="w-5 h-5 transform group-hover:-translate-x-1 transition-transform duration-300" 
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </div>
          <div>
            <span className="font-semibold text-sm">Back to Employee List</span>
            <p className="text-xs opacity-75 group-hover:opacity-100">Return to manage users</p>
          </div>
        </button>
      </div>

      {/* Header */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Add New Employee</h2>
        <p className="text-gray-600">Fill in the details below to add a new employee to the system</p>
      </div>

      {/* Form */}
      <div className="space-y-6">
        {/* Personal Information Section */}
        <div className="bg-gray-50 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <svg className="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
            </svg>
            Personal Information
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Full Name */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Full Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors ${
                  errors.name ? 'border-red-500 bg-red-50' : 'border-gray-300'
                }`}
                placeholder="Enter full name"
              />
              {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
            </div>

            {/* Employee ID */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Employee ID <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                name="employeeId"
                value={formData.employeeId}
                onChange={handleInputChange}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors ${
                  errors.employeeId ? 'border-red-500 bg-red-50' : 'border-gray-300'
                }`}
                placeholder="e.g., 1008"
              />
              {errors.employeeId && <p className="text-red-500 text-sm mt-1">{errors.employeeId}</p>}
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email Address <span className="text-red-500">*</span>
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors ${
                  errors.email ? 'border-red-500 bg-red-50' : 'border-gray-300'
                }`}
                placeholder="name@iftas.com"
              />
              {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
            </div>

            {/* Phone */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Phone Number <span className="text-red-500">*</span>
              </label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleInputChange}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors ${
                  errors.phone ? 'border-red-500 bg-red-50' : 'border-gray-300'
                }`}
                placeholder="+91 98765 43216"
              />
              {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone}</p>}
            </div>
          </div>
        </div>

        {/* Work Information Section */}
        <div className="bg-gray-50 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <svg className="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2-2v2m8 0V6a2 2 0 012 2v6a2 2 0 01-2 2H6a2 2 0 01-2-2V8a2 2 0 012-2V6" />
            </svg>
            Work Information
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Position */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Position <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                name="position"
                value={formData.position}
                onChange={handleInputChange}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors ${
                  errors.position ? 'border-red-500 bg-red-50' : 'border-gray-300'
                }`}
                placeholder="e.g., Software Engineer"
              />
              {errors.position && <p className="text-red-500 text-sm mt-1">{errors.position}</p>}
            </div>

            {/* Department */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Department <span className="text-red-500">*</span>
              </label>
              <select
                name="department"
                value={formData.department}
                onChange={handleInputChange}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors ${
                  errors.department ? 'border-red-500 bg-red-50' : 'border-gray-300'
                }`}
              >
                <option value="">Select Department</option>
                <option value="Technology">Technology</option>
                <option value="Design">Design</option>
                <option value="Operations">Operations</option>
                <option value="Human Resources">Human Resources</option>
                <option value="Marketing">Marketing</option>
                <option value="Finance">Finance</option>
                <option value="Sales">Sales</option>
              </select>
              {errors.department && <p className="text-red-500 text-sm mt-1">{errors.department}</p>}
            </div>

            {/* Join Date */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Join Date <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                name="joinDate"
                value={formData.joinDate}
                onChange={handleInputChange}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors ${
                  errors.joinDate ? 'border-red-500 bg-red-50' : 'border-gray-300'
                }`}
              />
              {errors.joinDate && <p className="text-red-500 text-sm mt-1">{errors.joinDate}</p>}
            </div>

            {/* Status */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Status <span className="text-red-500">*</span>
              </label>
              <select
                name="status"
                value={formData.status}
                onChange={handleInputChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors"
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-4 pt-6">
          <button
            onClick={onBack}
            className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 px-6 rounded-xl transition-colors font-medium"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            className="flex-1 bg-blue-500 hover:bg-blue-600 text-white py-3 px-6 rounded-xl transition-colors font-medium"
          >
            Add Employee
          </button>
        </div>
      </div>
    </div>
  );
};

const ManageUsers: React.FC = () => {
  const [employees, setEmployees] = useState<Employee[]>(sampleEmployees);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('All');
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [employeeToDelete, setEmployeeToDelete] = useState<Employee | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
   const [showEditForm, setShowEditForm] = useState(false);
  const departments = ['All', ...Array.from(new Set(employees.map(emp => emp.department)))];

  const filteredEmployees = employees.filter(employee => {
    const matchesSearch = employee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         employee.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         employee.employeeId.includes(searchTerm);
    const matchesDepartment = selectedDepartment === 'All' || employee.department === selectedDepartment;
    return matchesSearch && matchesDepartment;
  });

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const getStatusColor = (status: string) => {
    return status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';
  };

  const handleAddEmployee = () => {
    setShowAddForm(true);
  };

  const handleBackToList = () => {
    setShowAddForm(false);
  };

  const handleSubmitEmployee = (newEmployee: Omit<Employee, 'id'>) => {
    // Check if employee ID already exists
    if (employees.some(emp => emp.employeeId === newEmployee.employeeId)) {
      alert('Employee ID already exists. Please use a different ID.');
      return;
    }

    // Create new employee with generated ID
    const employeeToAdd: Employee = {
      ...newEmployee,
      id: Date.now().toString()
    };

    // Add to employees list
    setEmployees(prev => [...prev, employeeToAdd]);
    
    // Go back to list
    setShowAddForm(false);
    
    
  };

 
const handleEditEmployee = (employee: Employee) => {
  setSelectedEmployee(employee);
  setShowEditForm(true); // Show the edit form
};

// 3. Add function to close edit form
const handleCloseEdit = () => {
  setShowEditForm(false);
  setSelectedEmployee(null);
};

// 4. Add function to handle employee update
const handleUpdateEmployee = (updatedEmployee: Employee) => {
  setEmployees(prev => 
    prev.map(emp => 
      emp.id === updatedEmployee.id ? updatedEmployee : emp
    )
  );
  setShowEditForm(false);
  setSelectedEmployee(null);
};
if (showEditForm && selectedEmployee) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <EditEmployeeForm 
          employee={selectedEmployee}
          onBack={handleCloseEdit}
          onSubmit={handleUpdateEmployee}
        />
      </div>
    );
  }

 

  // Show Add Employee Form
  if (showAddForm) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <AddEmployeeForm 
          onBack={handleBackToList}
          onSubmit={handleSubmitEmployee}
        />
      </div>
    );
  }

  // Show Main Employee List
  return (
    

    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header Section */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Manage Users</h1>
        <p className="text-gray-600">Add, edit, and manage employee information</p>
      </div>

      {/* Action Buttons and Filters */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div className="flex gap-3">
          <button
            onClick={handleAddEmployee}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2 hover:bg-blue-100 transition-colors text-sm font-medium cursor-pointer"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
            </svg>
            Add Employee
          </button>
        </div>

        <div className="flex gap-4 w-full sm:w-auto">
          {/* Search */}
          <div className="relative flex-1 sm:w-64">
            <svg className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input
              type="text"
              placeholder="Search employees..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent w-full"
            />
          </div>

          {/* Department Filter */}
          <select
            value={selectedDepartment}
            onChange={(e) => setSelectedDepartment(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent hover:bg-blue-100 transition-colors text-sm font-medium cursor-pointer"
          >
            {departments.map(dept => (
              <option key={dept} value={dept}>{dept}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Employee List - Row by Row */}
      <div className="space-y-4">
        {filteredEmployees.map((employee) => (
          <div key={employee.id} className="bg-white rounded-lg shadow-md border border-gray-200 p-6 hover:shadow-lg transition-shadow ">
            <div className="flex items-center justify-between">
              {/* Left Section - Avatar and Basic Info */}
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold text-lg">
                  {getInitials(employee.name)}
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 text-lg">{employee.name}</h3>
                  <p className="text-sm text-gray-500">ID: {employee.employeeId}</p>
                </div>
              </div>

              {/* Middle Section - Employee Details */}
              <div className="flex-1 mx-8">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-xs text-gray-500 uppercase tracking-wide">Position</p>
                    <p className="text-sm font-medium text-gray-900">{employee.position}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 uppercase tracking-wide">Department</p>
                    <p className="text-sm font-medium text-gray-900">{employee.department}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 uppercase tracking-wide">Email</p>
                    <p className="text-sm font-medium text-gray-900 truncate">{employee.email}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 uppercase tracking-wide">Phone</p>
                    <p className="text-sm font-medium text-gray-900">{employee.phone}</p>
                  </div>
                </div>
              </div>

              {/* Right Section - Status and Actions */}
              <div className="flex items-center gap-4">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(employee.status)}`}>
                  {employee.status}
                </span>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleEditEmployee(employee)}
                    className="bg-blue-50 text-blue-600 px-4 py-2 rounded-lg hover:bg-blue-100 transition-colors text-sm font-medium hover:bg-blue-100 transition-colors text-sm font-medium cursor-pointer"

                  >
                    Edit
                  </button>
                
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {filteredEmployees.length === 0 && (
        <div className="text-center py-12">
          <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
          </svg>
          <h3 className="mt-2 text-sm font-medium text-gray-900">No employees found</h3>
          <p className="mt-1 text-sm text-gray-500">Try adjusting your search or filter criteria.</p>
        </div>
      )}


      {/* Modals would go here - Edit Employee forms */}
      {/* You can extend this component to include modal forms for editing employees */}
    </div>
  );
};

export default ManageUsers;