// Create this file: components/myappraisal/myappraisal.tsx

import React from 'react';

const MyAppraisal: React.FC = () => {
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 max-w-6xl mx-auto mt-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">My Performance Appraisal</h2>
          <p className="text-base text-gray-600 mt-1">FY 2024-25 • Review Period: April 2024 - March 2025</p>
        </div>
        <button className="px-6 py-3 bg-blue-500 text-white text-base rounded-lg hover:bg-blue-600 transition-colors font-medium">
          View My KRAs
        </button>
      </div>

      {/* No KRAs Assigned Message */}
      <div className="bg-gray-50 rounded-xl border border-gray-200 p-12">
        <div className="text-center">
          <div className="w-20 h-20 bg-gray-200 rounded-xl flex items-center justify-center mx-auto mb-6">
            <svg className="w-10 h-10 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
            </svg>
          </div>
          <h3 className="text-2xl font-semibold text-gray-900 mb-4">No KRAs Assigned</h3>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto leading-relaxed">
            Your Key Result Areas for this review period haven&apos;t been assigned yet. Please check with your manager or HR department for updates.
          </p>
        </div>
      </div>
    </div>
  );
};

export default MyAppraisal;