import React, { useState } from 'react';

// Define the structure for performance metrics
interface PerformanceMetric {
  id: number;
  name: string;
  thinkingHolistically: string;
  helpTheTeam: string;
  responsibilityAndOwnership: string;
  innovationAndGrowthOrientation: string;
  valueCollaboration: string;
  excellenceInProcesses: string;
  policyAdherenceBehaviourAttitudeDiscpline: string;
}

// Initial data based on the people from your data.ts
const initialPerformanceMetrics: PerformanceMetric[] = [
  {
    id: 1,
    name: 'Dhvaj Raman Das',
    thinkingHolistically: '',
    helpTheTeam: '',
    responsibilityAndOwnership: '',
    innovationAndGrowthOrientation: '',
    valueCollaboration: '',
    excellenceInProcesses: '',
    policyAdherenceBehaviourAttitudeDiscpline: ''
  },
  {
    id: 2,
    name: 'Harshith Murthy',
    thinkingHolistically: '',
    helpTheTeam: '',
    responsibilityAndOwnership: '',
    innovationAndGrowthOrientation: '',
    valueCollaboration: '',
    excellenceInProcesses: '',
    policyAdherenceBehaviourAttitudeDiscpline: ''
  },
  {
    id: 3,
    name: 'Mayur Pawar',
    thinkingHolistically: '',
    helpTheTeam: '',
    responsibilityAndOwnership: '',
    innovationAndGrowthOrientation: '',
    valueCollaboration: '',
    excellenceInProcesses: '',
    policyAdherenceBehaviourAttitudeDiscpline: ''
  },
  {
    id: 4,
    name: 'Rashmatti Mishra',
    thinkingHolistically: '',
    helpTheTeam: '',
    responsibilityAndOwnership: '',
    innovationAndGrowthOrientation: '',
    valueCollaboration: '',
    excellenceInProcesses: '',
    policyAdherenceBehaviourAttitudeDiscpline: ''
  },
  {
    id: 5,
    name: 'Utsav Raj',
    thinkingHolistically: '',
    helpTheTeam: '',
    responsibilityAndOwnership: '',
    innovationAndGrowthOrientation: '',
    valueCollaboration: '',
    excellenceInProcesses: '',
    policyAdherenceBehaviourAttitudeDiscpline: ''
  }
];

const PerformanceMetricsTable: React.FC = () => {
  const [metrics, setMetrics] = useState<PerformanceMetric[]>(initialPerformanceMetrics);
  const [editingId, setEditingId] = useState<number | null>(null);

  const handleUpdate = (id: number) => {
    // Toggle edit mode
    if (editingId === id) {
      setEditingId(null); // Save and exit edit mode
    } else {
      setEditingId(id); // Enter edit mode
    }
  };

  const handleDelete = (id: number) => {
    // Handle delete logic
    const confirmed = window.confirm('Are you sure you want to delete this record?');
    if (confirmed) {
      setMetrics(metrics.filter(metric => metric.id !== id));
    }
  };

  const handleAddNew = () => {
    // Handle add new metric
    const newMetric: PerformanceMetric = {
      id: Math.max(...metrics.map(m => m.id)) + 1,
      name: '',
      thinkingHolistically: '',
      helpTheTeam: '',
      responsibilityAndOwnership: '',
      innovationAndGrowthOrientation: '',
      valueCollaboration: '',
      excellenceInProcesses: '',
      policyAdherenceBehaviourAttitudeDiscpline: ''
    };
    setMetrics([...metrics, newMetric]);
    setEditingId(newMetric.id); // Automatically enter edit mode for new row
  };

  const handleExportToExcel = () => {
    // Handle export to Excel
    console.log('Export to Excel clicked');
    // You can implement export functionality here
  };

  const handleCellChange = (id: number, field: keyof PerformanceMetric, value: string) => {
    setMetrics(metrics.map(metric => 
      metric.id === id ? { ...metric, [field]: value } : metric
    ));
  };

  return (
    <div className="w-full bg-white rounded-lg shadow-sm">
      {/* Header with buttons */}
      <div className="p-4 flex gap-2">
        <button
          onClick={handleAddNew}
          className="bg-green-600 text-white px-4 py-2 rounded text-sm font-medium hover:bg-green-700 transition-colors"
        >
          Add New Task
        </button>
        <button
          onClick={handleExportToExcel}
          className="bg-blue-500 text-white px-4 py-2 rounded text-sm font-medium hover:bg-blue-600 transition-colors"
        >
          Export to Excel
          .
          
        </button>
        
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr>
              <th className="bg-blue-600 text-white text-center px-4 py-3 text-sm font-medium border border-gray-300">
                NAME
              </th>
              <th className="bg-blue-600 text-white text-center px-4 py-3 text-sm font-medium border border-gray-300">
                Thinking Holistically
              </th>
              <th className="bg-blue-600 text-white text-center px-4 py-3 text-sm font-medium border border-gray-300">
                Help the Team
              </th>
              <th className="bg-blue-600 text-white text-center px-4 py-3 text-sm font-medium border border-gray-300">
                Responsibility and Ownership
              </th>
              <th className="bg-blue-600 text-white text-center px-4 py-3 text-sm font-medium border border-gray-300">
                Innovation & Growth Orientation
              </th>
              <th className="bg-blue-600 text-white text-center px-4 py-3 text-sm font-medium border border-gray-300">
                Value Collaboration
              </th>
              <th className="bg-blue-600 text-white text-center px-4 py-3 text-sm font-medium border border-gray-300">
                Excellence in Processes
              </th>
              <th className="bg-blue-600 text-white text-center px-4 py-3 text-sm font-medium border border-gray-300">
                Policy Adherence, Behaviour & Attitude, Discipline
              </th>
              <th className="bg-blue-600 text-white text-center px-4 py-3 text-sm font-medium border border-gray-300">
                Actions
              </th>
            </tr>
          </thead>
          <tbody>
            {metrics.map((metric) => (
              <tr key={metric.id} className="hover:bg-gray-50">
                <td className="border border-gray-300 px-4 py-2 text-sm font-medium">
                  {editingId === metric.id ? (
                    <input
                      type="text"
                      value={metric.name}
                      onChange={(e) => handleCellChange(metric.id, 'name', e.target.value)}
                      className="w-full px-2 py-1 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  ) : (
                    metric.name
                  )}
                </td>
                <td className="border border-gray-300 px-4 py-2 text-sm text-center">
                  {editingId === metric.id ? (
                    <input
                      type="number"
                      value={metric.thinkingHolistically}
                      onChange={(e) => handleCellChange(metric.id, 'thinkingHolistically', e.target.value)}
                      className="w-full px-2 py-1 border rounded text-center focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="0"
                    />
                  ) : (
                    metric.thinkingHolistically
                  )}
                </td>
                <td className="border border-gray-300 px-4 py-2 text-sm text-center">
                  {editingId === metric.id ? (
                    <input
                      type="number"
                      value={metric.helpTheTeam}
                      onChange={(e) => handleCellChange(metric.id, 'helpTheTeam', e.target.value)}
                      className="w-full px-2 py-1 border rounded text-center focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="0"
                    />
                  ) : (
                    metric.helpTheTeam
                  )}
                </td>
                <td className="border border-gray-300 px-4 py-2 text-sm text-center">
                  {editingId === metric.id ? (
                    <input
                      type="number"
                      value={metric.responsibilityAndOwnership}
                      onChange={(e) => handleCellChange(metric.id, 'responsibilityAndOwnership', e.target.value)}
                      className="w-full px-2 py-1 border rounded text-center focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="0"
                    />
                  ) : (
                    metric.responsibilityAndOwnership
                  )}
                </td>
                <td className="border border-gray-300 px-4 py-2 text-sm text-center">
                  {editingId === metric.id ? (
                    <input
                      type="number"
                      value={metric.innovationAndGrowthOrientation}
                      onChange={(e) => handleCellChange(metric.id, 'innovationAndGrowthOrientation', e.target.value)}
                      className="w-full px-2 py-1 border rounded text-center focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="0"
                    />
                  ) : (
                    metric.innovationAndGrowthOrientation
                  )}
                </td>
                <td className="border border-gray-300 px-4 py-2 text-sm text-center">
                  {editingId === metric.id ? (
                    <input
                      type="number"
                      value={metric.valueCollaboration}
                      onChange={(e) => handleCellChange(metric.id, 'valueCollaboration', e.target.value)}
                      className="w-full px-2 py-1 border rounded text-center focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="0"
                    />
                  ) : (
                    metric.valueCollaboration
                  )}
                </td>
                <td className="border border-gray-300 px-4 py-2 text-sm text-center">
                  {editingId === metric.id ? (
                    <input
                      type="number"
                      value={metric.excellenceInProcesses}
                      onChange={(e) => handleCellChange(metric.id, 'excellenceInProcesses', e.target.value)}
                      className="w-full px-2 py-1 border rounded text-center focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="0"
                    />
                  ) : (
                    metric.excellenceInProcesses
                  )}
                </td>
                <td className="border border-gray-300 px-4 py-2 text-sm text-center">
                  {editingId === metric.id ? (
                    <input
                      type="number"
                      value={metric.policyAdherenceBehaviourAttitudeDiscpline}
                      onChange={(e) => handleCellChange(metric.id, 'policyAdherenceBehaviourAttitudeDiscpline', e.target.value)}
                      className="w-full px-2 py-1 border rounded text-center focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="0"
                    />
                  ) : (
                    metric.policyAdherenceBehaviourAttitudeDiscpline
                  )}
                </td>
                
                <td className="border border-gray-300 px-4 py-2 text-center">
                  <div className="flex justify-center gap-2">
                    <button
                      onClick={() => handleUpdate(metric.id)}
                      className={`${
                        editingId === metric.id ? 'bg-green-500 hover:bg-green-600' : 'bg-yellow-500 hover:bg-yellow-600'
                      } text-white px-3 py-1 rounded text-xs font-medium transition-colors`}
                    >
                      {editingId === metric.id ? 'Save' : 'Update'}
                    </button>
                    <button
                      onClick={() => handleDelete(metric.id)}
                      className="bg-red-500 text-white px-3 py-1 rounded text-xs font-medium hover:bg-red-600 transition-colors"
                    >
                      Delete
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// Main component
const PerformanceMetricsSection: React.FC = () => {
  return (
    <div className="p-4">
      <PerformanceMetricsTable />
    </div>
  );
};

export default PerformanceMetricsSection;