'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { teamMembersData, departments, statusOptions, TeamMember } from '@/data/sampledata3';

interface EmployeesProps {
  onBackToMyKRAs?: () => void;
}

const Employees: React.FC<EmployeesProps> = ({ onBackToMyKRAs }) => {
  const router = useRouter();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('All Departments');
  const [selectedStatus, setSelectedStatus] = useState('All Status');
  const [filteredMembers, setFilteredMembers] = useState<TeamMember[]>(teamMembersData);

  const handleApplyFilters = () => {
    const filtered = teamMembersData.filter(member => {
      const matchesSearch = member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           member.employeeId.includes(searchTerm);
      const matchesDepartment = selectedDepartment === 'All Departments' ||
                               member.department === selectedDepartment;
      const matchesStatus = selectedStatus === 'All Status' ||
                           member.kraStatus === selectedStatus;

      return matchesSearch && matchesDepartment && matchesStatus;
    });
    setFilteredMembers(filtered);
  };

  const handleViewEmployee = (member: TeamMember) => {
    // Navigate to employee detail page
    router.push(`/home/view/${member.employeeId}`);
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 max-w-6xl mx-auto">
      {/* Main Back Button */}
      {onBackToMyKRAs && (
        <div className="mb-6">
          <button
            onClick={onBackToMyKRAs}
            className="group flex items-center gap-3 px-4 py-3 text-gray-600 hover:text-white hover:bg-gradient-to-r hover:from-blue-500 hover:to-purple-600 rounded-xl transition-all duration-300 shadow-sm hover:shadow-lg transform hover:-translate-y-0.5"
          >
            <div className="p-1.5 bg-gray-100 group-hover:bg-white/20 rounded-lg transition-all duration-300">
              <svg
                className="w-5 h-5 transform group-hover:-translate-x-1 transition-transform duration-300"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </div>
            <div>
              <span className="font-semibold text-sm">Back to My KRAs</span>
              <p className="text-xs opacity-75 group-hover:opacity-100">Return to your performance dashboard</p>
            </div>
          </button>
        </div>
      )}

      {/* Header */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Employee Directory</h2>
        <p className="text-gray-600">View employee information and KRA status</p>
      </div>

      {/* Filters Section */}
      <div className="bg-gray-50 rounded-xl p-6 mb-6">
        {/* Search */}
        <div className="mb-4">
          <div className="relative">
            <svg className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input
              type="text"
              placeholder="Search employees..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
            />
          </div>
        </div>

        {/* Dropdown Filters */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <select
            value={selectedDepartment}
            onChange={(e) => setSelectedDepartment(e.target.value)}
            className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
          >
            {departments.map((dept) => (
              <option key={dept} value={dept}>{dept}</option>
            ))}
          </select>

          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
          >
            {statusOptions.map((status) => (
              <option key={status} value={status}>{status}</option>
            ))}
          </select>
        </div>

        {/* Apply Filters Button */}
        <button
          onClick={handleApplyFilters}
          className="w-full bg-blue-500 hover:bg-blue-600 text-white py-3 px-6 rounded-lg transition-colors font-medium"
        >
          Apply Filters
        </button>
      </div>

      {/* Employee List */}
      <div className="space-y-4">
        {filteredMembers.map((member) => (
          <div key={member.id} className="bg-white border border-gray-200 rounded-xl p-6">
            <div className="flex items-start gap-4">
              {/* Avatar */}
              <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center text-white font-bold text-lg flex-shrink-0">
                {member.initials}
              </div>

              {/* Content */}
              <div className="flex-1">
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                  {/* Column 1: Basic Info */}
                  <div>
                    <h3 className="font-semibold text-gray-900 text-lg mb-1">{member.name}</h3>
                    <p className="text-gray-600 mb-1">{member.position}</p>
                    <p className="text-sm text-gray-500">{member.employeeId}</p>
                  </div>

                  {/* Column 2: Department & Location */}
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm text-gray-500 mb-1">Department:</p>
                      <p className="text-gray-900 font-medium">{member.department}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 mb-1">Location:</p>
                      <p className="text-gray-700">{member.location}</p>
                    </div>
                  </div>

                  {/* Column 3: Experience & Status */}
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm text-gray-500 mb-1">Experience:</p>
                      <p className="text-gray-700">{member.experience}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 mb-1">KRA Status:</p>
                      {member.kraStatus === 'Not Assigned' && (
                        <span className="text-red-600 text-sm font-medium">{member.kraStatus}</span>
                      )}
                      {member.kraStatus === 'Assigned' && (
                        <span className="text-blue-600 text-sm font-medium">{member.kraStatus}</span>
                      )}
                      {member.kraStatus === 'In Progress' && (
                        <span className="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full text-sm font-medium">{member.kraStatus}</span>
                      )}
                    </div>
                  </div>

                  {/* Column 4: Actions - Only View Button */}
                  <div className="flex items-end">
                    <button
                      onClick={() => handleViewEmployee(member)}
                      className="w-full bg-gray-100 hover:bg-gray-200 text-gray-700 py-2.5 px-4 rounded-lg transition-colors flex items-center justify-center gap-2 font-medium"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                      </svg>
                      View Details
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {filteredMembers.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No employees found</h3>
          <p className="text-gray-500">Try adjusting your search criteria or filters</p>
        </div>
      )}
    </div>
  );
};

export default Employees;