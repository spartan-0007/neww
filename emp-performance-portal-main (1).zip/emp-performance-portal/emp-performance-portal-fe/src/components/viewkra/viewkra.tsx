'use client';

import React, { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { teamMembersData, TeamMember } from '@/data/sampledata3';

interface KRAItem {
  id: string;
  title: string;
  description: string;
  target: string;
  weightage: number;
  status: 'Not Started' | 'In Progress' | 'Completed';
  progress: number;
  deadline: string;
  selfRating: number;
  supervisorRating: number;
  comment?: string;
}

interface RatingData {
  employeeId: string;
  employeeName: string;
  ratings: {
    kraId: string;
    kraTitle: string;
    selfRating: number;
    supervisorRating: number;
    comment: string;
  }[];
  submittedAt: string;
}

const ViewKRA: React.FC = () => {
  const router = useRouter();
  const params = useParams();
  const employeeId = Array.isArray(params?.empID) ? params.empID[0] : params?.empID;

  const [employee, setEmployee] = useState<TeamMember | null>(null);
  const [kras, setKras] = useState<KRAItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedKRA, setExpandedKRA] = useState<string | null>(null);

  useEffect(() => {
    if (!employeeId) {
      setLoading(false);
      return;
    }

    const foundEmployee = teamMembersData.find((member) => member.employeeId === employeeId);

    if (foundEmployee) {
      setEmployee(foundEmployee);

      // Check if there are existing ratings for this employee
      const existingRatingsStr = localStorage.getItem('employeeRatings');
      let existingRatings: { [key: string]: RatingData } = {};
      
      if (existingRatingsStr) {
        try {
          existingRatings = JSON.parse(existingRatingsStr);
        } catch (error) {
          console.error('Error parsing existing ratings:', error);
        }
      }

      // Sample KRAs with pre-assigned self ratings
      const sampleKRAs: KRAItem[] = [
        {
          id: '1',
          title: 'Quarterly Sales Target Achievement',
          description: 'Achieve quarterly sales targets by maintaining client relationships and acquiring new customers through strategic outreach and product demonstrations.',
          target: '₹50 Lakhs Revenue',
          weightage: 30,
          status: 'In Progress',
          progress: 75,
          deadline: '2025-03-31',
          selfRating: 85,
          supervisorRating: 0,
          comment: '',
        },
        {
          id: '2',
          title: 'Team Leadership & Development',
          description: 'Lead and mentor junior team members, conduct regular performance reviews, and implement training programs to enhance team productivity.',
          target: '90% Team Satisfaction Score',
          weightage: 25,
          status: 'In Progress',
          progress: 60,
          deadline: '2025-06-30',
          selfRating: 75,
          supervisorRating: 0,
          comment: '',
        },
        {
          id: '3',
          title: 'Process Improvement Initiative',
          description: 'Identify and implement process improvements to reduce operational costs and increase efficiency in daily workflows.',
          target: '15% Cost Reduction',
          weightage: 20,
          status: 'Not Started',
          progress: 0,
          deadline: '2025-05-15',
          selfRating: 60,
          supervisorRating: 0,
          comment: '',
        },
        {
          id: '4',
          title: 'Client Satisfaction & Retention',
          description: 'Maintain high client satisfaction scores through excellent service delivery and proactive communication.',
          target: '95% Client Retention Rate',
          weightage: 15,
          status: 'Completed',
          progress: 100,
          deadline: '2025-02-28',
          selfRating: 95,
          supervisorRating: 0,
          comment: '',
        },
        {
          id: '5',
          title: 'Innovation & Research',
          description: 'Research market trends and propose innovative solutions to stay competitive in the market.',
          target: '3 Innovation Proposals',
          weightage: 10,
          status: 'In Progress',
          progress: 45,
          deadline: '2025-04-30',
          selfRating: 70,
          supervisorRating: 0,
          comment: '',
        },
      ];

      // If there are existing ratings for this employee, update the KRAs with those ratings
      const employeeRatings = existingRatings[employeeId];
      if (employeeRatings) {
        const updatedKRAs = sampleKRAs.map(kra => {
          const existingRating = employeeRatings.ratings.find(r => r.kraId === kra.id);
          if (existingRating) {
            return {
              ...kra,
              supervisorRating: existingRating.supervisorRating,
              comment: existingRating.comment
            };
          }
          return kra;
        });
        setKras(updatedKRAs);
      } else {
        setKras(sampleKRAs);
      }
    }

    setLoading(false);
  }, [employeeId]);

  const handleGoBack = () => {
    router.push('/home');
  };

  const handleSupervisorRating = (kraId: string, rating: number) => {
    setKras(prev => prev.map(kra => 
      kra.id === kraId ? { ...kra, supervisorRating: rating } : kra
    ));
  };

  const handleCommentChange = (kraId: string, comment: string) => {
    setKras(prev => prev.map(kra => 
      kra.id === kraId ? { ...kra, comment } : kra
    ));
  };

  const handleSubmitRatings = () => {
    if (!employee) return;

    // Prepare rating data
    const ratingData: RatingData = {
      employeeId: employee.employeeId,
      employeeName: employee.name,
      ratings: kras.map(kra => ({
        kraId: kra.id,
        kraTitle: kra.title,
        selfRating: kra.selfRating,
        supervisorRating: kra.supervisorRating,
        comment: kra.comment || ''
      })),
      submittedAt: new Date().toISOString()
    };

    // Get existing ratings from localStorage
    const existingRatingsStr = localStorage.getItem('employeeRatings');
    let existingRatings: { [key: string]: RatingData } = {};
    
    if (existingRatingsStr) {
      try {
        existingRatings = JSON.parse(existingRatingsStr);
      } catch (error) {
        console.error('Error parsing existing ratings:', error);
      }
    }

    // Update with new ratings
    existingRatings[employee.employeeId] = ratingData;
    
    // Save to localStorage
    localStorage.setItem('employeeRatings', JSON.stringify(existingRatings));
    
    // Also save to sessionStorage for immediate use in TeamKRA
    sessionStorage.setItem('submittedRatings', JSON.stringify(ratingData));
    
    console.log('Submitting ratings:', ratingData);
    
    // Navigate back to team KRA page
    router.push('/home/teamkra');
  };

  const toggleKRAExpansion = (kraId: string) => {
    setExpandedKRA(expandedKRA === kraId ? null : kraId);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Completed':
        return 'bg-green-100 text-green-700';
      case 'In Progress':
        return 'bg-blue-100 text-blue-700';
      case 'Not Started':
        return 'bg-gray-100 text-gray-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const calculateOverallProgress = () => {
    if (kras.length === 0) return 0;
    const totalWeightedProgress = kras.reduce((sum, kra) => sum + (kra.progress * kra.weightage) / 100, 0);
    return Math.round(totalWeightedProgress);
  };

  const getProgressColor = (progress: number) => {
    if (progress >= 80) return 'bg-green-500';
    if (progress >= 50) return 'bg-blue-500';
    if (progress >= 30) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const calculateAverageSupervisorRating = () => {
    const ratedKras = kras.filter(kra => kra.supervisorRating > 0);
    if (ratedKras.length === 0) return 0;
    
    const weightedSum = ratedKras.reduce((sum, kra) => sum + (kra.supervisorRating * kra.weightage), 0);
    const totalWeight = ratedKras.reduce((sum, kra) => sum + kra.weightage, 0);
    
    return totalWeight > 0 ? Math.round(weightedSum / totalWeight) : 0;
  };

  const calculateAverageSelfRating = () => {
    if (kras.length === 0) return 0;
    
    const weightedSum = kras.reduce((sum, kra) => sum + (kra.selfRating * kra.weightage), 0);
    const totalWeight = kras.reduce((sum, kra) => sum + kra.weightage, 0);
    
    return totalWeight > 0 ? Math.round(weightedSum / totalWeight) : 0;
  };

  const getRatingBadgeColor = (rating: number) => {
    if (rating >= 80) return 'bg-green-100 text-green-700 border-green-200';
    if (rating >= 60) return 'bg-blue-100 text-blue-700 border-blue-200';
    if (rating >= 40) return 'bg-yellow-100 text-yellow-700 border-yellow-200';
    return 'bg-red-100 text-red-700 border-red-200';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading employee details...</p>
        </div>
      </div>
    );
  }

  if (!employee) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L8.732 4c-.77-1.667-2.5-1.667-3.232 0L1.268 16c-.77 1.333.192 3 1.732 3z"
              />
            </svg>
          </div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Employee Not Found</h2>
          <p className="text-gray-600 mb-4">The employee with ID "{employeeId || 'unknown'}" could not be found.</p>
          <div className="flex gap-3 justify-center">
            <button
              onClick={handleGoBack}
              className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
            >
              Go Back
            </button>
            <button
              onClick={() => router.push('/home')}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Go to Team KRAs
            </button>
          </div>
        </div>
      </div>
    );
  }

  const avgSupervisorRating = calculateAverageSupervisorRating();
  const avgSelfRating = calculateAverageSelfRating();
  const ratedKrasCount = kras.filter(kra => kra.supervisorRating > 0).length;

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4">
        {/* Header and navigation buttons */}
        <div className="mb-8">
          <div className="flex gap-3 mb-6">
            <button
              onClick={handleGoBack}
              className="group flex items-center gap-3 px-4 py-3 text-gray-600 hover:text-white hover:bg-gradient-to-r hover:from-blue-500 hover:to-purple-600 rounded-xl transition-all duration-300 shadow-sm hover:shadow-lg transform hover:-translate-y-0.5"
            >
              <div className="p-1.5 bg-gray-100 group-hover:bg-white/20 rounded-lg transition-all duration-300">
                <svg
                  className="w-5 h-5 transform group-hover:-translate-x-1 transition-transform duration-300"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </div>
              <div>
                <span className="font-semibold text-sm">Go Back</span>
                <p className="text-xs opacity-75 group-hover:opacity-100">Return to previous page</p>
              </div>
            </button>

            <button
              onClick={() => router.push('/home/teamkra')}
              className="group flex items-center gap-3 px-4 py-3 text-gray-600 hover:text-white hover:bg-gradient-to-r hover:from-purple-500 hover:to-pink-600 rounded-xl transition-all duration-300 shadow-sm hover:shadow-lg transform hover:-translate-y-0.5"
            >
              <div className="p-1.5 bg-gray-100 group-hover:bg-white/20 rounded-lg transition-all duration-300">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                  />
                </svg>
              </div>
              <div>
                <span className="font-semibold text-sm">Team KRAs</span>
                <p className="text-xs opacity-75 group-hover:opacity-100">Manage your team's performance</p>
              </div>
            </button>
          </div>

          <h1 className="text-3xl font-bold text-gray-900 mb-2">KRA Performance Review</h1>
          <p className="text-gray-600">View, rate and monitor Key Result Areas performance</p>
        </div>

        {/* Employee info card with Rating Preview */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 mb-8">
          <div className="flex items-start gap-6">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center text-white font-bold text-2xl flex-shrink-0">
              {employee.initials}
            </div>

            <div className="flex-1">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-1">{employee.name}</h2>
                  <p className="text-lg text-gray-600 mb-2">{employee.position}</p>
                  <p className="text-sm text-gray-500">ID: {employee.employeeId}</p>
                </div>

                <div className="space-y-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500 mb-1">Department</p>
                    <p className="text-gray-900">{employee.department}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500 mb-1">Location</p>
                    <p className="text-gray-900">{employee.location}</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500 mb-1">Experience</p>
                    <p className="text-gray-900">{employee.experience}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500 mb-1">Overall Progress</p>
                    <div className="flex items-center gap-3">
                      <div className="flex-1 bg-gray-200 rounded-full h-3">
                        <div
                          className={`h-3 rounded-full ${getProgressColor(calculateOverallProgress())}`}
                          style={{ width: `${calculateOverallProgress()}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-medium text-gray-900">{calculateOverallProgress()}%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Rating Preview Section */}
          <div className="mt-6 pt-6 border-t border-gray-200">
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <svg className="w-5 h-5 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
                Performance Rating Preview
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Employee Average Rating */}
                <div className="bg-white rounded-lg p-4 text-center">
                  <p className="text-sm text-gray-600 mb-2">Employee Self Rating</p>
                  <div className={`inline-flex items-center justify-center w-20 h-20 rounded-full ${getRatingBadgeColor(avgSelfRating)} border-2 mb-2`}>
                    <span className="text-2xl font-bold">{avgSelfRating}</span>
                  </div>
                  <p className="text-xs text-gray-500">Weighted Average</p>
                </div>

                {/* Supervisor Average Rating */}
                <div className="bg-white rounded-lg p-4 text-center">
                  <p className="text-sm text-gray-600 mb-2">Supervisor Rating</p>
                  <div className={`inline-flex items-center justify-center w-20 h-20 rounded-full ${getRatingBadgeColor(avgSupervisorRating)} border-2 mb-2`}>
                    <span className="text-2xl font-bold">{avgSupervisorRating}</span>
                  </div>
                  <p className="text-xs text-gray-500">
                    {ratedKrasCount > 0 ? `${ratedKrasCount}/${kras.length} KRAs Rated` : 'Not Rated'}
                  </p>
                </div>

                {/* Rating Progress */}
                <div className="bg-white rounded-lg p-4">
                  <p className="text-sm text-gray-600 mb-3">Rating Progress</p>
                  <div className="space-y-2">
                    {kras.map((kra, index) => (
                      <div key={kra.id} className="flex items-center gap-2">
                        <span className="text-xs text-gray-500 w-20">KRA #{index + 1}:</span>
                        <div className="flex-1 bg-gray-200 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full ${kra.supervisorRating > 0 ? 'bg-green-500' : 'bg-gray-300'}`}
                            style={{ width: kra.supervisorRating > 0 ? '100%' : '0%' }}
                          ></div>
                        </div>
                        <span className="text-xs font-medium w-10 text-right">
                          {kra.supervisorRating > 0 ? '✓' : '-'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* KRAs list */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 mb-8">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-gray-900">Key Result Areas ({kras.length})</h3>
            <div className="text-sm text-gray-500">
              Total Weightage: <span className="font-medium">100%</span>
            </div>
          </div>

          <div className="space-y-6">
            {kras.map((kra, index) => (
              <div key={kra.id} className="border border-gray-200 rounded-xl overflow-hidden">
                <div 
                  className="p-6 hover:bg-gray-50 cursor-pointer transition-colors"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="text-lg font-semibold text-gray-900">
                          KRA #{index + 1}: {kra.title}
                        </h4>
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(kra.status)}`}>
                          {kra.status}
                        </span>
                        <div 
                          className="relative group flex items-center gap-2 cursor-pointer"
                          onClick={() => toggleKRAExpansion(kra.id)}
                        >
                          <div className="p-1.5 bg-gradient-to-r from-blue-100 to-purple-100 rounded-lg transition-all duration-300 group-hover:from-blue-200 group-hover:to-purple-200 shadow-sm group-hover:shadow-md">
                            <svg 
                              className={`w-5 h-5 text-purple-600 transition-transform duration-300 group-hover:scale-110 ${expandedKRA === kra.id ? 'rotate-180' : ''}`} 
                              fill="none" 
                              stroke="currentColor" 
                              viewBox="0 0 24 24"
                            >
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                            </svg>
                          </div>
                          <span className="text-sm text-purple-600 font-medium transition-colors duration-300 group-hover:text-purple-800">
                            Click to rate
                          </span>
                          {/* Tooltip */}
                          <div className="absolute left-0 top-8 hidden group-hover:block bg-purple-600 text-white text-xs rounded-lg py-1 px-2 shadow-lg">
                            Rate this KRA by providing a score and comments
                          </div>
                        </div>
                      </div>
                      <p className="text-gray-600 mb-4">{kra.description}</p>
                    </div>
                    <div className="text-right ml-6">
                      <p className="text-sm text-gray-500 mb-1">Weightage</p>
                      <p className="text-lg font-bold text-gray-900">{kra.weightage}%</p>
                      <div className="mt-2">
                        <p className="text-sm text-gray-500 mb-1">Employee Rating</p>
                        <p className="text-lg font-bold text-blue-600">{kra.selfRating}/100</p>
                      </div>
                      {kra.supervisorRating > 0 && (
                        <div className="mt-2">
                          <p className="text-sm text-gray-500 mb-1">Your Rating</p>
                          <p className="text-lg font-bold text-green-600">{kra.supervisorRating}/100</p>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <p className="text-sm font-medium text-gray-500 mb-2">Target</p>
                      <p className="text-gray-900 font-medium">{kra.target}</p>
                    </div>

                    <div>
                      <p className="text-sm font-medium text-gray-500 mb-2">Deadline</p>
                      <p className="text-gray-900">
                        {new Date(kra.deadline).toLocaleDateString('en-IN', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                        })}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Expanded rating section - Updated to reduce the width of the Score field */}
                {expandedKRA === kra.id && (
                  <div className="border-t border-gray-200 p-6 bg-gray-50">
                    <div className="space-y-4">
                      <div className="bg-white p-5 rounded-lg">
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Score (0-100) *
                        </label>
                        <div className="relative w-32">
                          <input
                            type="number"
                            min="0"
                            max="100"
                            value={kra.supervisorRating}
                            onChange={(e) => {
                              const value = Number(e.target.value);
                              if (value >= 0 && value <= 100) {
                                handleSupervisorRating(kra.id, value);
                              }
                            }}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                            placeholder="0"
                          />
                          <span className="absolute right-3 top-2 text-gray-400 text-sm">/100</span>
                        </div>
                      </div>

                      <div className="bg-white p-5 rounded-lg">
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Achievement Comments *
                        </label>
                        <textarea
                          value={kra.comment || ''}
                          onChange={(e) => handleCommentChange(kra.id, e.target.value)}
                          placeholder="Describe your key achievements..."
                          className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none resize-none"
                          rows={4}
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          {kras.length === 0 && (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                  />
                </svg>
              </div>
              <h4 className="text-lg font-medium text-gray-900 mb-2">No Key Result Areas Found</h4>
              <p className="text-gray-600 mb-4">This employee doesn't have any KRAs assigned yet.</p>
              <button
                onClick={handleGoBack}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Go Back
              </button>
            </div>
          )}

          {/* Submit Button */}
          {kras.length > 0 && (
            <div className="mt-8 flex justify-end">
              <button
                onClick={handleSubmitRatings}
                className="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-medium rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-300 shadow-md hover:shadow-lg"
              >
                Submit Ratings
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ViewKRA;