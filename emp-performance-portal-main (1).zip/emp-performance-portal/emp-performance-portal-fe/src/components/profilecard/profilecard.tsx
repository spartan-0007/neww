"use client";

import React from 'react';
import { ProfileData, profileData, sampleProfiles } from '@/data/sampledata2';

const ProfileCard: React.FC<{ data?: ProfileData; showPreview?: boolean }> = ({ 
  data = profileData, 
  showPreview = false 
}) => {
  const [currentProfileIndex, setCurrentProfileIndex] = React.useState(0);
  const currentProfile = showPreview ? sampleProfiles[currentProfileIndex] : data;

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: '2-digit', 
      day: '2-digit' 
    }).replace(/\//g, '-');
  };

  const getExperienceString = () => {
    const { years, months } = currentProfile.experience;
    if (months === 0) return `${years} years`;
    return `${years}.${months} years`;
  };

  const handlePrevProfile = () => {
    setCurrentProfileIndex((prev) => 
      prev === 0 ? sampleProfiles.length - 1 : prev - 1
    );
  };

  const handleNextProfile = () => {
    setCurrentProfileIndex((prev) => 
      prev === sampleProfiles.length - 1 ? 0 : prev + 1
    );
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Preview Controls */}
      {showPreview && sampleProfiles.length > 1 && (
        <div className="flex items-center justify-between mb-4">
          <button 
            onClick={handlePrevProfile}
            className="p-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
          >
            <span className="text-xl">←</span>
          </button>
          <span className="text-sm text-gray-600">
            Profile {currentProfileIndex + 1} of {sampleProfiles.length}
          </span>
          <button 
            onClick={handleNextProfile}
            className="p-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
          >
            <span className="text-xl">→</span>
          </button>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
        {/* Header Section */}
        <div className="flex items-center gap-5 mb-8">
          {/* Profile Avatar */}
          <div className="w-16 h-16 bg-blue-500 rounded-2xl flex items-center justify-center text-white font-semibold text-xl">
            {currentProfile.initials}
          </div>
          
          {/* Name and Title */}
          <div className="flex-1">
            <h2 className="text-2xl font-semibold text-gray-900">{currentProfile.name}</h2>
            <p className="text-gray-600 mt-0.5">{currentProfile.title}</p>
            {/* Tags */}
            <div className="flex gap-2 mt-2">
              <span className="px-2.5 py-0.5 bg-blue-50 text-blue-600 rounded text-xs font-medium">
                1002
              </span>
              <span className="px-2.5 py-0.5 bg-green-50 text-green-600 rounded text-xs font-medium">
                VP
              </span>
            </div>
          </div>
        </div>

        {/* Info Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-16 gap-y-6">
          {/* Department */}
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 bg-blue-50 rounded-lg flex items-center justify-center flex-shrink-0">
              <span className="text-blue-500 text-lg">🏢</span>
            </div>
            <div className="flex-1">
              <p className="text-xs text-gray-500 uppercase tracking-wide font-medium">
                DEPARTMENT
              </p>
              <p className="text-gray-900 font-medium mt-0.5">{currentProfile.department}</p>
            </div>
          </div>

          {/* Location */}
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 bg-green-50 rounded-lg flex items-center justify-center flex-shrink-0">
              <span className="text-green-500 text-lg">📍</span>
            </div>
            <div className="flex-1">
              <p className="text-xs text-gray-500 uppercase tracking-wide font-medium">
                LOCATION
              </p>
              <p className="text-gray-900 font-medium mt-0.5">{currentProfile.location}</p>
            </div>
          </div>

          {/* Joining Date */}
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 bg-pink-50 rounded-lg flex items-center justify-center flex-shrink-0">
              <span className="text-pink-500 text-lg">📅</span>
            </div>
            <div className="flex-1">
              <p className="text-xs text-gray-500 uppercase tracking-wide font-medium">
                JOINING DATE
              </p>
              <p className="text-gray-900 font-medium mt-0.5">{formatDate(currentProfile.joiningDate)}</p>
            </div>
          </div>

          {/* Experience */}
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 bg-purple-50 rounded-lg flex items-center justify-center flex-shrink-0">
              <span className="text-purple-500 text-lg">📊</span>
            </div>
            <div className="flex-1">
              <p className="text-xs text-gray-500 uppercase tracking-wide font-medium">
                EXPERIENCE
              </p>
              <p className="text-gray-900 font-medium mt-0.5">{getExperienceString()}</p>
            </div>
          </div>

          {/* Supervisor */}
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 bg-orange-50 rounded-lg flex items-center justify-center flex-shrink-0">
              <span className="text-orange-500 text-lg">👤</span>
            </div>
            <div className="flex-1">
              <p className="text-xs text-gray-500 uppercase tracking-wide font-medium">
                SUPERVISOR
              </p>
              <p className="text-gray-900 font-medium mt-0.5">{currentProfile.supervisor}</p>
            </div>
          </div>

          {/* Reviewer */}
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 bg-pink-50 rounded-lg flex items-center justify-center flex-shrink-0">
              <span className="text-pink-500 text-lg">👥</span>
            </div>
            <div className="flex-1">
              <p className="text-xs text-gray-500 uppercase tracking-wide font-medium">
                REVIEWER
              </p>
              <p className="text-gray-900 font-medium mt-0.5">{currentProfile.reviewer}</p>
            </div>
          </div>

          {/* Email - Full Width */}
          <div className="flex items-start gap-3 md:col-span-2">
            <div className="w-9 h-9 bg-teal-50 rounded-lg flex items-center justify-center flex-shrink-0">
              <span className="text-teal-500 text-lg">✉️</span>
            </div>
            <div className="flex-1">
              <p className="text-xs text-gray-500 uppercase tracking-wide font-medium">
                EMAIL ADDRESS
              </p>
              <p className="text-gray-900 font-medium mt-0.5">{currentProfile.email}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Demo component to show the preview functionality
const ProfileCardDemo: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Profile Card Preview</h1>
        <p className="text-gray-600">Navigate through different employee profiles</p>
      </div>
      
      {/* Profile Card with Preview enabled */}
      <ProfileCard showPreview={true} />
      
      {/* You can also show a single profile without preview controls */}
      <div className="mt-8">
        <h2 className="text-xl font-semibold text-center text-gray-800 mb-4">
          Single Profile View (No Navigation)
        </h2>
        <ProfileCard data={profileData} showPreview={false} />
      </div>
    </div>
  );
};

export default ProfileCardDemo;