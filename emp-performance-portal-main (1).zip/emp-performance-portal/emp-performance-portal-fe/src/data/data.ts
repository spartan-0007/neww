// data/taskData.ts

export interface Task {
  id: number;
  personName: string;
  level: string;
  taskDescription: string;
  storyPoints: string;
  status: string;
  sprint: string;
}

export const sampleTasks: Task[] = [
  {
    id: 1,
    personName: 'Harshith Murthy',
    level: 'L0',
    taskDescription: 'User Authentication Module',
    storyPoints: '8',
    status: 'Completed',
    sprint: 'Sprint 1'
  },
  {
    id: 2,
    personName: 'Utsav Raj',
    level: 'L0',
    taskDescription: 'Database Schema Design',
    storyPoints: '5',
    status: 'In Progress',
    sprint: 'Sprint 1'
  },
  {
    id: 3,
    personName: 'Dhvaj Raman Das',
    level: 'L1',
    taskDescription: 'API Integration',
    storyPoints: '13',
    status: 'Completed',
    sprint: 'Sprint 1'
  },
  {
    id: 4,
    personName: 'Rashmatti Mishra',
    level: 'Manager',
    taskDescription: 'Code Review & Planning',
    storyPoints: '8',
    status: 'Completed',
    sprint: 'Sprint 1'
  },
  {
    id: 5,
    personName: 'Mayur Pawar',
    level: 'L2',
    taskDescription: 'Frontend Architecture',
    storyPoints: '21',
    status: 'Completed',
    sprint: 'Sprint 1'
  },
  {
    id: 6,
    personName: 'Harshith Murthy',
    level: 'L1',
    taskDescription: 'Testing Framework Setup',
    storyPoints: '12',
    status: 'In Progress',
    sprint: 'Sprint 1'
  },
  {
    id: 7,
    personName: 'Harshith Murthy',
    level: 'L0',
    taskDescription: 'Login Page UI',
    storyPoints: '5',
    status: 'Completed',
    sprint: 'Sprint 1'
  },
  {
    id: 8,
    personName: 'Mayur Pawar',
    level: 'L2',
    taskDescription: 'Dashboard Components',
    storyPoints: '8',
    status: 'In Progress',
    sprint: 'Sprint 1'
  },
 
];

// Additional utility functions
export const getLevelOptions = () => ['L0', 'L1', 'L2', 'Manager'];

export const getStatusOptions = () => ['Not Started', 'In Progress', 'Completed'];

export const getSprintOptions = () => ['Sprint 1', 'Sprint 2', 'Sprint 3', 'Sprint 4'];

export const getNextTaskId = (tasks: Task[]): number => {
  return Math.max(...tasks.map(task => task.id)) + 1;
};

export const getTasksByStatus = (tasks: Task[], status: string): Task[] => {
  return tasks.filter(task => task.status === status);
};

export const getTasksBySprint = (tasks: Task[], sprint: string): Task[] => {
  return tasks.filter(task => task.sprint === sprint);
};

export const getTotalStoryPoints = (tasks: Task[]): number => {
  return tasks.reduce((total, task) => total + (parseInt(task.storyPoints) || 0), 0);
};