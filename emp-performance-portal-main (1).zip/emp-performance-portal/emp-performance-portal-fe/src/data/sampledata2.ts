// sampledata2.ts

export interface ProfileData {
  name: string;
  title: string;
  experience: {
    years: number;
    months: number;
  };
  department: string;
  location: string;
  joiningDate: string;
  supervisor: string;
  reviewer: string;
  email: string;
  initials: string;
}

export const profileData: ProfileData = {
  name: "Rajesh Kumar",
  title: "Vice President",
  experience: {
    years: 37,
    months: 5
  },
  department: "Cloud Engineering",
  location: "Hyderabad",
  joiningDate: "2015-12-16",
  supervisor: "Amit Sharma",
  reviewer: "Priya Singh",
  email: "rajesh.kumar@iftas.in",
  initials: "RK"
};

// Additional sample profiles if needed
export const sampleProfiles: ProfileData[] = [
  {
    name: "Rajesh Kumar",
    title: "Vice President",
    experience: {
      years: 37,
      months: 5
    },
    department: "Cloud Engineering",
    location: "Hyderabad",
    joiningDate: "2015-12-16",
    supervisor: "Amit Sharma",
    reviewer: "Priya Singh",
    email: "rajesh.kumar@iftas.in",
    initials: "RK"
  },
  {
    name: "Sarah Johnson",
    title: "Senior Manager",
    experience: {
      years: 12,
      months: 3
    },
    department: "Product Development",
    location: "Bangalore",
    joiningDate: "2018-06-22",
    supervisor: "David Chen",
    reviewer: "Amit Sharma",
    email: "sarah.johnson@iftas.in",
    initials: "SJ"
  }
];