// data.ts
export interface PersonalInfoData {
  name: string;
  position: string;
  employeeId: string;
  role: string;
  department: string;
  location: string;
  teamSize: number;
  experience: number;
  initials: string;
}

export const personalInfoData: PersonalInfoData = {
  name: "Amit Sharma",
  position: "Senior Vice President",
  employeeId: "1001",
  role: "SUPERVISOR",
  department: "Cloud Engineering",
  location: "Hyderabad",
  teamSize: 5,
  experience: 18.5,
  initials: "AS"
};