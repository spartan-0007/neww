// kraSampleData.ts

export interface KRA {
  id: number;
  title: string;
  description: string;
  targetValue: string;
  weightage: number;
  category: string;
  status: 'PENDING_SELF_RATING' | 'COMPLETED' | 'IN_PROGRESS';
  selfRating: number;
  supervisorRating: number;
  finalRating: number;
  achievementComments: string;
  supervisorComments: string;
  reviewerComments: string;
}

export interface PerformanceData {
  fiscalYear: string;
  reviewPeriod: string;
  supervisor: string;
  kras: KRA[];
}

// Empty KRA data - will show the waiting screen
export const emptyPerformanceData: PerformanceData = {
  fiscalYear: "FY 2024-25",
  reviewPeriod: "April 2024 - March 2025",
  supervisor: "Amit Sharma",
  kras: []
};

// Sample KRA data - will show the performance appraisal list
export const samplePerformanceData: PerformanceData = {
  fiscalYear: "FY 2024-25",
  reviewPeriod: "April 2024 - March 2025",
  supervisor: "Amit Sharma",
   kras: [
    {
      id: 1,
      title: "Self-Assessment Guidelines",
      description: "Utilize tools GCH as a base of 5184 based on your achievement. Include detailed, quantifiable examples of your accomplishments. Provide comprehensive evaluation and insights",
      targetValue: "100% completion of self-assessment with detailed examples",
      weightage: 25,
      category: "SELF",
      status: "PENDING_SELF_RATING",
      selfRating: 0,
      supervisorRating: 0,
      finalRating: 0,
      achievementComments: "",
      supervisorComments: "",
      reviewerComments: ""
    },
    {
      id: 2,
      title: "Cloud Infrastructure Modernization",
      description: "Lead the migration of legacy systems to cloud-based architecture reducing infrastructure costs and improving system performance and reliability",
      targetValue: "Migrate 75% of systems to cloud by Q4",
      weightage: 20,
      category: "CLOUD",
      status: "PENDING_SELF_RATING",
      selfRating: 0,
      supervisorRating: 0,
      finalRating: 0,
      achievementComments: "",
      supervisorComments: "",
      reviewerComments: ""
    },
    {
      id: 3,
      title: "Team Leadership & Development",
      description: "Develop a high-performing team of 10+ engineers with skill enhancement programs and achieve 100% retention rate",
      targetValue: "90% team satisfaction score, 2 promotions",
      weightage: 20,
      category: "TEAM",
      status: "PENDING_SELF_RATING",
      selfRating: 0,
      supervisorRating: 0,
      finalRating: 0,
      achievementComments: "",
      supervisorComments: "",
      reviewerComments: ""
    },
    {
      id: 4,
      title: "Cost Optimization & Efficiency",
      description: "Reduce AWS costs through architecture optimization and implementation of cost monitoring mechanisms and automated scaling",
      targetValue: "15% reduction in cloud infrastructure costs",
      weightage: 20,
      category: "EFFICIENCY",
      status: "PENDING_SELF_RATING",
      selfRating: 0,
      supervisorRating: 0,
      finalRating: 0,
      achievementComments: "",
      supervisorComments: "",
      reviewerComments: ""
    },
    {
      id: 5,
      title: "Innovation & Strategic Initiatives",
      description: "Launch AI/ML-powered solutions for improved customer experience and operational efficiency",
      targetValue: "Deploy 2 AI/ML solutions in production",
      weightage: 15,
      category: "INNOVATION",
      status: "PENDING_SELF_RATING",
      selfRating: 0,
      supervisorRating: 0,
      finalRating: 0,
      achievementComments: "",
      supervisorComments: "",
      reviewerComments: ""
    },
    {
      id: 6,
      title: "Stakeholder Management",
      description: "Establish effective communication channels with stakeholders for better service delivery",
      targetValue: "95% stakeholder satisfaction score",
      weightage: 10,
      category: "STAKEHOLDER",
      status: "PENDING_SELF_RATING",
      selfRating: 0,
      supervisorRating: 0,
      finalRating: 0,
      achievementComments: "",
      supervisorComments: "",
      reviewerComments: ""
    }
   ]
};