// data/sampledata3.ts

export interface TeamMember {
  id: string;
  name: string;
  position: string;
  employeeId: string;
  initials: string;
  department: string;
  location: string;
  experience: string;
  kraStatus: 'Not Assigned' | 'Assigned' | 'In Progress';
}

export const teamMembersData: TeamMember[] = [
  {
    id: '1',
    name: 'Rajesh Kumar',
    position: 'Vice President',
    employeeId: '1002',
    initials: 'RK',
    department: 'Cloud Engineering',
    location: 'Hyderabad',
    experience: '12 years',
    kraStatus: 'Not Assigned'
  },
  {
    id: '2',
    name: 'Priya Sharma',
    position: 'Senior Manager',
    employeeId: '1003',
    initials: 'PS',
    department: 'Infrastructure Services',
    location: 'Mumbai',
    experience: '7.2 years',
    kraStatus: 'Assigned'
  },
  {
    id: '3',
    name: 'Suresh Patel',
    position: 'Manager',
    employeeId: '1004',
    initials: 'SP',
    department: 'Cloud Engineering',
    location: 'Bangalore',
    experience: '5.3 years',
    kraStatus: 'In Progress'
  },
  {
    id: '4',
    name: 'Kavya Reddy',
    position: 'Assistant Manager',
    employeeId: '1005',
    initials: 'KR',
    department: 'Infrastructure Services',
    location: 'Hyderabad',
    experience: '3.8 years',
    kraStatus: 'Not Assigned'
  }
];

export const departments = [
  'All Departments',
  'Cloud Engineering',
  'Infrastructure Services',
  'Software Development',
  'Quality Assurance'
];

export const statusOptions = [
  'All Status',
  'Not Assigned',
  'Assigned',
  'In Progress'
];