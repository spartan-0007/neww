'use client';

import React, { useState, useEffect } from 'react';
import LoginPage from '@/app/login/page';
import Home from '@/app/home/page';
import App from '@/app/page';

const HashRouter: React.FC = () => {
  const [currentRoute, setCurrentRoute] = useState<string>('');

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash;
      const path = hash.startsWith('#') ? hash.substring(1) : hash || '/';
      console.log('Hash:', hash, 'Path:', path); // Debug log
      setCurrentRoute(path);
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);

    return () => {
      window.removeEventListener('hashchange', handleHashChange);
    };
  }, []);

  const validRoutes = ['/login', '/home', '/'];

  const renderComponent = () => {
    console.log('Current route:', currentRoute); // Debug log

    if (currentRoute === '/' || currentRoute === '') {
      return <LoginPage />;
    }

    if (!validRoutes.includes(currentRoute)) {
      return <App />;
    }

    switch(currentRoute) {
      case '/login':
        return <LoginPage />;
      case '/home':
        return <Home />;
      default:
        return <App />;
    }
  };

  return (
    <div>
      {renderComponent()}
    </div>
  );
};

export default HashRouter;