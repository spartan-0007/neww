// If your file is: components/login.tsx
"use client"

import { useState } from 'react';
import { useRouter } from 'next/navigation'; // Add this import
import PersonalInfo from '@/components/personalinfo/personalinfo';
import PerformanceAppraisalList from '@/components/performanceAppriesal/performanceAppreisal';
import KRAEvaluationForm from '@/components/performanceAppriesal/performanceAppreisal'; // Import the second component
import Header from '@/components/header/header';
import Footer from '@/components/footer/footer';
import TeamKRAs from '@/components/teamkra/teamkra';
import Employees from '@/components/Employees/Employees';
import ManageUsers from '@/components/ManageUsers/ManageUsers';
import EmployeeKRAView from '@/components/viewkra/viewkra';
import { samplePerformanceData } from '@/data/krasampledata';



export default function LoginPage() {
  const router = useRouter(); // Add this

  // State to track which component to show
  const [showEvaluationForm, setShowEvaluationForm] = useState(false);
  const [activeTab, setActiveTab] = useState('My KRAs'); // Add this state

  if (!samplePerformanceData || !samplePerformanceData.kras) {
    return (
      <div className="min-h-screen flex flex-col bg-blue-50">
        <Header activeTab={activeTab} onTabChange={setActiveTab} />
        <main className="flex-grow py-8">
          <div className="p-6">
            <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-sm p-6">
              <div className="text-center">
                <h2 className="text-xl font-semibold text-gray-900 mb-2">Loading...</h2>
                <p className="text-gray-600">Please check your data configuration.</p>
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const handleBeginAssessment = () => {
    console.log('Begin assessment clicked');
    setShowEvaluationForm(true); // Switch to evaluation form
  };

  const handleBackToList = () => {
    console.log('Back to list clicked');
    setShowEvaluationForm(false); // Switch back to list
  };

  const handleSaveEvaluation = (kraId: number, score: number, comments: string) => {
    console.log('Evaluation saved:', { kraId, score, comments });
    // Add your logic here to save the evaluation data
    // You might want to update the samplePerformanceData or send to an API
  };

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    // Reset evaluation form state when switching tabs
    if (tab === 'My KRAs') {
      setShowEvaluationForm(false);
    }
  };

  const handleBackToMyKRAs = () => {
    setActiveTab('My KRAs');
    setShowEvaluationForm(false);
  };

  // Handle viewing employee details - navigate to dynamic route
  const handleViewEmployee = (employee: any) => {
    console.log('Viewing employee:', employee);
    // Navigate to the dynamic route with employee ID
    router.push(`/home/view/${employee.employeeId}`);
  };

  return (
    <div className="min-h-screen flex flex-col bg-blue-50">
      <Header activeTab={activeTab} onTabChange={handleTabChange} />
      <main className="flex-grow py-8">
        {activeTab === 'My KRAs' && (
          <>
            <PersonalInfo />
            {/* Conditionally render components based on state */}
            {!showEvaluationForm ? (
              <PerformanceAppraisalList
                data={samplePerformanceData}
                onBeginAssessment={handleBeginAssessment}
              />
            ) : (
              <KRAEvaluationForm
                kras={samplePerformanceData.kras}
                onBackToList={handleBackToList}
                onSaveEvaluation={handleSaveEvaluation}
              />
            )}
          </>
        )}

        {activeTab === 'Team KRAs' && (
          <TeamKRAs
            onBackToMyKRAs={handleBackToMyKRAs}
            onViewEmployee={handleViewEmployee} // Pass the handler to TeamKRAs
          />
        )}
        {activeTab === 'Employees' && (
          <Employees onBackToMyKRAs={handleBackToMyKRAs} />
        )}
        {activeTab === 'Manage Users' && (
          <ManageUsers />
        )}
      </main>
      <Footer />
    </div>
  );
}