'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import TeamKRAs from '@/components/teamkra/teamkra';
const TeamKRAPage: React.FC = () => {
  const router = useRouter();

  const handleBackToMyKRAs = () => {
    router.push('/home'); // Adjust this to your main KRA dashboard route
  };

  const handleViewEmployee = (employee: any) => {
    // Navigate to the employee's individual KRA view
    router.push(`/view/${employee.employeeId}`);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4">
        <TeamKRAs 
          onBackToMyKRAs={handleBackToMyKRAs}
          onViewEmployee={handleViewEmployee}
        />
      </div>
    </div>
  );
};

export default TeamKRAPage;