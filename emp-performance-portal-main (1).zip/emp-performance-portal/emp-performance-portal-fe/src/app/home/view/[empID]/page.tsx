import ViewKRA from '@/components/viewkra/viewkra';
import { teamMembersData } from '@/data/sampledata3';

// This function is required for static export with dynamic routes
export async function generateStaticParams() {
  // Generate params for all possible employee IDs
  return teamMembersData.map((member) => ({
    empID: member.employeeId,
  }));
}

export default function EmployeeViewPage() {
  return <ViewKRA />;
}