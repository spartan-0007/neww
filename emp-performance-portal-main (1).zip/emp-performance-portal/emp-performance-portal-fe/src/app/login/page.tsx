// app/login/page.tsx
'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/navigation';

interface FormData {
  employeeCode: string;
  password: string;
  rememberMe: boolean;
}

const LoginPage: React.FC = () => {
  const router = useRouter();
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [formData, setFormData] = useState<FormData>({
    employeeCode: '',
    password: '',
    rememberMe: false
  });
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  const togglePassword = (): void => {
    setShowPassword(!showPassword);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    // Clear error when user types
    if (error) setError('');
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      // Mock authentication for testing
      const mockAuth = async () => {
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Mock users - replace with actual API call
        const users = [
          { employeeCode: 'EMP001', password: 'password123', role: 'employee' },
          { employeeCode: 'SUP001', password: 'password123', role: 'superviser' },
          { employeeCode: '1001', password: 'admin', role: 'superviser' }, // Amit Sharma
        ];

        const user = users.find(
          u => u.employeeCode === formData.employeeCode && u.password === formData.password
        );

        if (user) {
          return { success: true, role: user.role, token: 'mock-jwt-token' };
        } else {
          return { success: false, message: 'Invalid credentials' };
        }
      };

      const response = await mockAuth();

      // For production, replace above with:
      /*
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          employeeCode: formData.employeeCode,
          password: formData.password,
        }),
      });

      const data = await response.json();
      */

      if (response.success) {
        // Store auth token
        localStorage.setItem('authToken', response.token);
        localStorage.setItem('userRole', response.role);

        // Redirect based on role - UPDATED ROUTES
        if (response.role === 'supervisor') {
          router.push('/home/supervisor');  // Nested route
        } else {
          router.push('/home');  // Employee goes to /home
        }
      } else {
        setError(response.message || 'Invalid employee code or password');
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
      console.error('Login error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden flex items-center justify-end pr-[5%]">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/images/hr2.jpg"
          alt="Background"
          fill
          className="object-cover"
          quality={100}
          priority
        />
        <div className="absolute inset-0 bg-blue-900/40"></div>
      </div>

      {/* Background static HR icons */}
      <div className="absolute top-[20%] left-[10%] text-white/10 text-2xl z-10">👥</div>
      <div className="absolute top-[60%] left-[85%] text-white/10 text-2xl z-10">📊</div>
      <div className="absolute top-[80%] left-[15%] text-white/10 text-2xl z-10">🎯</div>
      <div className="absolute top-[30%] left-[80%] text-white/10 text-2xl z-10">📈</div>
      <div className="absolute top-[70%] left-[70%] text-white/10 text-2xl z-10">⚡</div>

      {/* Main login container */}
      <div className="bg-white/95 backdrop-blur-lg rounded-3xl p-10 max-w-md w-[90%] shadow-[0_20px_60px_rgba(0,0,0,0.3)] text-center relative z-20 md:w-full">
        {/* App icon */}
        <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl mx-auto mb-5 flex items-center justify-center text-white text-3xl shadow-[0_8px_25px_rgba(59,130,246,0.3)]">
          📊
        </div>

        {/* Company branding */}
        <h1 className="text-3xl font-bold text-blue-800 mb-2">IFTAS</h1>
        <h2 className="text-lg text-gray-600 mb-2 font-semibold">HR Performance Portal</h2>
        <p className="text-sm text-gray-400 mb-8">Indian Financial Technology & Allied Services</p>

        {/* Welcome section */}
        <div className="bg-gradient-to-br from-blue-500 to-indigo-600 text-white p-6 rounded-2xl mb-8">
          <h3 className="text-2xl font-bold mb-2">Welcome Back</h3>
          <p className="text-sm opacity-90">Sign in to access your performance dashboard</p>
        </div>

        {/* Error message */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg mb-4 text-sm">
            {error}
          </div>
        )}

        {/* Login form */}
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="text-left">
            <label className="block mb-2 text-gray-700 font-semibold text-sm">Employee Code</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 text-lg z-10">👤</span>
              <input 
                type="text" 
                name="employeeCode"
                className="w-full pl-12 pr-5 py-4 border-2 border-gray-200 rounded-xl text-base bg-gray-50 transition-all duration-300 focus:border-blue-500 focus:bg-white focus:shadow-[0_0_0_3px_rgba(59,130,246,0.1)] outline-none placeholder-gray-400" 
                placeholder="Enter your employee code"
                value={formData.employeeCode}
                onChange={handleInputChange}
                required
                disabled={isLoading}
              />
            </div>
          </div>

          <div className="text-left">
            <label className="block mb-2 text-gray-700 font-semibold text-sm">Password</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 text-lg z-10">🔒</span>
              <input 
                type={showPassword ? 'text' : 'password'}
                name="password"
                className="w-full pl-12 pr-12 py-4 border-2 border-gray-200 rounded-xl text-base bg-gray-50 transition-all duration-300 focus:border-blue-500 focus:bg-white focus:shadow-[0_0_0_3px_rgba(59,130,246,0.1)] outline-none placeholder-gray-400" 
                placeholder="Enter your password"
                value={formData.password}
                onChange={handleInputChange}
                required
                disabled={isLoading}
              />
              <button 
                type="button" 
                className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-blue-500 text-lg flex items-center justify-center p-1 z-20"
                onClick={togglePassword}
                aria-label={showPassword ? 'Hide password' : 'Show password'}
                disabled={isLoading}
              >
                {showPassword ? '🙈' : '👁️'}
              </button>
            </div>
          </div>

          <div className="flex justify-between items-center text-sm">
            <label className="flex items-center gap-2 text-gray-700 cursor-pointer">
              <input 
                type="checkbox" 
                name="rememberMe"
                checked={formData.rememberMe}
                onChange={handleInputChange}
                className="w-4 h-4 accent-blue-500 cursor-pointer"
                disabled={isLoading}
              />
              <span>Remember me</span>
            </label>
            <a href="#" className="text-blue-500 font-medium hover:underline">Forgot password?</a>
          </div>

          <button 
            type="submit" 
            className="w-full py-4 bg-gradient-to-br from-blue-500 to-indigo-600 text-white rounded-xl text-base font-semibold transition-all duration-300 shadow-[0_4px_15px_rgba(59,130,246,0.3)] hover:-translate-y-0.5 hover:shadow-[0_6px_20px_rgba(59,130,246,0.4)] active:translate-y-0 disabled:opacity-60 disabled:cursor-not-allowed disabled:transform-none"
            disabled={!formData.employeeCode || !formData.password || isLoading}
          >
            {isLoading ? 'Signing In...' : 'Sign In'}
          </button>
        </form>

        {/* Support section */}
        <div className="mt-6 pt-5 border-t border-gray-200 text-sm text-gray-500">
          Need assistance? Contact <a href="#" className="text-blue-500 font-semibold hover:underline">IT Support</a>
        </div>

        {/* Demo credentials hint - Remove in production */}
        <div className="mt-4 p-3 bg-blue-50 rounded-lg text-xs text-blue-600">
          <p className="font-semibold mb-1">Demo Credentials:</p>
          <p>Employee: EMP001 / password123</p>
          <p>Supervisor: SUP001 / password123</p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;