'use client';

import { useEffect } from 'react';
import HashRouter from '@/utils/HashRouter';

export default function Home() {
  useEffect(() => {
    console.log('Home page loaded');
    
    if (window.location.pathname === '/' && window.location.hash === '') {
      window.location.hash = '/login';
    }
  }, []);

  return <HashRouter />;
}
