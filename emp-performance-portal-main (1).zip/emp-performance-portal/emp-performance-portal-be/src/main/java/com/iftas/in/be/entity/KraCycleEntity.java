package com.iftas.in.be.entity;

import com.iftas.in.be.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDate;

@Entity
@Table(name = "kra_cycles", indexes = {
        @Index(name = "idx_cycle_status", columnList = "status"),
        @Index(name = "idx_cycle_dates", columnList = "start_date,end_date")
})
@Data
@EqualsAndHashCode(callSuper = true)
public class KraCycleEntity extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "cycle_name", nullable = false, length = 100)
    private String cycleName;

    @Column(name = "start_date", nullable = false)
    private LocalDate startDate;

    @Column(name = "end_date", nullable = false)
    private LocalDate endDate;

    @Column(name = "self_rating_deadline")
    private LocalDate selfRatingDeadline;

    @Column(name = "supervisor_rating_deadline")
    private LocalDate supervisorRatingDeadline;

    @Column(name = "reviewer_rating_deadline")
    private LocalDate reviewerRatingDeadline;

    @Enumerated(EnumType.STRING)
    @Column(columnDefinition = "ENUM('DRAFT','ACTIVE','COMPLETED','CANCELLED') DEFAULT 'DRAFT'")
    private CycleStatus status = CycleStatus.DRAFT;

    public enum CycleStatus {
        DRAFT, ACTIVE, COMPLETED, CANCELLED
    }
}