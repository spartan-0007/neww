package com.iftas.in.be.exceptions;

public class PasswordResetRequiredException extends RuntimeException {
    public PasswordResetRequiredException(String message) {
        super(message);
    }
}