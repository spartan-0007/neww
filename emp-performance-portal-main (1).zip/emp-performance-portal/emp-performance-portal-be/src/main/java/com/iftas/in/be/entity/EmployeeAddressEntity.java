package com.iftas.in.be.entity;

import com.iftas.in.be.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "employee_addresses", indexes = {
        @Index(name = "idx_address_employee", columnList = "employee_id"),
        @Index(name = "idx_address_type", columnList = "address_type")
})
@Data
@EqualsAndHashCode(callSuper = true)
public class EmployeeAddressEntity extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id", nullable = false)
    private EmployeeEntity employee;

    @Enumerated(EnumType.STRING)
    @Column(name = "address_type", nullable = false)
    private AddressType addressType;

    @Column(name = "address_line1", length = 200)
    private String addressLine1;

    @Column(name = "address_line2", length = 200)
    private String addressLine2;

    @Column(length = 100)
    private String city;

    @Column(length = 100)
    private String state;

    @Column(length = 100)
    private String country;

    @Column(length = 20)
    private String pincode;

    public enum AddressType {
        RESIDENTIAL, POSTING, PERMANENT
    }
}