package com.iftas.in.be.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "kra_workflow_history", indexes = {
        @Index(name = "idx_workflow_rating", columnList = "kra_rating_id"),
        @Index(name = "idx_workflow_actor", columnList = "actor_id")
})
@Data
@EqualsAndHashCode(callSuper = true)
public class KraWorkflowHistoryEntity extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "kra_rating_id", nullable = false)
    private KraRatingEntity kraRating;

    @Column(name = "from_status", length = 50)
    private String fromStatus;

    @Column(name = "to_status", nullable = false, length = 50)
    private String toStatus;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "actor_id", nullable = false)
    private EmployeeEntity actor;

    @Column(columnDefinition = "TEXT")
    private String comments;
}