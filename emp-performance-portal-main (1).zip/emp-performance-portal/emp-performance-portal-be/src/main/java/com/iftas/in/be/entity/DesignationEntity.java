package com.iftas.in.be.entity;


import com.iftas.in.be.entity.BaseEntity;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import jakarta.persistence.*;

@Entity
@Table(name = "designations", indexes = {
        @Index(name = "idx_designation_level", columnList = "level_order"),
        @Index(name = "idx_designation_code", columnList = "code")
})
@Data
@EqualsAndHashCode(callSuper = true)
public class DesignationEntity extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 10, unique = true)
    private String code;

    @Column(nullable = false, length = 100)
    private String name;

    @Column(name = "level_order", nullable = false)
    private Integer levelOrder;
}