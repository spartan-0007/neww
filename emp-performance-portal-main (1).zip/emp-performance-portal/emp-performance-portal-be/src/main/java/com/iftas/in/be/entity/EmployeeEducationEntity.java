package com.iftas.in.be.entity;


import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

@Entity
@Table(name = "employee_education", indexes = {
        @Index(name = "idx_education_employee", columnList = "employee_id")
})
@Data
@EqualsAndHashCode(callSuper = true)
public class EmployeeEducationEntity extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id", nullable = false)
    private com.iftas.in.be.entity.EmployeeEntity employee;

    @Column(nullable = false, length = 100)
    private String degree;

    @Column(length = 100)
    private String specialization;

    @Column(length = 200)
    private String institution;

    @Column(name = "passing_year")
    private Integer passingYear;

    @Column(precision = 5, scale = 2)
    private BigDecimal percentage;
}