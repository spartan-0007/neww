package com.iftas.in.be.service;

import com.iftas.in.be.entity.EmployeeEntity;
import com.iftas.in.be.exceptions.InvalidTokenException;
import com.iftas.in.be.exceptions.UserNotFoundException;
import com.iftas.in.be.model.UserProfile;
import com.iftas.in.be.model.UserProfileResponse;
import com.iftas.in.be.model.UserProfileResponseData;
import com.iftas.in.be.repository.EmployeeRepository;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.time.OffsetDateTime;
import java.util.Objects;
import java.util.Optional;

@Service
public class UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    private final EmployeeRepository employeeRepository;
    private final KeycloakTokenService keycloakTokenService;


    public UserService(EmployeeRepository employeeRepository, KeycloakTokenService keycloakTokenService) {
        this.employeeRepository = employeeRepository;
        this.keycloakTokenService = keycloakTokenService;
    }

    /**
     * Gets current user profile using Spring Security context (most efficient)
     */
    public UserProfile getCurrentUserProfile() {
        logger.info("Fetching current user profile from Security Context");

        try {
            String keycloakUserId = getCurrentUserKeycloakId();

            Optional<EmployeeEntity> employeeOpt = employeeRepository.findByKeycloakUserIdAndIsActiveTrue(keycloakUserId);

            if (employeeOpt.isEmpty()) {
                logger.error("Employee not found for Keycloak user ID: {}", keycloakUserId);
                throw new UserNotFoundException("Employee not found for user ID: " + keycloakUserId);
            }

            EmployeeEntity employee = employeeOpt.get();

            Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

            return buildUserProfile(employee, jwt);

        } catch (InvalidTokenException | UserNotFoundException e) {
            throw e;
        } catch (Exception e) {
            logger.error("Error fetching user profile: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to fetch user profile", e);
        }
    }

    /**
     * Gets current user profile using access token (fallback method for manual token handling)
     */
    public UserProfile getCurrentUserProfile(String accessToken) {
        logger.info("Fetching user profile with access token");

        try {
            Jwt jwt = decodeToken(accessToken);
            String keycloakUserId = jwt.getClaimAsString("sub");

            if (keycloakUserId == null) {
                logger.error("Keycloak user ID not found in token");
                throw new InvalidTokenException("Invalid token: user ID not found");
            }
            Optional<EmployeeEntity> employeeOpt = employeeRepository.findByKeycloakUserIdAndIsActiveTrue(keycloakUserId);

            if (employeeOpt.isEmpty()) {
                logger.error("Employee not found for Keycloak user ID: {}", keycloakUserId);
                throw new UserNotFoundException("Employee not found for user ID: " + keycloakUserId);
            }

            EmployeeEntity employee = employeeOpt.get();

            return buildUserProfile(employee, jwt);

        } catch (InvalidTokenException | UserNotFoundException e) {
            throw e;
        } catch (Exception e) {
            logger.error("Error fetching user profile: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to fetch user profile", e);
        }
    }

    /**
     * Helper method to decode JWT token
     */
    private Jwt decodeToken(String accessToken) {
        try {
            return org.springframework.security.oauth2.jwt.NimbusJwtDecoder.withJwkSetUri("your-jwk-set-uri").build().decode(accessToken);
        } catch (Exception e) {
            logger.error("Failed to decode JWT token: {}", e.getMessage());
            throw new InvalidTokenException("Invalid JWT token");
        }
    }

    /**
     * Gets user profile using refresh token from cookies
     */
    public UserProfile getCurrentUserProfileWithRefresh() {
        logger.info("Fetching current user profile with token refresh");

        try {
            ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            HttpServletRequest request = Objects.requireNonNull(attributes, "Request context not available").getRequest();

            String accessToken = extractTokenFromCookie(request, "access_token");
            String refreshToken = extractTokenFromCookie(request, "refresh_token");

            if (accessToken == null) {
                logger.warn("Access token not found in cookies");
                throw new InvalidTokenException("Access token not found in cookies");
            }

            if (keycloakTokenService.isTokenExpired(accessToken)) {
                logger.info("Access token expired, attempting refresh");

                if (refreshToken == null || keycloakTokenService.isRefreshTokenExpired(refreshToken)) {
                    logger.warn("No valid refresh token available");
                    throw new InvalidTokenException("Session expired. Please log in again.");
                }

                var newTokens = keycloakTokenService.refreshAccessToken(refreshToken);
                accessToken = newTokens.getAccessToken();

            }

            return getCurrentUserProfile(accessToken);

        } catch (InvalidTokenException | UserNotFoundException e) {
            throw e;
        } catch (Exception e) {
            logger.error("Error fetching user profile with refresh: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to fetch user profile with refresh", e);
        }
    }

    /**
     * Gets current employee from database using Security Context
     */
    public EmployeeEntity getCurrentEmployee() {
        logger.info("Fetching current employee from Security Context");

        try {
            String keycloakUserId = getCurrentUserKeycloakId();

            Optional<EmployeeEntity> employeeOpt = employeeRepository.findByKeycloakUserIdAndIsActiveTrue(keycloakUserId);

            if (employeeOpt.isEmpty()) {
                logger.error("Employee not found for Keycloak user ID: {}", keycloakUserId);
                throw new UserNotFoundException("Employee not found for user ID: " + keycloakUserId);
            }

            return employeeOpt.get();

        } catch (InvalidTokenException | UserNotFoundException e) {
            throw e;
        } catch (Exception e) {
            logger.error("Error fetching current employee: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to fetch current employee", e);
        }
    }

    /**
     * Extracts token from cookies
     */
    private String extractTokenFromCookie(HttpServletRequest request, String cookieName) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookieName.equals(cookie.getName())) {
                    return cookie.getValue();
                }
            }
        }
        return null;
    }

    /**
     * Builds user profile response from employee entity and JWT
     */
    private UserProfile buildUserProfile(EmployeeEntity employee, Jwt jwt) {

        UserProfile userProfile = new UserProfile();

        try {

            setFieldIfExists(userProfile, "id", employee.getId());
            setFieldIfExists(userProfile, "empCode", employee.getEmpCode());
            setFieldIfExists(userProfile, "keycloakUserId", employee.getKeycloakUserId());
            setFieldIfExists(userProfile, "firstName", employee.getFirstName());
            setFieldIfExists(userProfile, "middleName", employee.getMiddleName());
            setFieldIfExists(userProfile, "lastName", employee.getLastName());
            setFieldIfExists(userProfile, "email", employee.getEmail());
            setFieldIfExists(userProfile, "phone", employee.getPhone());
            setFieldIfExists(userProfile, "dateOfJoining", employee.getDateOfJoining());
            setFieldIfExists(userProfile, "dateOfBirth", employee.getDateOfBirth());
            setFieldIfExists(userProfile, "isActive", employee.getIsActive());
            setFieldIfExists(userProfile, "engagementType", employee.getEngagementType());
            setFieldIfExists(userProfile, "employmentSubtype", employee.getEmploymentSubtype());
            setFieldIfExists(userProfile, "maritalStatus", employee.getMaritalStatus());
            setFieldIfExists(userProfile, "bloodGroup", employee.getBloodGroup());
            setFieldIfExists(userProfile, "username", jwt.getClaimAsString("preferred_username"));
            setFieldIfExists(userProfile, "emailVerified", jwt.getClaimAsBoolean("email_verified"));
            if (employee.getDepartmentEntity() != null) {
                setFieldIfExists(userProfile, "departmentId", employee.getDepartmentEntity().getId());
                setFieldIfExists(userProfile, "departmentName", employee.getDepartmentEntity().getName());
                setFieldIfExists(userProfile, "departmentCode", employee.getDepartmentEntity().getCode());
            }

            if (employee.getDesignationEntity() != null) {
                setFieldIfExists(userProfile, "designationId", employee.getDesignationEntity().getId());
                setFieldIfExists(userProfile, "designationName", employee.getDesignationEntity().getName());
                setFieldIfExists(userProfile, "designationCode", employee.getDesignationEntity().getCode());
                setFieldIfExists(userProfile, "designationLevel", employee.getDesignationEntity().getLevelOrder());
            }

            if (employee.getLocation() != null) {
                setFieldIfExists(userProfile, "locationId", employee.getLocation().getId());
                setFieldIfExists(userProfile, "locationName", employee.getLocation().getName());
                setFieldIfExists(userProfile, "locationCode", employee.getLocation().getCode());
                setFieldIfExists(userProfile, "locationCity", employee.getLocation().getCity());
            }

        } catch (Exception e) {
            logger.warn("Error mapping employee data to UserProfile: {}", e.getMessage());
        }

        return userProfile;
    }

    /**
     * Helper method to set field value using reflection if the setter exists
     */
    private void setFieldIfExists(UserProfile userProfile, String fieldName, Object value) {
        try {
            String setterName = "set" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);

            java.lang.reflect.Method[] methods = userProfile.getClass().getMethods();
            for (java.lang.reflect.Method method : methods) {
                if (method.getName().equals(setterName) && method.getParameterCount() == 1) {
                    method.invoke(userProfile, value);
                    break;
                }
            }
        } catch (Exception e) {
            logger.debug("Could not set field {} on UserProfile: {}", fieldName, e.getMessage());
        }
    }

    /**
     * Validates current user session using Security Context
     */
    public boolean isCurrentUserSessionValid() {
        try {
            Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            return jwt != null && !jwt.getExpiresAt().isBefore(java.time.Instant.now());
        } catch (Exception e) {
            logger.error("Error validating user session: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Gets current user's Keycloak ID from Security Context
     */
    public String getCurrentUserKeycloakId() {
        try {
            Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            return jwt.getClaimAsString("sub");
        } catch (Exception e) {
            logger.error("Error getting current user Keycloak ID: {}", e.getMessage());
            throw new InvalidTokenException("Failed to get current user Keycloak ID from Security Context");
        }
    }

    /**
     * Gets the full JWT token from Security Context
     */
    public Jwt getCurrentUserJwt() {
        try {
            return (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        } catch (Exception e) {
            logger.error("Error getting current user JWT: {}", e.getMessage());
            throw new InvalidTokenException("Failed to get current user JWT from Security Context");
        }
    }

    /**
     * Gets current user's username from JWT
     */
    public String getCurrentUsername() {
        try {
            Jwt jwt = getCurrentUserJwt();
            return jwt.getClaimAsString("preferred_username");
        } catch (Exception e) {
            logger.error("Error getting current username: {}", e.getMessage());
            throw new InvalidTokenException("Failed to get current username from Security Context");
        }
    }

    /**
     * Gets current user's email from JWT
     */
    public String getCurrentUserEmail() {
        try {
            Jwt jwt = getCurrentUserJwt();
            return jwt.getClaimAsString("email");
        } catch (Exception e) {
            logger.error("Error getting current user email: {}", e.getMessage());
            throw new InvalidTokenException("Failed to get current user email from Security Context");
        }
    }

    /**
     * Gets current user's session ID from JWT
     */
    public String getCurrentUserSessionId() {
        try {
            Jwt jwt = getCurrentUserJwt();
            return jwt.getClaimAsString("sid");
        } catch (Exception e) {
            logger.error("Error getting current user session ID: {}", e.getMessage());
            throw new InvalidTokenException("Failed to get current user session ID from Security Context");
        }
    }

    /**
     * Logout current user (requires KeycloakTokenService)
     */
    public void logoutCurrentUser() {
        if (keycloakTokenService == null) {
            throw new UnsupportedOperationException("KeycloakTokenService not available. Use constructor with KeycloakTokenService parameter.");
        }

        try {
            Jwt jwt = getCurrentUserJwt();
            String accessToken = jwt.getTokenValue();
            keycloakTokenService.logoutUserUsingToken(accessToken);
            logger.info("Successfully logged out user: {}", getCurrentUsername());
        } catch (Exception e) {
            logger.error("Error logging out current user: {}", e.getMessage());
            throw new RuntimeException("Failed to logout current user", e);
        }
    }
}