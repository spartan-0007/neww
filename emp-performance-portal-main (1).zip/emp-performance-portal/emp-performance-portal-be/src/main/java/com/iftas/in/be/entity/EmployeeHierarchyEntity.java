package com.iftas.in.be.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDate;

@Entity
@Table(name = "employee_hierarchy",
        uniqueConstraints = @UniqueConstraint(columnNames = {"employee_id", "is_current"}),
        indexes = {
                @Index(name = "idx_hierarchy_supervisor", columnList = "supervisor_id"),
                @Index(name = "idx_hierarchy_reviewer", columnList = "reviewer_id"),
                @Index(name = "idx_hierarchy_current", columnList = "is_current"),
                @Index(name = "idx_emp_hierarchy_effective", columnList = "effective_from,effective_to")
        }
)
@Data
@EqualsAndHashCode(callSuper = true)
public class EmployeeHierarchyEntity extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id", nullable = false)
    private EmployeeEntity employee;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "supervisor_id")
    private EmployeeEntity supervisor;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "reviewer_id")
    private EmployeeEntity reviewer;

    @Column(name = "effective_from", nullable = false)
    private LocalDate effectiveFrom;

    @Column(name = "effective_to")
    private LocalDate effectiveTo;

    @Column(name = "is_current", columnDefinition = "TINYINT(1) DEFAULT 1")
    private Boolean isCurrent = true;
}