package com.iftas.in.be.utils;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.iftas.in.be.model.ApiResponseError;
import com.iftas.in.be.model.ModelApiResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.OffsetDateTime;
import java.util.Map;


public class ResponseBuilder {
    
    private static final ObjectMapper objectMapper = new ObjectMapper();
    
    static {
        // Configure ObjectMapper for better compatibility
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.registerModule(new JavaTimeModule());
    }
    
    // Success responses
    public static ResponseEntity<ModelApiResponse> success(Object data, String message) {
        return success(data, message, HttpStatus.OK);
    }
    
    public static ResponseEntity<ModelApiResponse> success(Object data, String message, HttpStatus status) {
        ModelApiResponse response = new ModelApiResponse();
        response.setSuccess(true);
        response.setMessage(message);
        response.setData(convertToMap(data));
        response.setError(null);
        
        return ResponseEntity.status(status).body(response);
    }
    
    // Convert any object to Map<String, Object>
    @SuppressWarnings("unchecked")
    private static Map<String, Object> convertToMap(Object data) {
        if (data == null) {
            return null;
        }
        
        if (data instanceof Map) {
            return (Map<String, Object>) data;
        }
        
        // Use Jackson to convert POJO to Map
        return objectMapper.convertValue(data, Map.class);
    }
    
    // Convenience methods
    public static ResponseEntity<ModelApiResponse> success(Object data) {
        return success(data, "Operation completed successfully");
    }
    
    public static ResponseEntity<ModelApiResponse> successNoData(String message) {
        return success(null, message);
    }
    
    // Error methods remain the same...
    public static ResponseEntity<ModelApiResponse> error(String errorCode, String errorMessage, HttpStatus status) {
        ApiResponseError error = new ApiResponseError();
        error.setCode(errorCode);
        error.setMessage(errorMessage);
        error.setTimestamp(OffsetDateTime.now());
        
        ModelApiResponse response = new ModelApiResponse();
        response.setSuccess(false);
        response.setMessage(errorMessage);
        response.setData(null);
        response.setError(error);
        
        return ResponseEntity.status(status).body(response);
    }
}