package com.iftas.in.be;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SfmsPerformanceTrackerBeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SfmsPerformanceTrackerBeApplication.class, args);
	}

}
