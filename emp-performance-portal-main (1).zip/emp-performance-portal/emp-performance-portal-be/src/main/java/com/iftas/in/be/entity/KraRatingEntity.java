package com.iftas.in.be.entity;

import com.iftas.in.be.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "kra_ratings", indexes = {
        @Index(name = "idx_rating_status", columnList = "status"),
        @Index(name = "idx_rating_emp_kra", columnList = "employee_kra_id"),
        @Index(name = "idx_kra_ratings_submitted", columnList = "self_submitted_at,supervisor_submitted_at,reviewer_submitted_at")
})
@Data
@EqualsAndHashCode(callSuper = true)
public class KraRatingEntity extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_kra_id", nullable = false)
    private EmployeeKraEntity employeeKra;

    @Column(name = "self_rating", precision = 3, scale = 2)
    private BigDecimal selfRating;

    @Column(name = "self_comments", columnDefinition = "TEXT")
    private String selfComments;

    @Column(name = "self_achievement", length = 500)
    private String selfAchievement;

    @Column(name = "self_submitted_at")
    private LocalDateTime selfSubmittedAt;

    @Column(name = "supervisor_rating", precision = 3, scale = 2)
    private BigDecimal supervisorRating;

    @Column(name = "supervisor_comments", columnDefinition = "TEXT")
    private String supervisorComments;

    @Column(name = "supervisor_submitted_at")
    private LocalDateTime supervisorSubmittedAt;

    @Column(name = "reviewer_rating", precision = 3, scale = 2)
    private BigDecimal reviewerRating;

    @Column(name = "reviewer_comments", columnDefinition = "TEXT")
    private String reviewerComments;

    @Column(name = "reviewer_submitted_at")
    private LocalDateTime reviewerSubmittedAt;

    @Column(name = "final_rating", precision = 3, scale = 2)
    private BigDecimal finalRating;

    @Enumerated(EnumType.STRING)
    @Column(columnDefinition = "ENUM('PENDING_SELF','PENDING_SUPERVISOR','PENDING_REVIEWER','COMPLETED','REJECTED') DEFAULT 'PENDING_SELF'")
    private RatingStatus status = RatingStatus.PENDING_SELF;

    @Column(name = "rejection_reason", columnDefinition = "TEXT")
    private String rejectionReason;

    public enum RatingStatus {
        PENDING_SELF, PENDING_SUPERVISOR, PENDING_REVIEWER, COMPLETED, REJECTED
    }
}