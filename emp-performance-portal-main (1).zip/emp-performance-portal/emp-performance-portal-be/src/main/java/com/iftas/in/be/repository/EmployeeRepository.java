package com.iftas.in.be.repository;

import com.iftas.in.be.entity.EmployeeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface EmployeeRepository extends JpaRepository<EmployeeEntity, Long> {
    
    /**
     * Find employee by Keycloak user ID and active status
     */
    Optional<EmployeeEntity> findByKeycloakUserIdAndIsActiveTrue(String keycloakUserId);
    
    /**
     * Find employee by employee code and active status
     */
    Optional<EmployeeEntity> findByEmpCodeAndIsActiveTrue(String empCode);
    
    /**
     * Find employee by email and active status
     */
    Optional<EmployeeEntity> findByEmailAndIsActiveTrue(String email);
    
    /**
     * Check if employee exists by Keycloak user ID
     */
    boolean existsByKeycloakUserId(String keycloakUserId);
    
    /**
     * Check if employee exists by employee code
     */
    boolean existsByEmpCode(String empCode);
    
    /**
     * Check if employee exists by email
     */
    boolean existsByEmail(String email);
    
    /**
     * Find supervisor based on department and designation level
     * Fixed: Changed 'level' to 'levelOrder' to match the actual field name in DesignationEntity
     */
    @Query("SELECT e FROM EmployeeEntity e " +
           "WHERE e.departmentEntity.id = :departmentId " +
           "AND e.designationEntity.levelOrder > :designationLevel " +
           "AND e.isActive = true " +
           "ORDER BY e.designationEntity.levelOrder ASC")
    Optional<EmployeeEntity> findSupervisorByDepartmentAndDesignation(
        @Param("departmentId") Long departmentId, 
        @Param("designationLevel") Integer designationLevel
    );
}