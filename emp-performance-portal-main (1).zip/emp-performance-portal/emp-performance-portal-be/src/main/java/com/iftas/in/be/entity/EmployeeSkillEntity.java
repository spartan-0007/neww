package com.iftas.in.be.entity;

import com.iftas.in.be.entity.BaseEntity;
import com.iftas.in.be.entity.EmployeeEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "employee_skills", indexes = {
        @Index(name = "idx_skills_employee", columnList = "employee_id"),
        @Index(name = "idx_skills_name", columnList = "skill_name")
})
@Data
@EqualsAndHashCode(callSuper = true)
public class EmployeeSkillEntity extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id", nullable = false)
    private EmployeeEntity employee;

    @Column(name = "skill_name", nullable = false, length = 100)
    private String skillName;

    @Enumerated(EnumType.STRING)
    @Column(name = "proficiency_level", nullable = false)
    private ProficiencyLevel proficiencyLevel;

    @Column(name = "years_of_experience")
    private Integer yearsOfExperience;

    public enum ProficiencyLevel {
        BEGINNER, INTERMEDIATE, ADVANCED, EXPERT
    }
}