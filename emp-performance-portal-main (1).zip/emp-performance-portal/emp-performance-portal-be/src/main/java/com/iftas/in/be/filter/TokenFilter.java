package com.iftas.in.be.filter;

import com.iftas.in.be.exceptions.PasswordResetRequiredException;
import com.iftas.in.be.exceptions.UserNotFoundException;
import com.iftas.in.be.model.TokenResponse;
import com.iftas.in.be.service.KeycloakTokenService;
import com.iftas.in.be.utils.SecurityUtils;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Objects;

import static org.springframework.web.context.request.RequestAttributes.SCOPE_REQUEST;

@Component
public class TokenFilter extends OncePerRequestFilter {
    private static final Logger logger = LoggerFactory.getLogger(TokenFilter.class);

    private final SecurityUtils securityUtils;
    private final KeycloakTokenService keycloakTokenService;
    private final JwtDecoder jwtDecoder;

    public TokenFilter(SecurityUtils securityUtils, KeycloakTokenService keycloakTokenService, JwtDecoder jwtDecoder) {
        this.securityUtils = securityUtils;
        this.keycloakTokenService = keycloakTokenService;
        this.jwtDecoder = jwtDecoder;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest httpRequest,
                                    HttpServletResponse httpResponse,
                                    FilterChain filterChain) throws ServletException, IOException {

        String requestURI = httpRequest.getRequestURI();
        logger.info("TokenFilter: Processing request for URI: {}", requestURI);

        if (isBypassEndpoint(requestURI)) {
            logger.debug("Bypassing filter for URI: {}", requestURI);
            filterChain.doFilter(httpRequest, httpResponse);
            return;
        }
        if ("/auth/login".equals(requestURI)) {
            handleLogin(httpRequest, httpResponse, filterChain);
            return;
        }
        String accessToken = extractTokenFromCookie(httpRequest, "access_token");
        String refreshToken = extractTokenFromCookie(httpRequest, "refresh_token");

        logger.debug("Extracted access token: {}", accessToken != null ? "Present" : "Not present");
        logger.debug("Extracted refresh token: {}", refreshToken != null ? "Present" : "Not present");

        if (accessToken == null) {
            logger.warn("Missing access token. Sending unauthorized response.");
            sendErrorResponse(httpResponse, HttpServletResponse.SC_UNAUTHORIZED, "Missing access token. Please authenticate.");
            return;
        }
        if (keycloakTokenService.isTokenExpired(accessToken)) {
            logger.info("Access token expired. Attempting refresh...");

            if (refreshToken == null || keycloakTokenService.isRefreshTokenExpired(refreshToken)) {
                logger.warn("No valid refresh token. Forcing re-login.");
                sendErrorResponse(httpResponse, HttpServletResponse.SC_UNAUTHORIZED, "Session expired. Please log in again.");
                return;
            }
            try {
                TokenResponse newTokens = keycloakTokenService.refreshAccessToken(refreshToken);
                addTokenCookies(httpResponse, newTokens);
                accessToken = newTokens.getAccessToken();
            } catch (Exception e) {
                logger.error("Failed to refresh token: {}", e.getMessage());
                sendErrorResponse(httpResponse, HttpServletResponse.SC_UNAUTHORIZED, "Failed to refresh session. Please log in again.");
                return;
            }
        }

        try {
            Jwt jwt = jwtDecoder.decode(accessToken);
            JwtAuthenticationToken authentication = new JwtAuthenticationToken(jwt);
            SecurityContextHolder.getContext().setAuthentication(authentication);
            logger.debug("Security context set with JWT authentication for user: {}", jwt.getClaimAsString("preferred_username"));
        } catch (Exception e) {
            logger.error("Failed to decode JWT token: {}", e.getMessage());
            sendErrorResponse(httpResponse, HttpServletResponse.SC_UNAUTHORIZED, "Invalid token. Please log in again.");
            return;
        }
        logger.debug("Token validated. Proceeding with request.");
        filterChain.doFilter(httpRequest, httpResponse);
    }

    /**
     * Extracts a token from cookies (returns null if not found).
     */
    private String extractTokenFromCookie(HttpServletRequest request, String cookieName) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookieName.equals(cookie.getName())) {
                    return cookie.getValue();
                }
            }
        }
        return null;
    }

    private boolean isBypassEndpoint(String requestURI) {
        return "/auth/forget-password".equals(requestURI) ||
                "/auth/validate-otp".equals(requestURI) ||
                "/auth/resend-otp".equals(requestURI) ||
                "/auth/change-password/change".equals(requestURI) ||
                "/auth/reset-password".equals(requestURI) ||
                "/auth/refresh-token".equals(requestURI);
    }

    private void handleLogin(HttpServletRequest httpRequest, HttpServletResponse httpResponse, FilterChain filterChain) throws IOException, ServletException {
        String username = httpRequest.getParameter("username");
        String password = httpRequest.getParameter("password");
        logger.info("Handling login for user: {}", username);

        if (username.isEmpty() || password.isEmpty()) {
            sendErrorResponse(httpResponse, HttpServletResponse.SC_BAD_REQUEST, "Username and password are required.");
            return;
        }

        try {
            TokenResponse tokenResponse = keycloakTokenService.authenticateUser(username, password);
            addTokenCookies(httpResponse, tokenResponse);
            ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            Objects.requireNonNull(attributes).setAttribute("tokenResponse", tokenResponse, SCOPE_REQUEST);

            filterChain.doFilter(httpRequest, httpResponse);
        } catch (UserNotFoundException e) {
            sendErrorResponse(httpResponse, HttpServletResponse.SC_UNAUTHORIZED, "User not found.");
        } catch (PasswordResetRequiredException e) {
            sendErrorResponse(httpResponse, HttpServletResponse.SC_BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            sendErrorResponse(httpResponse, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }

    private void sendErrorResponse(HttpServletResponse response, int status, String message) throws IOException {
        response.setStatus(status);
        response.setContentType("application/json");
        response.getWriter().write("{\"error\": \"" + message + "\"}");
    }

    private void addTokenCookies(HttpServletResponse response, TokenResponse tokenResponse) {
        addCookie(response, "access_token", tokenResponse.getAccessToken(), 3600);
        addCookie(response, "refresh_token", tokenResponse.getRefreshToken(), 3600);
    }

    private void addCookie(HttpServletResponse response, String name, String value, int maxAge) {
        Cookie cookie = new Cookie(name, value);
        cookie.setHttpOnly(true);
        cookie.setSecure(false);
        cookie.setPath("/");
        cookie.setMaxAge(maxAge);
        response.addCookie(cookie);
    }
}