package com.iftas.in.be.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.spec.KeySpec;
import java.util.Arrays;
import java.util.Base64;

@Component
public class SecurityUtils {

    private static final Logger logger = LoggerFactory.getLogger(SecurityUtils.class);
    private static final int ITERATION_COUNT = 65536;
    private static final int KEY_LENGTH = 256;
    private static final int IV_LENGTH = 16;

    @Value("${PASSWORD_ENCRYPTION_KEY}")
    private String secret;

    public String decrypt(String encryptedData) throws GeneralSecurityException {
        logger.debug("Starting decryption process for encrypted data.");
        if (encryptedData == null || encryptedData.isEmpty()) {
            logger.warn("Encrypted data is null or empty.");
            throw new IllegalArgumentException("Encrypted data cannot be null or empty.");
        }

        try {
            logger.debug("Decoding Base64 encrypted data.");
            byte[] cipherData = Base64.getDecoder().decode(encryptedData);
            logger.debug("Base64 decoded data length: {} bytes", cipherData.length);

            logger.debug("Creating ByteBuffer to process encrypted data.");
            ByteBuffer buffer = ByteBuffer.wrap(cipherData);

            boolean hasSaltedHeader = false;
            byte[] header = new byte[8];
            buffer.get(header);
            if (new String(header, StandardCharsets.UTF_8).equals("Salted__")) {
                hasSaltedHeader = true;
                logger.debug("'Salted__' header detected. Continuing after header.");
            } else {
                logger.debug("No 'Salted__' header found. Resetting buffer position to beginning.");
                buffer.position(0);
            }

            byte[] salt = new byte[8];
            buffer.get(salt);
            logger.debug("Extracted salt of length: {} bytes", salt.length);

            byte[] iv = new byte[IV_LENGTH];
            buffer.get(iv);
            logger.debug("Extracted IV of length: {} bytes", iv.length);

            byte[] encrypted = new byte[buffer.remaining()];
            buffer.get(encrypted);
            logger.debug("Extracted encrypted data of length: {} bytes", encrypted.length);

            logger.debug("Initializing PBKDF2 key factory with SHA-256.");
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

            logger.debug("Creating key spec with {} iterations and {} key length.", ITERATION_COUNT, KEY_LENGTH);
            KeySpec spec = new PBEKeySpec(
                    secret.toCharArray(),
                    salt,
                    ITERATION_COUNT,
                    KEY_LENGTH
            );

            logger.debug("Generating secret key.");
            byte[] keyBytes = factory.generateSecret(spec).getEncoded();
            SecretKey key = new SecretKeySpec(keyBytes, "AES");
            logger.debug("Secret key generated successfully.");

            logger.debug("Creating IV parameter spec.");
            IvParameterSpec ivSpec = new IvParameterSpec(iv);

            logger.debug("Initializing AES/CTR/NoPadding cipher for decryption.");
            Cipher cipher = Cipher.getInstance("AES/CTR/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key, ivSpec);
            logger.debug("Cipher initialized successfully.");

            logger.debug("Performing final decryption step.");
            byte[] decryptedData = cipher.doFinal(encrypted);
            logger.debug("Decryption completed. Decrypted data length: {} bytes", decryptedData.length);

            String decryptedText = new String(decryptedData, StandardCharsets.UTF_8);

            logger.debug("Decryption complete. Decrypted text length: {}", decryptedText.length());
            return decryptedText;

        } catch (GeneralSecurityException e) {
            logger.error("Security exception during decryption process: {}", e.getMessage(), e);
            throw e;
        } catch (IllegalArgumentException e) {
            logger.error("Illegal argument exception: {}", e.getMessage(), e);
            throw e;
        } catch (Exception e) {
            logger.error("Unexpected error during decryption: {}", e.getMessage(), e);
            throw new RuntimeException("Unexpected error during decryption.", e);
        } finally {
            if (secret != null) {
                Arrays.fill(secret.toCharArray(), '\0');
            }
        }
    }

}