package com.iftas.in.be.api;

import com.iftas.in.be.exceptions.InvalidTokenException;
import com.iftas.in.be.exceptions.UserNotFoundException;
import com.iftas.in.be.model.ModelApiResponse;
import com.iftas.in.be.model.UserProfile;
import com.iftas.in.be.service.UserService;
import com.iftas.in.be.utils.ResponseBuilder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
@Slf4j
public class AuthenticationController implements AuthApi {

    private final UserService userService;

    @Override
    public ResponseEntity<ModelApiResponse> authLoginPost(String username, String password) {
        MDC.put("username", username != null ? username : "unknown");
        log.info("Starting authLoginPost for user: {}", username);

        try {

            if (username == null || username.trim().isEmpty() ||
                    password == null || password.trim().isEmpty()) {
                log.warn("Missing username or password");
                return ResponseBuilder.error("VALIDATION_ERROR",
                        "Username and password are required", HttpStatus.BAD_REQUEST);
            }

            log.info("Login successful for user: {}", username);
            return ResponseBuilder.successNoData("Token Generated Successfully in HttpOnly Cookies");

        } catch (Exception e) {
            log.error("Unexpected error during authentication for user: {}", username, e);
            return ResponseBuilder.error("AUTHENTICATION_ERROR",
                    "Authentication failed due to server error", HttpStatus.INTERNAL_SERVER_ERROR);

        } finally {
            log.info("Completed authLoginPost for user: {}", username);
            MDC.clear();
        }
    }

    @Override
    public ResponseEntity<ModelApiResponse> authUserGet() {
        MDC.put("operation", "getCurrentUserProfile");
        log.info("Fetching current user profile");

        try {
            String username = userService.getCurrentUsername();
            MDC.put("username", username);

            log.debug("Retrieving profile for user: {}", username);

            UserProfile userProfile = userService.getCurrentUserProfile();

            log.info("Successfully retrieved user profile for user: {}", username);
            return ResponseBuilder.success(userProfile, "User profile retrieved successfully");

        } catch (UserNotFoundException e) {
            log.warn("User not found: {}", e.getMessage());
            return ResponseBuilder.error("USER_NOT_FOUND", "User profile not found", HttpStatus.NOT_FOUND);

        } catch (InvalidTokenException e) {
            log.warn("Invalid token while retrieving user profile: {}", e.getMessage());
            return ResponseBuilder.error("INVALID_TOKEN", "Invalid or expired authentication token", HttpStatus.UNAUTHORIZED);

        } catch (Exception e) {
            log.error("Unexpected error retrieving user profile", e);
            return ResponseBuilder.error("INTERNAL_ERROR",
                    "Failed to retrieve user profile due to server error", HttpStatus.INTERNAL_SERVER_ERROR);

        } finally {
            log.debug("Completed user profile retrieval attempt");
        }

    }
}