package com.iftas.in.be.entity;

import com.iftas.in.be.entity.BaseEntity;
import com.iftas.in.be.entity.EmployeeEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

@Entity
@Table(name = "employee_kras", indexes = {
        @Index(name = "idx_emp_kra_employee", columnList = "employee_id"),
        @Index(name = "idx_emp_kra_cycle", columnList = "kra_cycle_id"),
        @Index(name = "idx_emp_kra_category", columnList = "kra_category_id"),
        @Index(name = "idx_emp_kra_creator", columnList = "created_by")
})
@Data
@EqualsAndHashCode(callSuper = true)
public class EmployeeKraEntity extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id", nullable = false)
    private EmployeeEntity employee;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "kra_cycle_id", nullable = false)
    private com.iftas.in.be.entity.KraCycleEntity kraCycle;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "kra_category_id", nullable = false)
    private com.iftas.in.be.entity.KraCategoryEntity kraCategory;

    @Column(nullable = false, length = 300)
    private String title;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(name = "target_value", length = 200)
    private String targetValue;

    @Column(nullable = false, precision = 5, scale = 2)
    private BigDecimal weightage;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by", nullable = false)
    private String createdBy;
}