package com.iftas.in.be.entity;

import com.iftas.in.be.entity.BaseEntity;
import com.iftas.in.be.entity.EmployeeEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "file_uploads", indexes = {
        @Index(name = "idx_upload_status", columnList = "processed_status"),
        @Index(name = "idx_upload_type", columnList = "upload_type")
})
@Data
@EqualsAndHashCode(callSuper = true)
public class FileUploadEntity extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String filename;

    @Column(name = "original_filename", nullable = false)
    private String originalFilename;

    @Column(name = "file_type", nullable = false, length = 50)
    private String fileType;

    @Column(name = "file_size", nullable = false)
    private Long fileSize;

    @Enumerated(EnumType.STRING)
    @Column(name = "upload_type", nullable = false)
    private UploadType uploadType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "uploaded_by", nullable = false)
    private EmployeeEntity uploadedBy;

    @Enumerated(EnumType.STRING)
    @Column(name = "processed_status", columnDefinition = "ENUM('PENDING','PROCESSING','COMPLETED','FAILED') DEFAULT 'PENDING'")
    private ProcessedStatus processedStatus = ProcessedStatus.PENDING;

    @Column(name = "processed_records", columnDefinition = "INT DEFAULT 0")
    private Integer processedRecords = 0;

    @Column(name = "failed_records", columnDefinition = "INT DEFAULT 0")
    private Integer failedRecords = 0;

    @Column(name = "error_log", columnDefinition = "TEXT")
    private String errorLog;

    public enum UploadType {
        EMPLOYEE_MASTER, KRA_TEMPLATE, OTHER
    }

    public enum ProcessedStatus {
        PENDING, PROCESSING, COMPLETED, FAILED
    }
}