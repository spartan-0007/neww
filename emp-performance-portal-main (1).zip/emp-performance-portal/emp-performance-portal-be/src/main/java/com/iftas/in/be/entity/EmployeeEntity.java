package com.iftas.in.be.entity;

import com.iftas.in.be.entity.BaseEntity;
import com.iftas.in.be.entity.DepartmentEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDate;

@Entity
@Table(name = "employees", indexes = {
        @Index(name = "idx_emp_active", columnList = "is_active"),
        @Index(name = "idx_emp_department", columnList = "department_id"),
        @Index(name = "idx_emp_designation", columnList = "designation_id"),
        @Index(name = "idx_emp_joining_date", columnList = "date_of_joining"),
        @Index(name = "idx_emp_keycloak", columnList = "keycloak_user_id"),
        @Index(name = "idx_emp_email", columnList = "email")
})
@Data
@EqualsAndHashCode(callSuper = true)
public class EmployeeEntity extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "emp_code", nullable = false, length = 50, unique = true)
    private String empCode;

    @Column(name = "keycloak_user_id", nullable = false, unique = true)
    private String keycloakUserId;

    @Column(name = "first_name", nullable = false, length = 100)
    private String firstName;

    @Column(name = "middle_name", length = 100)
    private String middleName;

    @Column(name = "last_name", nullable = false, length = 100)
    private String lastName;

    @Column(nullable = false, length = 150, unique = true)
    private String email;

    @Column(length = 20)
    private String phone;

    @Column(name = "emergency_contact", length = 20)
    private String emergencyContact;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "designation_id", nullable = false)
    private com.iftas.in.be.entity.DesignationEntity designationEntity;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id", nullable = false)
    private DepartmentEntity departmentEntity;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sub_department_id")
    private SubDepartmentEntity subDepartment;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "location_id", nullable = false)
    private LocationEntity location;

    @Column(name = "date_of_joining", nullable = false)
    private LocalDate dateOfJoining;

    @Column(name = "date_of_birth")
    private LocalDate dateOfBirth;

    @Column(name = "confirmation_due_date")
    private LocalDate confirmationDueDate;

    @Column(name = "is_confirmed", columnDefinition = "TINYINT(1) DEFAULT 0")
    private Boolean isConfirmed = false;

    @Enumerated(EnumType.STRING)
    @Column(name = "engagement_type", nullable = false)
    private EngagementType engagementType;

    @Enumerated(EnumType.STRING)
    @Column(name = "employment_subtype", nullable = false)
    private EmploymentSubtype employmentSubtype;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vendor_id")
    private com.iftas.in.be.entity.VendorEntity vendor;

    @Column(name = "contract_start_date")
    private LocalDate contractStartDate;

    @Column(name = "contract_end_date")
    private LocalDate contractEndDate;

    @Column(name = "pan_number_encrypted", columnDefinition = "VARBINARY(500)")
    private byte[] panNumberEncrypted;

    @Column(name = "aadhar_number_encrypted", columnDefinition = "VARBINARY(500)")
    private byte[] aadharNumberEncrypted;

    @Column(name = "account_number_encrypted", columnDefinition = "VARBINARY(500)")
    private byte[] accountNumberEncrypted;

    @Column(name = "bank_name", length = 100)
    private String bankName;

    @Column(name = "ifsc_code", length = 20)
    private String ifscCode;

    @Column(name = "pf_number", length = 50)
    private String pfNumber;

    @Column(name = "uan_number", length = 50)
    private String uanNumber;

    @Enumerated(EnumType.STRING)
    @Column(name = "marital_status")
    private MaritalStatus maritalStatus;

    @Column(name = "blood_group", length = 10)
    private String bloodGroup;

    @Column(name = "previous_experience_months", columnDefinition = "INT DEFAULT 0")
    private Integer previousExperienceMonths = 0;

    @Column(name = "is_active", columnDefinition = "TINYINT(1) DEFAULT 1")
    private Boolean isActive = true;

    @Column(name = "resignation_date")
    private LocalDate resignationDate;

    @Column(name = "last_working_day")
    private LocalDate lastWorkingDay;

    @Column(columnDefinition = "TEXT")
    private String remarks;

    public enum EngagementType {
        ON_ROLL, OFF_ROLL
    }

    public enum EmploymentSubtype {
        PERMANENT, FTC, VENDOR
    }

    public enum MaritalStatus {
        SINGLE, MARRIED, DIVORCED, WIDOWED
    }
}