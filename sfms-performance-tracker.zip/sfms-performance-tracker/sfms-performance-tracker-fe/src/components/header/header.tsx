import React from 'react';
import Image from 'next/image';
import iftasLogo from '@/app/assets/images/iftas_logo.png';
const Header = () => {
  return (
    <header className="flex justify-between items-center bg-[#003399] py-1 px-2">
      <div className="flex-shrink-0">
        <Image src={iftasLogo} alt="IFTAS Logo" width={60} height={25} />
      </div>
      <h1 className="text-white text-lg md:text-xl font-bold mx-auto">
        CHANGE REQUEST FORM
      </h1>
      <div className="flex-shrink-0 invisible">
        <Image src={iftasLogo} alt="IFTAS Logo" width={60} height={25} />
      </div>
    </header>
  );
};

export default Header;