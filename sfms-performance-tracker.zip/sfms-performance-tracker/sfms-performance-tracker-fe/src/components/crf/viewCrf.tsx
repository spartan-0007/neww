"use client";

import React, { useState, useEffect } from 'react';
import Footer from '@/components/footer/footer';
import Header from '@/components/header/header';
import { useDeleteApiCrfId } from '@/lib/api/delete-crf/delete-crf';
import { useQueryClient } from '@tanstack/react-query';
import { useGetApiCrf } from '@/lib/api/get-crf/get-crf';

export default function ViewCrf() {
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage, setRecordsPerPage] = useState(10);
  const [allRecords, setAllRecords] = useState([]);
  const [isInitialLoad, setIsInitialLoad] = useState(true);

  const queryClient = useQueryClient();

  const { data: crfData, isLoading, isError } = useGetApiCrf({
    filter: searchTerm,
    limit: 1000  
  });

  useEffect(() => {
    if (crfData && !isLoading) {
      setAllRecords(crfData);
      setIsInitialLoad(false);
    }
  }, [crfData, isLoading]);

  const totalRecords = allRecords.length;
  const totalPages = Math.ceil(totalRecords / recordsPerPage);
  const startIndex = (currentPage - 1) * recordsPerPage;
  const endIndex = Math.min(startIndex + recordsPerPage, totalRecords);
  const currentRecords = allRecords.slice(startIndex, endIndex);

  const displayColumns = [
    { key: 'id', header: 'ID' },
    { key: 'name', header: 'NAME' },
    { key: 'email', header: 'EMAIL' },
    { key: 'destinationIps', header: 'DEST. IPS' },
    { key: 'port', header: 'PORT' },
    { key: 'closeDate', header: 'CLOSE DATE' }
  ];

  const deleteMutation = useDeleteApiCrfId({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries(['getApiCrf']);
        alert('CRF deleted successfully!');
      },
      onError: (error) => {
        alert('Failed to delete CRF. Please try again.');
      }
    }
  });

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
    setCurrentPage(1);  
  };

  const handleUpdate = (record) => {
    localStorage.setItem('editCrfData', JSON.stringify(record));
    window.location.href = '/#/crf';
  };

  const handleDelete = async (record) => {
    if (confirm(`Are you sure you want to delete CRF with ID: ${record.id}?`)) {
      try {
        await deleteMutation.mutateAsync({ id: record.id });
      } catch (error) {
       
      }
    }
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handlePageClick = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const handleRecordsPerPageChange = (e) => {
    setRecordsPerPage(Number(e.target.value));
    setCurrentPage(1);  
  };

  const getPageNumbers = () => {
    const pageNumbers = [];
    const maxPageItems = 5; 
    
    let startPage = Math.max(1, currentPage - Math.floor(maxPageItems / 2));
    let endPage = startPage + maxPageItems - 1;
    
    if (endPage > totalPages) {
      endPage = totalPages;
      startPage = Math.max(1, endPage - maxPageItems + 1);
    }
    
    for (let i = startPage; i <= endPage; i++) {
      pageNumbers.push(i);
    }
    
    return pageNumbers;
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header />

      <main className="flex-grow bg-white px-6 py-4">
          <div className="min-w-full bg-white border border-gray-200 p-1 rounded shadow-md">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-blue-900 text-xl font-bold border-b-4 border-yellow-400 pb-1">
              View Change Request Forms
            </h2>
            <button
              onClick={() => window.location.href = '/#/crf'}
              className="bg-yellow-400 hover:bg-yellow-500 text-black font-bold py-2 px-6 rounded"
            >
              Add CRF
            </button>
          </div>

          <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
            <div className="relative w-full md:w-1/2">
              <input
                type="text"
                placeholder="Search by name..."
                className="w-full p-2 pl-10 border border-gray-300 rounded"
                value={searchTerm}
                onChange={handleSearch}
              />
              <div className="absolute inset-y-0 left-0 flex items-center pl-3">
                <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            </div>
            <div className="flex items-center">
              <label className="mr-2 text-gray-600">Records per page:</label>
              <select
                value={recordsPerPage}
                onChange={handleRecordsPerPageChange}
                className="border border-gray-300 rounded p-2"
              >
                <option value={10}>10</option>
                <option value={20}>20</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
              </select>
            </div>
          </div>

          {isLoading || isInitialLoad ? (
            <div className="text-center text-gray-500 py-8">
              <div className="inline-block animate-spin mr-2 h-6 w-6 text-blue-500">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
              </div>
              <span>Loading records...</span>
            </div>
          ) : isError ? (
            <div className="text-center text-red-500 py-8">Error: CRF data is currently unavailable.</div>
          ) : currentRecords.length === 0 ? (
            <div className="text-center text-gray-500 py-8">No CRF records available.</div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="min-w-full bg-white border border-gray-200">
                <thead>
                    <tr className="bg-blue-500 text-white uppercase text-xs leading-normal">
                      {displayColumns.map(col => (
                        <th key={col.key} className="py-2 px-4 text-left border-b border-blue-400">
                          {col.header}
                        </th>
                      ))}
                      <th className="py-2 px-4 text-center border-b border-blue-400">ACTIONS</th>
                    </tr>
                  </thead>
                  <tbody className="text-gray-600 text-sm">
                    {currentRecords.map((record) => (
                      <tr key={record.id} className="border-b border-gray-200 hover:bg-gray-50">
                        {displayColumns.map(col => (
                          <td key={col.key} className="py-2 px-4">
                            {record[col.key]}
                          </td>
                        ))}
                        <td className="py-2 px-4 text-center">
                          <div className="flex justify-center space-x-2">
                            <button
                              onClick={() => handleUpdate(record)}
                              className="bg-blue-100 text-blue-600 hover:bg-blue-200 px-3 py-1 rounded"
                            >
                              Update
                            </button>
                            <button
                              onClick={() => handleDelete(record)}
                              disabled={deleteMutation.isLoading}
                              className={`${
                                deleteMutation.isLoading
                                  ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                                  : 'bg-red-100 text-red-600 hover:bg-red-200'
                              } px-3 py-1 rounded`}
                            >
                              {deleteMutation.isLoading ? 'Deleting...' : 'Delete'}
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex flex-col md:flex-row justify-between items-center mt-4 gap-4">
                <div className="text-gray-600 text-sm">
                  {totalRecords > 0 ? 
                    `Showing ${startIndex + 1} to ${endIndex} of ${totalRecords} records` : 
                    'No records found'}
                </div>
                
                <div className="flex flex-wrap justify-center items-center gap-1">
                  <button
                    onClick={handlePrevPage}
                    disabled={currentPage === 1}
                    className={`px-3 py-1 rounded ${
                      currentPage === 1
                        ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                        : 'bg-blue-100 text-blue-600 hover:bg-blue-200'
                    }`}
                  >
                    Previous
                  </button>
                  
                  {getPageNumbers()[0] > 1 && (
                    <>
                      <button
                        onClick={() => handlePageClick(1)}
                        className="px-3 py-1 rounded bg-blue-100 text-blue-600 hover:bg-blue-200"
                      >
                        1
                      </button>
                      {getPageNumbers()[0] > 2 && (
                        <span className="px-2 py-1 text-gray-500">...</span>
                      )}
                    </>
                  )}
                  
                  {getPageNumbers().map(number => (
                    <button
                      key={number}
                      onClick={() => handlePageClick(number)}
                      className={`px-3 py-1 rounded ${
                        currentPage === number
                          ? 'bg-blue-500 text-white'
                          : 'bg-blue-100 text-blue-600 hover:bg-blue-200'
                      }`}
                    >
                      {number}
                    </button>
                  ))}
                  
                  {getPageNumbers()[getPageNumbers().length - 1] < totalPages && (
                    <>
                      {getPageNumbers()[getPageNumbers().length - 1] < totalPages - 1 && (
                        <span className="px-2 py-1 text-gray-500">...</span>
                      )}
                      <button
                        onClick={() => handlePageClick(totalPages)}
                        className="px-3 py-1 rounded bg-blue-100 text-blue-600 hover:bg-blue-200"
                      >
                        {totalPages}
                      </button>
                    </>
                  )}
                  
                  <button
                    onClick={handleNextPage}
                    disabled={currentPage === totalPages || totalPages === 0}
                    className={`px-3 py-1 rounded ${
                      currentPage === totalPages || totalPages === 0
                        ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                        : 'bg-blue-100 text-blue-600 hover:bg-blue-200'
                    }`}
                  >
                    Next
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}