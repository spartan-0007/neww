"use client";

import React from 'react';

interface CRFFormProps {
  formData: any;
  handleChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  handleSubmit: (e: React.FormEvent) => void;
  isSubmitting: boolean;
  submitButtonText: string;
  handleReset: () => void;
  useFormPlaceholders?: boolean;
}

const CRFForm: React.FC<CRFFormProps> = ({
  formData,
  handleChange,
  handleSubmit,
  isSubmitting,
  submitButtonText,
  handleReset,
  useFormPlaceholders = true
}) => {
  const inputClass = "w-full p-2 border border-gray-300 rounded";

  return (
    <form onSubmit={handleSubmit} className="bg-white border border-gray-200 p-6 rounded space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-gray-700 mb-1">Name</label>
          <input
            type="text"
            name="name"
            placeholder={useFormPlaceholders ? "Name" : ""}
            className={inputClass}
            value={formData.name}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label className="block text-gray-700 mb-1">Designation</label>
          <input
            type="text"
            name="designation"
            placeholder={useFormPlaceholders ? "Designation" : ""}
            className={inputClass}
            value={formData.designation}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label className="block text-gray-700 mb-1">Company</label>
          <input
            type="text"
            name="company"
            placeholder={useFormPlaceholders ? "Company" : ""}
            className={inputClass}
            value={formData.company}
            onChange={handleChange}
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-gray-700 mb-1">Location</label>
          <input
            type="text"
            name="location"
            placeholder={useFormPlaceholders ? "Location" : ""}
            className={inputClass}
            value={formData.location}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label className="block text-gray-700 mb-1">Contact Number</label>
          <input
            type="tel"
            name="contactNumber"
            placeholder={useFormPlaceholders ? "Contact Number" : ""}
            className={inputClass}
            value={formData.contactNumber}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label className="block text-gray-700 mb-1">Email</label>
          <input
            type="email"
            name="email"
            placeholder={useFormPlaceholders ? "Email" : ""}
            className={inputClass}
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-gray-700 mb-1">Priority</label>
          <input
            type="text"
            name="priority"
            placeholder={useFormPlaceholders ? "Priority" : ""}
            className={inputClass}
            value={formData.priority}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label className="block text-gray-700 mb-1">CRF Department</label>
          <input
            type="text"
            name="crf_dept"
            placeholder={useFormPlaceholders ? "CRF Department" : ""}
            className={inputClass}
            value={formData.crf_dept}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label className="block text-gray-700 mb-1">Protocol</label>
          <input
            type="text"
            name="protocol"
            placeholder={useFormPlaceholders ? "Protocol" : ""}
            className={inputClass}
            value={formData.protocol}
            onChange={handleChange}
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-gray-700 mb-1">Source IPs</label>
          <input
            type="text"
            name="source_ips"
            placeholder={useFormPlaceholders ? "Source IPs" : ""}
            className={inputClass}
            value={formData.source_ips}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label className="block text-gray-700 mb-1">Source Server Details</label>
          <input
            type="text"
            name="source_server_details"
            placeholder={useFormPlaceholders ? "Source Server Details" : ""}
            className={inputClass}
            value={formData.source_server_details}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label className="block text-gray-700 mb-1">Port</label>
          <input
            type="text"
            name="port"
            placeholder={useFormPlaceholders ? "Port" : ""}
            className={inputClass}
            value={formData.port}
            onChange={handleChange}
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-gray-700 mb-1">Destination IPs</label>
          <input
            type="text"
            name="destination_ips"
            placeholder={useFormPlaceholders ? "Destination IPs" : ""}
            className={inputClass}
            value={formData.destination_ips}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label className="block text-gray-700 mb-1">Destination Server Details</label>
          <input
            type="text"
            name="destination_server_details"
            placeholder={useFormPlaceholders ? "Destination Server Details" : ""}
            className={inputClass}
            value={formData.destination_server_details}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label className="block text-gray-700 mb-1">Port Description</label>
          <input
            type="text"
            name="port_description"
            placeholder={useFormPlaceholders ? "Port Description" : ""}
            className={inputClass}
            value={formData.port_description}
            onChange={handleChange}
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-gray-700 mb-1">Open Date</label>
          <input
            type="date"
            name="open_date"
            className={inputClass}
            value={formData.open_date}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label className="block text-gray-700 mb-1">Close Date</label>
          <input
            type="date"
            name="close_date"
            className={inputClass}
            value={formData.close_date}
            onChange={handleChange}
            required
          />
        </div>
      </div>

      <div>
        <label className="block text-gray-700 mb-1">Reason for Change</label>
        <textarea
          name="reason_for_change"
          placeholder={useFormPlaceholders ? "Reason for Change" : ""}
          className={`${inputClass} h-10`}
          value={formData.reason_for_change}
          onChange={handleChange}
          required
        />
      </div>

      <div className="flex justify-end gap-4">
        <button
          type="submit"
          disabled={isSubmitting}
          className={`bg-yellow-400 hover:bg-yellow-500 text-black font-bold py-2 px-8 rounded flex items-center justify-center ${
            isSubmitting ? 'opacity-70 cursor-not-allowed' : ''
          }`}
        >
          {isSubmitting ? (
            <>
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-black" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              GENERATING...
            </>
          ) : (
            submitButtonText
          )}
        </button>
        <button
          type="button"
          onClick={handleReset}
          className="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-8 rounded"
        >
          RESET
        </button>
      </div>
    </form>
  );
};

export default CRFForm;