"use client";

import React, { useState, useEffect } from 'react';
import Header from '@/components/header/header';
import Footer from '@/components/footer/footer';
import CRFForm from './CRFForm';
import { usePostApiCrf } from '@/lib/api/create-crf/create-crf';
import { usePutApiCrf } from '@/lib/api/update-crf/update-crf';
import { useQueryClient } from '@tanstack/react-query';

const CreateCrf = () => {
  const [formData, setFormData] = useState({
    name: '',
    designation: '',
    company: '',
    location: '',
    contactNumber: '',
    email: '',
    priority: '',
    crf_dept: '',
    protocol: '',
    source_ips: '',
    source_server_details: '',
    destination_ips: '',
    destination_server_details: '',
    port: '',
    port_description: '',
    open_date: '',
    close_date: '',
    reason_for_change: ''
  });

  const [isEditMode, setIsEditMode] = useState(false);
  const [editId, setEditId] = useState(null);
  const [showPopup, setShowPopup] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  
  const queryClient = useQueryClient();

  useEffect(() => {
    const editCrfData = localStorage.getItem('editCrfData');
    if (editCrfData) {
      try {
        const parsedData = JSON.parse(editCrfData);
        setEditId(parsedData.id);
        setIsEditMode(true);
        
        setFormData({
          name: parsedData.name || '',
          designation: parsedData.designation || '',
          company: parsedData.company || '',
          location: parsedData.location || '',
          contactNumber: parsedData.contactNumber || '',
          email: parsedData.email || '',
          priority: parsedData.priority || '',
          crf_dept: parsedData.crfDept || '',
          protocol: parsedData.protocol || '',
          source_ips: parsedData.sourceIps || '',
          source_server_details: parsedData.sourceServerDetails || '',
          destination_ips: parsedData.destinationIps || '',
          destination_server_details: parsedData.destinationServerDetails || '',
          port: parsedData.port || '',
          port_description: parsedData.portDescription || '',
          open_date: parsedData.openDate || '',
          close_date: parsedData.closeDate || '',
          reason_for_change: parsedData.reasonForChange || ''
        });
        
        localStorage.removeItem('editCrfData');
      } catch (error) {
        console.error("Error parsing edit data:", error);
      }
    }
  }, []);

  const createCrfMutation = usePostApiCrf({
    mutation: {
      onMutate: () => {
        setIsGenerating(true);
      },
      onSuccess: (data) => {
        handleApiSuccess(data, "CRF Excel file generated successfully!");
      },
      onError: (error) => {
        console.error('Error generating Excel:', error);
        alert(`Failed to generate Excel file. Please try again.`);
        setIsGenerating(false);
      }
    }
  });

  const updateCrfMutation = usePutApiCrf({
    mutation: {
      onMutate: () => {
        setIsGenerating(true);
      },
      onSuccess: (data) => {
        handleApiSuccess(data, "CRF updated successfully!");
      },
      onError: (error) => {
        console.error('Error updating CRF:', error);
        alert(`Failed to update CRF. Please try again.`);
        setIsGenerating(false);
      }
    }
  });

  const handleApiSuccess = (data, successMessage) => {
    const url = window.URL.createObjectURL(new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = `CRF_${formData.name.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.xlsx`;
    document.body.appendChild(a);
    a.click();

    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
    setIsGenerating(false);

    queryClient.invalidateQueries(['getApiCrf']);
    
    alert(successMessage);
    window.location.href = '/#/getcrf';
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const validateForm = () => {
    const requiredFields = Object.keys(formData);
    for (const field of requiredFields) {
      if (!formData[field]) {
        const fieldName = field.replace(/_/g, ' ');
        alert(`Please fill out the ${fieldName} field`);
        return false;
      }
    }
    return true;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validateForm()) return;
  
    try {
      const crfData = {
        name: formData.name,
        designation: formData.designation,
        company: formData.company,
        location: formData.location,
        contactNumber: formData.contactNumber,
        email: formData.email,
        priority: formData.priority,
        crfDept: formData.crf_dept,
        protocol: formData.protocol,
        sourceIps: formData.source_ips,
        sourceServerDetails: formData.source_server_details,
        destinationIps: formData.destination_ips,
        destinationServerDetails: formData.destination_server_details,
        port: formData.port,
        portDescription: formData.port_description,
        openDate: formData.open_date,
        closeDate: formData.close_date,
        reasonForChange: formData.reason_for_change
      };
  
      const payload = {
        data: [{
          crf: crfData
        }]
      };
  
      if (isEditMode && editId) {
        updateCrfMutation.mutate({
          id: editId,
          data: payload
        });
        console.log('Update API Payload:', { id: editId, data: payload });
      } else {
        createCrfMutation.mutate({
          data: payload   
        });
        console.log('Create API Payload:', { data: payload });
      }
    } catch (error) {
      console.error("Error in CRF operation:", error);
      alert(`An error occurred: ${error.message}`);
      setIsGenerating(false);
    }
  };

  const handleReset = () => {
    if (isEditMode) {
      if (window.confirm("Do you want to clear all the fields? This will remove the editing data.")) {
        setIsEditMode(false);
        setEditId(null);
        resetFormFields();
      }
    } else {
      resetFormFields();
    }
  };
  
  const resetFormFields = () => {
    setFormData({
      name: '',
      designation: '',
      company: '',
      location: '',
      contactNumber: '',
      email: '',
      priority: '',
      crf_dept: '',
      protocol: '',
      source_ips: '',
      source_server_details: '',
      destination_ips: '',
      destination_server_details: '',
      port: '',
      port_description: '',
      open_date: '',
      close_date: '',
      reason_for_change: ''
    });
  };

  const handleOpenPopup = (e) => {
    e.preventDefault();
    setShowPopup(true);
  };

  const handleClosePopup = () => {
    setShowPopup(false);
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow bg-white px-6 py-4">
        <div className="min-w-full bg-white border border-gray-200 p-1 rounded shadow-md">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-blue-900 text-xl font-bold border-b-4 border-yellow-400 pb-1">
              {isEditMode ? "Update Change Request Form" : "Change Request Form"}
            </h2>
            <button
              onClick={() => window.location.href = '/#/getcrf'}
              className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
            >
              View CRF
            </button>
          </div>

          <div className="mb-6">
            <span className="text-gray-700">Before filling in the CRF form details, please </span>
            <a href="#" className="text-blue-500 font-medium" onClick={handleOpenPopup}>CLICK HERE</a>
            <span className="text-gray-700"> to go through the points.</span>
          </div>

          {showPopup && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
              <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
                <div className="flex justify-end p-2">
                  <button
                    onClick={handleClosePopup}
                    className="text-gray-500 hover:text-gray-700 focus:outline-none"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
                <div className="text-center text-xl font-bold text-blue-900 border-b pb-2 mx-6">
                  CRF Rules
                </div>
                <div className="p-6">
                  <div className="space-y-3 text-gray-700">
                    <p className="font-bold text-red-600">All are Mandatory Fields</p>
                    <p>If you want to provide multiple ports, you can separate by comma ( , ).</p>
                    <p className="font-medium">If you want to give more than one IP address, you can separate by comma ( , ).</p>
                    <p>For Other Queries, Kindly contact SFMS-Development Team.</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          <CRFForm
            formData={formData}
            handleChange={handleChange}
            handleSubmit={handleSubmit}
            isSubmitting={isGenerating || createCrfMutation.isLoading || updateCrfMutation.isLoading}
            submitButtonText={isEditMode ? "UPDATE CRF" : "GENERATE CRF"}
            handleReset={handleReset}
            useFormPlaceholders={true}
          />
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default CreateCrf;