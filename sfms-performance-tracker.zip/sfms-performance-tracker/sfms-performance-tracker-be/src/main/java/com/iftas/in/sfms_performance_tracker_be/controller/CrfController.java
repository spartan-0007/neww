package com.iftas.in.sfms_performance_tracker_be.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CrfController {

    @GetMapping({"/crf", "/getcrf"})
    public String serveApp() {
        return "forward:/index.html";
    }
}