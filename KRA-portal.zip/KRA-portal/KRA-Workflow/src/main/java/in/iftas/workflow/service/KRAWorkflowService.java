//package in.iftas.workflow.service;
//
//import in.iftas.kra.common.enums.CycleStatus;
//import in.iftas.kra.common.enums.Role;
//import in.iftas.kra.common.exceptions.InvalidCycleStateException;
//import in.iftas.kra.common.exceptions.ResourceNotFoundException;
//import in.iftas.kra.common.exceptions.UnauthorizedAccessException;
//import in.iftas.kra.core.dto.*;
//import in.iftas.kra.core.entity.*;
//import in.iftas.kra.core.repository.*;
//import in.iftas.kra.notifications.service.NotificationService;
//import lombok.RequiredArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.scheduling.annotation.Async;
//import org.springframework.security.access.prepost.PreAuthorize;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import java.math.BigDecimal;
//import java.time.OffsetDateTime;
//import java.time.ZoneOffset;
//import java.util.*;
//import java.util.concurrent.CompletableFuture;
//import java.util.stream.Collectors;
//
//@Slf4j
//@Service
//@RequiredArgsConstructor
//public class KRAWorkflowService {
//
//    private final EmployeeRepository employeeRepository;
//    private final AppraisalCycleRepository appraisalCycleRepository;
//    private final EmployeeKRARepository employeeKRARepository;
//    private final EmployeeCompetencyScoreRepository competencyScoreRepository;
//    private final AppraisalDiscussionRepository discussionRepository;
//    private final TrainingNeedRepository trainingNeedRepository;
//    private final FinalRatingRepository finalRatingRepository;
//    private final KRACategoryRepository kraCategoryRepository;
//    private final BehavioralCompetencyRepository competencyRepository;
//    private final NotificationService notificationService;
//
//    // Start a new appraisal cycle
//    @Transactional
//    @PreAuthorize("hasRole('ADMIN')")
//    public AppraisalCycleInfo startAppraisalCycle(AppraisalCycleRequest request) {
//        log.info("Starting new appraisal cycle: {}", request.getCycleName());
//        AppraisalCycle cycle = new AppraisalCycle();
//        cycle.setCycleName(request.getCycleName());
//        cycle.setStartDate(request.getStartDate());
//        cycle.setEndDate(request.getEndDate());
//        cycle.setStatus(CycleStatus.PLANNING.name());
//        appraisalCycleRepository.save(cycle);
//
//        // Notify all employees
//        notificationService.sendCycleStartNotification(cycle);
//        return mapToAppraisalCycleInfo(cycle);
//    }
//
//    // Employee submits self-appraisal for KRAs
//    @Transactional
//    @PreAuthorize("hasRole('EMPLOYEE') and #employeeId == authentication.principal.id")
//    public EmployeeKRAResponse submitSelfAppraisal(Long employeeId, Long cycleId, List<KRADetail> kraDetails) {
//        log.info("Employee {} submitting self-appraisal for cycle {}", employeeId, cycleId);
//
//        Employee employee = employeeRepository.findById(employeeId)
//                .orElseThrow(() -> new ResourceNotFoundException("Employee not found: " + employeeId));
//        AppraisalCycle cycle = appraisalCycleRepository.findById(cycleId)
//                .orElseThrow(() -> new ResourceNotFoundException("Cycle not found: " + cycleId));
//
//        if (!cycle.getStatus().equals(CycleStatus.SELF_APPRAISAL.name())) {
//            throw new InvalidCycleStateException("Cycle is not in SELF_APPRAISAL state");
//        }
//
//        // Convert BigDecimal to Double for entity compatibility
//        kraDetails.forEach(detail -> {
//            if (detail.getSelfScore() != null) {
//                detail.setSelfScore(detail.getSelfScore().doubleValue());
//            }
//            if (detail.getWeightage() != null) {
//                detail.setWeightage(detail.getWeightage().doubleValue());
//            }
//        });
//
//        validateKRAs(employee, kraDetails);
//        List<EmployeeKRA> kras = kraDetails.stream().map(detail -> {
//            EmployeeKRA kra = new EmployeeKRA();
//            kra.setEmployee(employee);
//            kra.setAppraisalCycle(cycle);
//            kra.setKraCategory(kraCategoryRepository.findById(detail.getKraCategoryId())
//                    .orElseThrow(() -> new ResourceNotFoundException("KRA category not found: " + detail.getKraCategoryId())));
//            kra.setTitle(detail.getTitle());
//            kra.setDescription(detail.getDescription());
//            kra.setTargetValue(detail.getTargetValue());
//            kra.setWeightage(detail.getWeightage());
//            kra.setSelfScore(detail.getSelfScore());
//            kra.setStatus("PENDING_SUPERVISOR");
//            return kra;
//        }).collect(Collectors.toList());
//
//        employeeKRARepository.saveAll(kras);
//        checkAndUpdateCycleStatus(cycle);
//
//        // Notify supervisor
//        if (employee.getSupervisorId() != null) {
//            notificationService.sendSelfAppraisalSubmittedNotification(employee, cycle);
//        }
//
//        return createKRAResponse("Self-appraisal submitted successfully", employee, cycle, kras, true);
//    }
//
//    // Employee submits behavioral competency self-scores
//    @Transactional
//    @PreAuthorize("hasRole('EMPLOYEE') and #employeeId == authentication.principal.id")
//    public EmployeeKRAResponse submitCompetencySelfScores(Long employeeId, Long cycleId, List<CompetencyScoreRequest> scores) {
//        log.info("Employee {} submitting competency self-scores for cycle {}", employeeId, cycleId);
//
//        Employee employee = employeeRepository.findById(employeeId)
//                .orElseThrow(() -> new ResourceNotFoundException("Employee not found: " + employeeId));
//        AppraisalCycle cycle = appraisalCycleRepository.findById(cycleId)
//                .orElseThrow(() -> new ResourceNotFoundException("Cycle not found: " + cycleId));
//
//        if (!cycle.getStatus().equals(CycleStatus.SELF_APPRAISAL.name())) {
//            throw new InvalidCycleStateException("Cycle is not in SELF_APPRAISAL state");
//        }
//
//        // Convert BigDecimal to Double
//        scores.forEach(score -> {
//            if (score.getSelfScore() != null) {
//                score.setSelfScore(score.getSelfScore().doubleValue());
//            }
//        });
//
//        validateCompetencyScores(employee, scores);
//        List<EmployeeCompetencyScore> competencyScores = scores.stream().map(score -> {
//            EmployeeCompetencyScore compScore = new EmployeeCompetencyScore();
//            compScore.setEmployee(employee);
//            compScore.setAppraisalCycle(cycle);
//            compScore.setCompetency(competencyRepository.findById(score.getCompetencyId())
//                    .orElseThrow(() -> new ResourceNotFoundException("Competency not found: " + score.getCompetencyId())));
//            compScore.setSelfScore(score.getSelfScore());
//            compScore.setComments(score.getSupervisorComments());
//            return compScore;
//        }).collect(Collectors.toList());
//
//        competencyScoreRepository.saveAll(competencyScores);
//
//        // Notify supervisor
//        if (employee.getSupervisorId() != null) {
//            notificationService.sendCompetencySelfScoresSubmittedNotification(employee, cycle);
//        }
//
//        return createKRAResponse("Competency self-scores submitted successfully", employee, cycle, null, true);
//    }
//
//    // Get all KRAs for a cycle, filtered by role
//    @Transactional(readOnly = true)
//    @PreAuthorize("hasAnyRole('EMPLOYEE', 'SUPERVISOR', 'REVIEWER', 'ADMIN')")
//    public EmployeeKRAResponse getAllKRAsByCycle(Long cycleId) {
//        log.info("Retrieving all KRAs for cycle {}", cycleId);
//
//        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
//        boolean isEmployee = auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals(Role.EMPLOYEE.name()));
//        Long userId = ((UserData) auth.getPrincipal()).getId();
//
//        AppraisalCycle cycle = appraisalCycleRepository.findById(cycleId)
//                .orElseThrow(() -> new ResourceNotFoundException("Appraisal Cycle not found: " + cycleId));
//
//        List<EmployeeKRA> entities = employeeKRARepository.findByAppraisalCycleId(cycleId);
//
//        if (entities.isEmpty()) {
//            log.warn("No KRAs found for cycle {}", cycleId);
//            return createKRAResponse("No KRAs found for cycle", null, cycle, null, isEmployee);
//        }
//
//        Map<Long, List<EmployeeKRA>> groupedByEmployee = entities.stream()
//                .filter(kra -> !isEmployee || kra.getEmployee().getId().equals(userId) ||
//                        kra.getEmployee().getSupervisorId().equals(userId) ||
//                        kra.getEmployee().getReviewerId().equals(userId))
//                .collect(Collectors.groupingBy(kra -> kra.getEmployee().getId()));
//
//        List<Long> sortedEmployeeIds = groupedByEmployee.keySet().stream()
//                .sorted()
//                .collect(Collectors.toList());
//
//        List<EmployeeKRAData> employeeKRADataList = new ArrayList<>();
//        for (Long empId : sortedEmployeeIds) {
//            List<EmployeeKRA> employeeKRAs = groupedByEmployee.get(empId);
//            Employee employee = employeeRepository.findById(empId)
//                    .orElseThrow(() -> new ResourceNotFoundException("Employee not found: " + empId));
//
//            List<KRADetail> kras = employeeKRAs.stream()
//                    .map(kra -> mapToKRADetail(kra, isEmployee && !employee.getSupervisorId().equals(userId) && !employee.getReviewerId().equals(userId)))
//                    .sorted(Comparator.comparing(KRADetail::getId))
//                    .collect(Collectors.toList());
//
//            double totalWeightage = kras.stream()
//                    .mapToDouble(KRADetail::getWeightage)
//                    .sum();
//
//            EmployeeKRAData employeeData = new EmployeeKRAData();
//            employeeData.setEmployee(mapToUserData(employee));
//            employeeData.setCycle(mapToAppraisalCycleInfo(cycle));
//            employeeData.setKras(kras);
//            employeeData.setTotalWeightage(totalWeightage);
//
//            employeeKRADataList.add(employeeData);
//        }
//
//        return createKRAResponse("All KRAs for cycle retrieved successfully", null, cycle, null, isEmployee);
//    }
//
//    // Get competency scores, filtered by role
//    @Transactional(readOnly = true)
//    @PreAuthorize("hasAnyRole('EMPLOYEE', 'SUPERVISOR', 'REVIEWER', 'ADMIN')")
//    public EmployeeCompetencyResponse getCompetencyScores(Long employeeId, Long cycleId) {
//        log.info("Retrieving competency scores for employee {} in cycle {}", employeeId, cycleId);
//
//        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
//        boolean isEmployee = auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals(Role.EMPLOYEE.name()));
//        Long userId = ((UserData) auth.getPrincipal()).getId();
//
//        Employee employee = employeeRepository.findById(employeeId)
//                .orElseThrow(() -> new ResourceNotFoundException("Employee not found: " + employeeId));
//        AppraisalCycle cycle = appraisalCycleRepository.findById(cycleId)
//                .orElseThrow(() -> new ResourceNotFoundException("Cycle not found: " + cycleId));
//
//        if (isEmployee && !employeeId.equals(userId) && !employee.getSupervisorId().equals(userId) && !employee.getReviewerId().equals(userId)) {
//            throw new UnauthorizedAccessException("Unauthorized access to employee data");
//        }
//
//        List<EmployeeCompetencyScore> scores = competencyScoreRepository.findByEmployeeIdAndAppraisalCycleId(employeeId, cycleId);
//        List<CompetencyScoreData> scoreData = scores.stream()
//                .map(score -> mapToCompetencyScoreData(score, isEmployee && !employee.getSupervisorId().equals(userId) && !employee.getReviewerId().equals(userId)))
//                .collect(Collectors.toList());
//
//        EmployeeCompetencyResponse response = new EmployeeCompetencyResponse();
//        response.setSuccess(true);
//        response.setMessage("Competency scores retrieved successfully");
//        response.setTimestamp(OffsetDateTime.now(ZoneOffset.UTC));
//        response.setData(scoreData);
//        return response;
//    }
//
//    // Supervisor submits KRA evaluations
//    @Transactional
//    @PreAuthorize("hasRole('SUPERVISOR') and @employeeRepository.findById(#employeeId).orElseThrow().supervisorId == authentication.principal.id")
//    public EmployeeKRAResponse submitSupervisorKRAEvals(Long employeeId, Long cycleId, List<KRADetail> kraDetails) {
//        log.info("Supervisor evaluating KRAs for employee {} in cycle {}", employeeId, cycleId);
//
//        Employee employee = employeeRepository.findById(employeeId)
//                .orElseThrow(() -> new ResourceNotFoundException("Employee not found: " + employeeId));
//        AppraisalCycle cycle = appraisalCycleRepository.findById(cycleId)
//                .orElseThrow(() -> new ResourceNotFoundException("Cycle not found: " + cycleId));
//
//        if (!cycle.getStatus().equals(CycleStatus.SUPERVISOR_EVALUATION.name())) {
//            throw new InvalidCycleStateException("Cycle is not in SUPERVISOR_EVALUATION state");
//        }
//
//        List<EmployeeKRA> kras = employeeKRARepository.findByEmployeeIdAndAppraisalCycleId(employeeId, cycleId);
//        if (kras.isEmpty()) {
//            throw new IllegalStateException("No KRAs found for employee in this cycle");
//        }
//
//        for (KRADetail detail : kraDetails) {
//            EmployeeKRA kra = kras.stream()
//                    .filter(k -> k.getId().equals(detail.getId()))
//                    .findFirst()
//                    .orElseThrow(() -> new ResourceNotFoundException("KRA not found: " + detail.getId()));
//            kra.setSupervisorScore(detail.getSupervisorScore() != null ? detail.getSupervisorScore().doubleValue() : null);
//            kra.setSupervisorComments(detail.getSupervisorComments());
//            kra.setWeightedScore(detail.getWeightage().doubleValue() * kra.getSupervisorScore() / 100);
//            kra.setStatus("PENDING_REVIEWER");
//        }
//
//        employeeKRARepository.saveAll(kras);
//        checkAndUpdateCycleStatus(cycle);
//
//        // Notify reviewer
//        if (employee.getReviewerId() != null) {
//            notificationService.sendSupervisorEvaluationNotification(employee, cycle);
//        }
//
//        return createKRAResponse("Supervisor KRA evaluations submitted", employee, cycle, kras, false);
//    }
//
//    // Supervisor submits competency evaluations
//    @Transactional
//    @PreAuthorize("hasRole('SUPERVISOR') and @employeeRepository.findById(#employeeId).orElseThrow().supervisorId == authentication.principal.id")
//    public EmployeeKRAResponse submitSupervisorCompetencyEvals(Long employeeId, Long cycleId, List<CompetencyScoreRequest> scores) {
//        log.info("Supervisor evaluating competencies for employee {} in cycle {}", employeeId, cycleId);
//
//        Employee employee = employeeRepository.findById(employeeId)
//                .orElseThrow(() -> new ResourceNotFoundException("Employee not found: " + employeeId));
//        AppraisalCycle cycle = appraisalCycleRepository.findById(cycleId)
//                .orElseThrow(() -> new ResourceNotFoundException("Cycle not found: " + cycleId));
//
//        if (!cycle.getStatus().equals(CycleStatus.SUPERVISOR_EVALUATION.name())) {
//            throw new InvalidCycleStateException("Cycle is not in SUPERVISOR_EVALUATION state");
//        }
//
//        List<EmployeeCompetencyScore> compScores = competencyScoreRepository.findByEmployeeIdAndAppraisalCycleId(employeeId, cycleId);
//        if (compScores.isEmpty()) {
//            throw new IllegalStateException("No competency scores found for employee in this cycle");
//        }
//
//        for (CompetencyScoreRequest score : scores) {
//            EmployeeCompetencyScore compScore = compScores.stream()
//                    .filter(cs -> cs.getCompetency().getId().equals(score.getCompetencyId()))
//                    .findFirst()
//                    .orElseThrow(() -> new ResourceNotFoundException("Competency score not found: " + score.getCompetencyId()));
//            compScore.setSupervisorScore(score.getSupervisorScore() != null ? score.getSupervisorScore().doubleValue() : null);
//            compScore.setComments(score.getSupervisorComments());
//        }
//
//        competencyScoreRepository.saveAll(compScores);
//
//        // Notify reviewer
//        if (employee.getReviewerId() != null) {
//            notificationService.sendSupervisorCompetencyEvaluationNotification(employee, cycle);
//        }
//
//        return createKRAResponse("Supervisor competency evaluations submitted", employee, cycle, null, false);
//    }
//
//    // Joint appraisal discussion
//    @Transactional
//    @PreAuthorize("hasAnyRole('EMPLOYEE', 'SUPERVISOR') and (#employeeId == authentication.principal.id or @employeeRepository.findById(#employeeId).orElseThrow().supervisorId == authentication.principal.id)")
//    public AppraisalDiscussionResponse submitAppraisalDiscussion(Long employeeId, Long cycleId, AppraisalDiscussionRequest request) {
//        log.info("Recording appraisal discussion for employee {} in cycle {}", employeeId, cycleId);
//
//        Employee employee = employeeRepository.findById(employeeId)
//                .orElseThrow(() -> new ResourceNotFoundException("Employee not found: " + employeeId));
//        AppraisalCycle cycle = appraisalCycleRepository.findById(cycleId)
//                .orElseThrow(() -> new ResourceNotFoundException("Cycle not found: " + cycleId));
//
//        if (!cycle.getStatus().equals(CycleStatus.SUPERVISOR_EVALUATION.name())) {
//            throw new InvalidCycleStateException("Cycle is not in SUPERVISOR_EVALUATION state");
//        }
//
//        AppraisalDiscussion discussion = new AppraisalDiscussion();
//        discussion.setEmployee(employee);
//        discussion.setAppraisalCycle(cycle);
//        discussion.setDiscussionDate(request.getDiscussionDate());
//        discussion.setDiscussionSummary(request.getDiscussionSummary());
//        discussion.setTrainingNeeds(request.getTrainingNeeds());
//
//        discussionRepository.save(discussion);
//
//        // Notify employee and supervisor
//        notificationService.sendDiscussionRecordedNotification(employee, cycle);
//
//        AppraisalDiscussionResponse response = new AppraisalDiscussionResponse();
//        response.setSuccess(true);
//        response.setMessage("Appraisal discussion recorded successfully");
//        response.setTimestamp(OffsetDateTime.now(ZoneOffset.UTC));
//        response.setData(mapToAppraisalDiscussionData(discussion));
//        return response;
//    }
//
//    // Reviewer submits final ratings
//    @Transactional
//    @PreAuthorize("hasRole('REVIEWER') and @employeeRepository.findById(#employeeId).orElseThrow().reviewerId == authentication.principal.id")
//    public FinalRatingResponse submitFinalRating(Long employeeId, Long cycleId, FinalRatingRequest request) {
//        log.info("Reviewer submitting final rating for employee {} in cycle {}", employeeId, cycleId);
//
//        Employee employee = employeeRepository.findById(employeeId)
//                .orElseThrow(() -> new ResourceNotFoundException("Employee not found: " + employeeId));
//        AppraisalCycle cycle = appraisalCycleRepository.findById(cycleId)
//                .orElseThrow(() -> new ResourceNotFoundException("Cycle not found: " + cycleId));
//
//        if (!cycle.getStatus().equals(CycleStatus.REVIEWER_EVALUATION.name())) {
//            throw new InvalidCycleStateException("Cycle is not in REVIEWER_EVALUATION state");
//        }
//
//        List<EmployeeKRA> kras = employeeKRARepository.findByEmployeeIdAndAppraisalCycleId(employeeId, cycleId);
//        List<EmployeeCompetencyScore> compScores = competencyScoreRepository.findByEmployeeIdAndAppraisalCycleId(employeeId, cycleId);
//
//        double kraWeightedScore = kras.stream().mapToDouble(EmployeeKRA::getWeightedScore).sum();
//        double competencyWeightedScore = compScores.stream().mapToDouble(EmployeeCompetencyScore::getSupervisorScore).sum();
//
//        double kraWeight = getKRAWeight(employee.getLevel());
//        double competencyWeight = 1.0 - kraWeight;
//
//        FinalRating rating = new FinalRating();
//        rating.setEmployee(employee);
//        rating.setAppraisalCycle(cycle);
//        rating.setKraWeightedScore(kraWeightedScore);
//        rating.setKraActualScore(kraWeightedScore * kraWeight);
//        rating.setCompetencyWeightedScore(competencyWeightedScore);
//        rating.setCompetencyActualScore(competencyWeightedScore * competencyWeight);
//        rating.setFinalScore(request.getFinalScore().doubleValue());
//        rating.setFinalRating(request.getFinalRating());
//        rating.setComments(request.getComments());
//
//        finalRatingRepository.save(rating);
//        kras.forEach(kra -> kra.setStatus("COMPLETED"));
//        employeeKRARepository.saveAll(kras);
//        checkAndUpdateCycleStatus(cycle);
//
//        // Notify employee
//        notificationService.sendFinalRatingNotification(employee, cycle);
//
//        FinalRatingResponse response = new FinalRatingResponse();
//        response.setSuccess(true);
//        response.setMessage("Final rating submitted successfully");
//        response.setTimestamp(OffsetDateTime.now(ZoneOffset.UTC));
//        response.setData(mapToFinalRatingData(rating));
//        return response;
//    }
//
//    // Async report generation
//    @Async
//    @Transactional(readOnly = true)
//    @PreAuthorize("hasRole('ADMIN')")
//    public CompletableFuture<Void> generateAppraisalReport(Long cycleId) {
//        log.info("Generating appraisal report for cycle {}", cycleId);
//        AppraisalCycle cycle = appraisalCycleRepository.findById(cycleId)
//                .orElseThrow(() -> new ResourceNotFoundException("Cycle not found: " + cycleId));
//
//        List<FinalRating> ratings = finalRatingRepository.findByAppraisalCycleId(cycleId);
//        // Placeholder for report generation logic (e.g., PDF creation)
//        log.info("Generated report for {} employees in cycle {}", ratings.size(), cycleId);
//
//        // Notify admins
//        notificationService.sendReportGeneratedNotification(cycle);
//        return CompletableFuture.completedFuture(null);
//    }
//
//    // Validate KRAs
//    private void validateKRAs(Employee employee, List<KRADetail> kraDetails) {
//        if (kraDetails.size() > 5) {
//            throw new IllegalArgumentException("Maximum 5 KRAs allowed");
//        }
//        KRACategory mandatoryCategory = kraCategoryRepository.findByName("New Initiatives / Process Improvements and Self Development")
//                .orElseThrow(() -> new ResourceNotFoundException("Mandatory KRA category not found"));
//        boolean hasMandatoryKRA = kraDetails.stream()
//                .anyMatch(kra -> kra.getKraCategoryId().equals(mandatoryCategory.getId()));
//        if (!hasMandatoryKRA) {
//            throw new IllegalArgumentException("Mandatory KRA 'New Initiatives / Process Improvements and Self Development' is required");
//        }
//        double totalWeightage = kraDetails.stream().mapToDouble(kra -> kra.getWeightage().doubleValue()).sum();
//        if (Math.abs(totalWeightage - 100.0) > 0.01) {
//            throw new IllegalArgumentException("Total KRA weightage must be 100%");
//        }
//        for (KRADetail kra : kraDetails) {
//            double selfScore = kra.getSelfScore() != null ? kra.getSelfScore().doubleValue() : 0;
//            if (selfScore < 0 || selfScore > 100) {
//                throw new IllegalArgumentException("KRA self-score must be between 0 and 100");
//            }
//        }
//    }
//
//    // Validate competency scores
//    private void validateCompetencyScores(Employee employee, List<CompetencyScoreRequest> scores) {
//        int expectedCount = employee.getLevel().equals("AVP") || employee.getLevel().equals("DVP") ? 7 : 6;
//        if (scores.size() != expectedCount) {
//            throw new IllegalArgumentException("Expected " + expectedCount + " competency scores for level " + employee.getLevel());
//        }
//        int maxScore = employee.getLevel().equals("AVP") || employee.getLevel().equals("DVP") ? 10 : 15;
//        for (CompetencyScoreRequest score : scores) {
//            double selfScore = score.getSelfScore() != null ? score.getSelfScore().doubleValue() : 0;
//            if (selfScore < 0 || selfScore > maxScore) {
//                throw new IllegalArgumentException("Competency self-score must be between 0 and " + maxScore);
//            }
//        }
//    }
//
//    // Update cycle status based on KRA states
//    @Transactional
//    public void checkAndUpdateCycleStatus(AppraisalCycle cycle) {
//        List<EmployeeKRA> kras = employeeKRARepository.findByAppraisalCycleId(cycle.getId());
//        if (kras.isEmpty()) {
//            return;
//        }
//        boolean allPendingSupervisor = kras.stream().allMatch(kra -> kra.getStatus().equals("PENDING_SUPERVISOR"));
//        boolean allPendingReviewer = kras.stream().allMatch(kra -> kra.getStatus().equals("PENDING_REVIEWER"));
//        boolean allCompleted = kras.stream().allMatch(kra -> kra.getStatus().equals("COMPLETED"));
//
//        if (allCompleted && !cycle.getStatus().equals(CycleStatus.COMPLETED.name())) {
//            cycle.setStatus(CycleStatus.COMPLETED.name());
//            appraisalCycleRepository.save(cycle);
//            generateAppraisalReport(cycle.getId());
//        } else if (allPendingReviewer && !cycle.getStatus().equals(CycleStatus.REVIEWER_EVALUATION.name())) {
//            cycle.setStatus(CycleStatus.REVIEWER_EVALUATION.name());
//            appraisalCycleRepository.save(cycle);
//            notificationService.sendCycleStatusChangeNotification(cycle, CycleStatus.REVIEWER_EVALUATION);
//        } else if (allPendingSupervisor && !cycle.getStatus().equals(CycleStatus.SUPERVISOR_EVALUATION.name())) {
//            cycle.setStatus(CycleStatus.SUPERVISOR_EVALUATION.name());
//            appraisalCycleRepository.save(cycle);
//            notificationService.sendCycleStatusChangeNotification(cycle, CycleStatus.SUPERVISOR_EVALUATION);
//        }
//    }
//
//    // Get KRA weight based on employee level
//    private double getKRAWeight(String level) {
//        switch (level) {
//            case "VP":
//            case "SVP":
//            case "AVP":
//            case "DVP":
//                return 0.4; // 40% KRA, 60% Competency
//            case "MGR":
//            case "SR_MGR":
//                return 0.6; // 60% KRA, 40% Competency
//            case "L3":
//                return 0.7; // 70% KRA, 30% Competency
//            default:
//                throw new IllegalArgumentException("Invalid employee level: " + level);
//        }
//    }
//
//    // Helper methods for mapping entities to DTOs
//    private EmployeeKRAResponse createKRAResponse(String message, Employee employee, AppraisalCycle cycle, List<EmployeeKRA> kras, boolean isEmployeeView) {
//        List<EmployeeKRAData> employeeKRADataList = new ArrayList<>();
//        if (employee != null && kras != null) {
//            EmployeeKRAData data = new EmployeeKRAData();
//            data.setEmployee(mapToUserData(employee));
//            data.setCycle(mapToAppraisalCycleInfo(cycle));
//            data.setKras(kras.stream()
//                    .map(kra -> mapToKRADetail(kra, isEmployeeView))
//                    .collect(Collectors.toList()));
//            data.setTotalWeightage(kras.stream().mapToDouble(EmployeeKRA::getWeightage).sum());
//            employeeKRADataList.add(data);
//        }
//
//        EmployeeKRAResponse response = new EmployeeKRAResponse();
//        response.setSuccess(true);
//        response.setMessage(message);
//        response.setTimestamp(OffsetDateTime.now(ZoneOffset.UTC));
//        response.setData(employeeKRADataList);
//        return response;
//    }
//
//    private KRADetail mapToKRADetail(EmployeeKRA kra, boolean isEmployeeView) {
//        KRADetail detail = new KRADetail();
//        detail.setId(kra.getId());
//        detail.setKraCategoryId(kra.getKraCategory().getId());
//        detail.setTitle(kra.getTitle());
//        detail.setDescription(kra.getDescription());
//        detail.setTargetValue(kra.getTargetValue());
//        detail.setWeightage(BigDecimal.valueOf(kra.getWeightage()));
//        detail.setSelfScore(kra.getSelfScore() != null ? BigDecimal.valueOf(kra.getSelfScore()) : null);
//        detail.setStatus(kra.getStatus());
//        if (!isEmployeeView) {
//            detail.setSupervisorScore(kra.getSupervisorScore() != null ? BigDecimal.valueOf(kra.getSupervisorScore()) : null);
//            detail.setSupervisorComments(kra.getSupervisorComments());
//        }
//        return detail;
//    }
//
//    private CompetencyScoreData mapToCompetencyScoreData(EmployeeCompetencyScore score, boolean isEmployeeView) {
//        CompetencyScoreData data = new CompetencyScoreData();
//        data.setCompetencyId(score.getCompetency().getId());
//        data.setCompetencyName(score.getCompetency().getName());
//        data.setSelfScore(score.getSelfScore() != null ? BigDecimal.valueOf(score.getSelfScore()) : null);
//        data.setComments(score.getComments());
//        if (!isEmployeeView) {
//            data.setSupervisorScore(score.getSupervisorScore() != null ? BigDecimal.valueOf(score.getSupervisorScore()) : null);
//        }
//        return data;
//    }
//
//    private UserData mapToUserData(Employee employee) {
//        UserData userData = new UserData();
//        userData.setId(employee.getId());
//        userData.setEmpCode(employee.getEmpCode());
//        userData.setEmail(employee.getEmail());
//        userData.setFullName((employee.getFirstName() != null ? employee.getFirstName() : "") +
//                (employee.getLastName() != null ? " " + employee.getLastName() : ""));
//        userData.setDesignation(employee.getDesignation());
//        userData.setDepartment(employee.getDepartment() != null ? employee.getDepartment().getName() : null);
//        userData.setLocation(employee.getLocation());
//        userData.setDateOfJoining(employee.getDateOfJoining() != null ? employee.getDateOfJoining().toString() : null);
//        userData.setIsActive(employee.getIsActive());
//        return userData;
//    }
//
//    private AppraisalCycleInfo mapToAppraisalCycleInfo(AppraisalCycle cycle) {
//        AppraisalCycleInfo cycleInfo = new AppraisalCycleInfo();
//        cycleInfo.setId(cycle.getId());
//        cycleInfo.setCycleName(cycle.getCycleName());
//        cycleInfo.setStartDate(cycle.getStartDate().toString());
//        cycleInfo.setEndDate(cycle.getEndDate().toString());
//        cycleInfo.setStatus(cycle.getStatus());
//        return cycleInfo;
//    }
//
//    private AppraisalDiscussionData mapToAppraisalDiscussionData(AppraisalDiscussion discussion) {
//        AppraisalDiscussionData data = new AppraisalDiscussionData();
//        data.setId(discussion.getId());
//        data.setEmployeeId(discussion.getEmployee().getId());
//        data.setAppraisalCycleId(discussion.getAppraisalCycle().getId());
//        data.setDiscussionDate(discussion.getDiscussionDate());
//        data.setDiscussionSummary(discussion.getDiscussionSummary());
//        data.setTrainingNeeds(discussion.getTrainingNeeds());
//        return data;
//    }
//
//    private FinalRatingData mapToFinalRatingData(FinalRating rating) {
//        FinalRatingData data = new FinalRatingData();
//        data.setId(rating.getId());
//        data.setEmployeeId(rating.getEmployee().getId());
//        data.setAppraisalCycleId(rating.getAppraisalCycle().getId());
//        data.setFinalScore(BigDecimal.valueOf(rating.getFinalScore()));
//        data.setFinalRating(rating.getFinalRating());
//        data.setComments(rating.getComments());
//        return data;
//    }
//}
