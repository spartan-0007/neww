package in.iftas.kra.notifications.service;

public class NotificationService {
}
