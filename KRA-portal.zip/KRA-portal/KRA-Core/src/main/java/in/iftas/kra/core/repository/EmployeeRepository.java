package in.iftas.kra.core.repository;



import in.iftas.kra.core.entity.EmployeeEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<EmployeeEntity, Long> {
    EmployeeEntity findByEmpCode(String empCode);
    EmployeeEntity findByEmail(String email);
}
