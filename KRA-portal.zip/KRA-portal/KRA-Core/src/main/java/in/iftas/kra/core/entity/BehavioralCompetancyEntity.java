package in.iftas.kra.core.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "behavioral_competencies")
@Data
public class BehavioralCompetancyEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true)
    private String name;
}

