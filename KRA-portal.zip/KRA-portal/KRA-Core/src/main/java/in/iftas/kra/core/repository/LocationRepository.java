package in.iftas.kra.core.repository;

public interface LocationRepository {
}
