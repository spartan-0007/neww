package in.iftas.kra.core.entity;



import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;

@Entity
@Table(name = "employees")
@Data
public class EmployeeEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "emp_code", unique = true)
    private String empCode;

    @Column(unique = true)
    private String email;

    private String firstName;
    private String lastName;
    private String designation;
    private String location;
    private LocalDate dateOfJoining;
    private Boolean isActive;
    private String level; // e.g., VP, AVP, MGR, L3

    @Column(name = "supervisor_id")
    private Long supervisorId;

    @Column(name = "reviewer_id")
    private Long reviewerId;

    @ManyToOne
    @JoinColumn(name = "department_id")
    private DepartmentEntity departmentEntity;
}
