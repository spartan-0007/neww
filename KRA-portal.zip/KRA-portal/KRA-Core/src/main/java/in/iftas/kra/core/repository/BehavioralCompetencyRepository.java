package in.iftas.kra.core.repository;



import in.iftas.kra.core.entity.BehavioralCompetancyEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BehavioralCompetencyRepository extends JpaRepository<BehavioralCompetancyEntity, Long> {
}
