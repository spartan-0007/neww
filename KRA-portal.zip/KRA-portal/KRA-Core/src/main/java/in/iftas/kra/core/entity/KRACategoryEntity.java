package in.iftas.kra.core.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "kra_categories")
@Data
public class KRACategoryEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true)
    private String name;
}
