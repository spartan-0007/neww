package in.iftas.kra.core.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "final_ratings")
@Data
public class FinalRatingEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "employee_id")
    private EmployeeEntity employeeEntity;

    @ManyToOne
    @JoinColumn(name = "appraisal_cycle_id")
    private AppraisalCycleEntity appraisalCycleEntity;

    private Double finalScore;
    private String finalRating;
    private String comments;
}
