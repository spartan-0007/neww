package in.iftas.kra.core.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "employee_competency_scores")
@Data
public class EmployeeCompetancyScoreEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "employee_id")
    private EmployeeEntity employeeEntity;

    @ManyToOne
    @JoinColumn(name = "appraisal_cycle_id")
    private AppraisalCycleEntity appraisalCycle;

    @ManyToOne
    @JoinColumn(name = "competency_id")
    private BehavioralCompetancyEntity behavioralCompetancyEntity;

    private Double selfScore;
    private Double supervisorScore;
    private String comments;
}
