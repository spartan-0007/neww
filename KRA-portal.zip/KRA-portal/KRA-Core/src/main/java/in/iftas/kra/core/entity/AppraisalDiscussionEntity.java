package in.iftas.kra.core.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "appraisal_discussions")
@Data
public class AppraisalDiscussionEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "employee_id")
    private EmployeeEntity employeeEntity;

    @ManyToOne
    @JoinColumn(name = "appraisal_cycle_id")
    private AppraisalCycleEntity appraisalCycleEntity;

    private LocalDate discussionDate;
    private String discussionSummary;
    private List<String> trainingNeeds;
}

