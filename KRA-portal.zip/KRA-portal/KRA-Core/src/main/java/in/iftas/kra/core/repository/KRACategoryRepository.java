package in.iftas.kra.core.repository;



import in.iftas.kra.core.entity.KRACategoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KRACategoryRepository extends JpaRepository<KRACategoryEntity, Long> {
}
