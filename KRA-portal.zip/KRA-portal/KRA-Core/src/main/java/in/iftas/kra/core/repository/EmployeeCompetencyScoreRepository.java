package in.iftas.kra.core.repository;





import in.iftas.kra.core.entity.EmployeeCompetancyScoreEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeCompetencyScoreRepository extends JpaRepository<EmployeeCompetancyScoreEntity, Long> {
}
