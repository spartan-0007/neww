package in.iftas.kra.core.repository;



import in.iftas.kra.core.entity.AppraisalCycleEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AppraisalCycleRepository extends JpaRepository<AppraisalCycleEntity, Long> {
}
