package in.iftas.kra.core.entity;

public class LocationEntity {
}
