package in.iftas.kra.core.repository;



import in.iftas.kra.core.entity.FinalRatingEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FinalRatingRepository extends JpaRepository<FinalRatingEntity, Long> {
}
