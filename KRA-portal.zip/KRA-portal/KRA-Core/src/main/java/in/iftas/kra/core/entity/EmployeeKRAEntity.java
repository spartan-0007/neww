package in.iftas.kra.core.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "employee_kras")
@Data
public class EmployeeKRAEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "employee_id")
    private EmployeeEntity employeeEntity;

    @ManyToOne
    @JoinColumn(name = "appraisal_cycle_id")
    private AppraisalCycleEntity appraisalCycleEntity;

    @ManyToOne
    @JoinColumn(name = "kra_category_id")
    private KRACategoryEntity kraCategoryEntity;

    private String title;
    private String description;
    private String targetValue;
    private Double weightage;
    private Double selfScore;
    private Double supervisorScore;
    private String supervisorComments;
    private Double weightedScore;
    private String status; // e.g., PENDING_SUPERVISOR, PENDING_REVIEWER, COMPLETED
}

