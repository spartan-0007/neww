package in.iftas.kra.core.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;

@Entity
@Table(name = "appraisal_cycles")
@Data
public class AppraisalCycleEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "cycle_name")
    private String cycleName;

    private LocalDate startDate;
    private LocalDate endDate;
    private String status; // e.g., PLANNING, SELF_APPRAISAL, COMPLETED
}

