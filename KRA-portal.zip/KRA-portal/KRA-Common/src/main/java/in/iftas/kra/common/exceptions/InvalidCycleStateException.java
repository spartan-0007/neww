package in.iftas.kra.common.exceptions;

public class InvalidCycleStateException extends RuntimeException {
    public InvalidCycleStateException(String message) {
        super(message);
    }
}
