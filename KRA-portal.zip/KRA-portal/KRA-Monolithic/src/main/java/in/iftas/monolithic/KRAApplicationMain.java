package in.iftas.monolithic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = {
       "in.iftas.kra.core",//           // Includes entities, repositories, services
      "in.iftas.kra.auth",           // If you have auth-related beans
       "in.iftas.kra.workflow",       // If workflow beans exist
      "in.iftas.kra.notifications"   // If notification beans exist
})
@EntityScan(basePackages = "in.iftas.kra.core.entity")
@EnableJpaRepositories(basePackages = "in.iftas.kra.core.repository")
public class KRAApplicationMain {
    public static void main(String[] args) {
        SpringApplication.run(KRAApplicationMain.class, args);
    }
}
